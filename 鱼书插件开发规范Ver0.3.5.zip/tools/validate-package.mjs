import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import vm from 'node:vm';
import crypto from 'node:crypto';

const fileArg = process.argv[2];
if (!fileArg) {
  console.error('用法：node tools/validate-package.mjs <插件包.fishplugin.json>');
  process.exit(2);
}

const errors = [];
const warnings = [];
const filePath = path.resolve(fileArg);
const bytes = fs.readFileSync(filePath);
if (bytes.length < 1) errors.push('文件为空');
if (bytes.length > 5 * 1024 * 1024) errors.push('插件包超过 5 MiB');

let pkg;
try { pkg = JSON.parse(bytes.toString('utf8')); }
catch (error) { errors.push('不是有效 UTF-8 JSON：' + error.message); }

const stableId = /^[A-Za-z0-9._:-]{8,128}$/;
const semver = /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-[0-9A-Za-z.-]+)?$/;
const domain = /^(?:\*\.)?(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?))*$/;
const modulePath = /^[A-Za-z0-9._/-]+\.(?:m?js|html?)$/;
const publicKinds = new Set(['source', 'dictionary', 'tts']);
const publicEntrypoints = new Set([
  'searchTargets', 'searchPrepareBatch', 'searchParseBatch', 'searchBatch',
  'manageSearchTarget', 'permissionGroups', 'search', 'exploreMenu', 'explore',
  'detail', 'catalog', 'content', 'dictionary', 'ttsVoices', 'ttsSynthesize',
  'loginCheck', 'manage', 'ui'
]);

if (pkg) {
  if (pkg.schemaVersion !== 1) errors.push('顶层 schemaVersion 必须为 1');
  if (!pkg.manifest || typeof pkg.manifest !== 'object' || Array.isArray(pkg.manifest)) errors.push('缺少 manifest');
  if (typeof pkg.source !== 'string' || pkg.source.length < 1) errors.push('缺少 source');
  if (typeof pkg.source === 'string' && Buffer.byteLength(pkg.source, 'utf8') > 4 * 1024 * 1024) errors.push('主模块超过 4 MiB');

  const m = pkg.manifest || {};
  const sourceFormat = m.sourceFormat || 'fishreader-js';
  if (m.schemaVersion !== 1) errors.push('manifest.schemaVersion 必须为 1');
  if (!stableId.test(m.pluginId || '')) errors.push('pluginId 不合法');
  if (typeof m.name !== 'string' || !m.name.trim()) errors.push('name 不能为空');
  if (!semver.test(m.version || '')) errors.push('version 必须是 SemVer');
  if (!/^\d+\.\d+$/.test(m.sdkVersion || '')) errors.push('sdkVersion 格式应为 1.0');
  if (!['fishreader-js', 'fishreader-html', 'legado-compat'].includes(sourceFormat)) errors.push('sourceFormat 不合法');
  if (!Array.isArray(m.entrypoints) || m.entrypoints.length < 1) errors.push('entrypoints 必须是非空数组');
  if (Array.isArray(m.entrypoints) && new Set(m.entrypoints).size !== m.entrypoints.length) errors.push('entrypoints 不能重复');
  if (Array.isArray(m.entrypoints)) {
    for (const name of m.entrypoints) if (!publicEntrypoints.has(name)) errors.push(`入口 ${name} 未在 0.3.5 第三方规范中公开`);
  }
  const kinds = Array.isArray(m.pluginKinds) && m.pluginKinds.length ? m.pluginKinds : ['source'];
  for (const kind of kinds) if (!publicKinds.has(kind)) errors.push(`插件类型 ${kind} 未在 0.3.5 第三方规范中公开`);
  const required = [];
  if (kinds.includes('source')) required.push('search', 'detail', 'catalog', 'content');
  if (kinds.includes('dictionary')) required.push('dictionary');
  if (kinds.includes('tts')) required.push('ttsVoices', 'ttsSynthesize');
  for (const name of required) if (!m.entrypoints?.includes(name)) errors.push(`缺少必需入口 ${name}`);
  if (!m.permissions || !Array.isArray(m.permissions.networkDomains)) errors.push('permissions.networkDomains 必须是数组');
  for (const field of ['networkDomains', 'redirectDomains']) {
    const values = m.permissions?.[field] || [];
    if (!Array.isArray(values)) errors.push(`permissions.${field} 必须是数组`);
    else {
      if (new Set(values).size !== values.length) errors.push(`permissions.${field} 不能重复`);
      for (const value of values) if (typeof value !== 'string' || !domain.test(value)) errors.push(`非法域名：${value}`);
    }
  }
  if (m.permissions?.loginBrowser === true && (m.permissions.cookieScope !== true || !m.loginUrl)) {
    errors.push('loginBrowser 需要 cookieScope: true 和 loginUrl');
  }
  if (m.loginUrl && !/^https?:\/\//i.test(m.loginUrl)) errors.push('loginUrl 必须是 HTTP(S) 绝对地址');
  if (m.loginUrl && Array.isArray(m.permissions?.networkDomains)) {
    try {
      const host = new URL(m.loginUrl).hostname.toLowerCase();
      const allowed = m.permissions.networkDomains.some(rule => {
        const value = String(rule).toLowerCase();
        return value.startsWith('*.')
          ? host === value.slice(2) || host.endsWith('.' + value.slice(2))
          : host === value;
      });
      if (!allowed) errors.push('loginUrl 域名必须包含在 permissions.networkDomains 中');
    } catch (_) {}
  }
  if (m.contentHash !== undefined) {
    const actualHash = typeof pkg.source === 'string'
      ? 'sha256:' + crypto.createHash('sha256').update(pkg.source, 'utf8').digest('hex')
      : '';
    if (m.contentHash !== actualHash) errors.push('manifest.contentHash 与主模块不一致');
  }
  if (Array.isArray(m.exploreCategories) && m.exploreCategories.length > 0 && !m.entrypoints?.includes('explore')) {
    errors.push('exploreCategories 需要 explore 入口');
  }
  if (m.exploreCategories !== undefined && !Array.isArray(m.exploreCategories)) {
    errors.push('exploreCategories 必须是数组');
  }
  if (Array.isArray(m.exploreCategories)) {
    if (m.exploreCategories.length < 1 || m.exploreCategories.length > 64) errors.push('exploreCategories 必须有 1 到 64 项');
    const categoryKeys = m.exploreCategories.map(value => value && value.key);
    if (new Set(categoryKeys).size !== categoryKeys.length) errors.push('exploreCategories.key 不能重复');
  }
  if (m.entrypoints?.includes('ui') && !m.managementModule) {
    errors.push('ui 入口需要 managementModule');
  }
  if (m.managementModule && (!m.entrypoints?.includes('ui') || !pkg.modules?.[m.managementModule])) {
    errors.push('managementModule 需要 ui 入口，并在 modules 中包含对应 HTML');
  }
  if (sourceFormat === 'fishreader-html' && !m.entrypoints?.includes('ui')) {
    errors.push('fishreader-html 插件必须声明 ui 入口');
  }
  if (sourceFormat === 'fishreader-html' && (m.entrypoints?.length !== 1 || m.entrypoints[0] !== 'ui')) {
    errors.push('fishreader-html 只允许 ui 入口');
  }
  if (sourceFormat === 'fishreader-html' && m.managementModule) {
    errors.push('fishreader-html 不使用 managementModule');
  }
  if (sourceFormat === 'fishreader-html' && !/\.html?$/i.test(m.entryModule || '')) {
    errors.push('fishreader-html 的 entryModule 必须指向 HTML 文件');
  }
  if (sourceFormat !== 'fishreader-html' && !/\.m?js$/i.test(m.entryModule || '')) {
    errors.push('JavaScript 插件的 entryModule 必须指向 .js 或 .mjs 文件');
  }
  for (const [field, value] of [['entryModule', m.entryModule], ['managementModule', m.managementModule]]) {
    if (value === undefined && field === 'managementModule') continue;
    if (typeof value !== 'string' || value.length > 512 || !modulePath.test(value) ||
        value.startsWith('/') || value.includes('\\') || value.split('/').includes('..')) {
      errors.push(`${field} 路径不合法`);
    }
  }
  if (m.managementModule && m.managementModule === m.entryModule) errors.push('managementModule 不能与 entryModule 相同');
  if (pkg.modules && typeof pkg.modules === 'object') {
    for (const [name, value] of Object.entries(pkg.modules)) {
      if (typeof value !== 'string') errors.push(`模块 ${name} 不是字符串`);
      else if (Buffer.byteLength(value, 'utf8') > 4 * 1024 * 1024) errors.push(`模块 ${name} 超过 4 MiB`);
    }
  }

  if (typeof pkg.source === 'string' && sourceFormat !== 'fishreader-html') {
    const moduleObject = { exports: {} };
    try {
      vm.runInNewContext(pkg.source, {
        module: moduleObject,
        exports: moduleObject.exports,
        reader: Object.freeze({}),
        URL,
        TextEncoder,
        TextDecoder,
        console: Object.freeze({ log() {}, warn() {}, error() {} })
      }, { timeout: 1000, filename: m.entryModule || 'plugin.js' });
      for (const name of m.entrypoints || []) {
        if (['ui'].includes(name)) continue;
        if (typeof moduleObject.exports[name] !== 'function') errors.push(`源码未导出函数 ${name}`);
      }
    } catch (error) {
      errors.push('主模块加载失败：' + error.message);
    }
  }
}

for (const warning of warnings) console.warn('警告：' + warning);
if (errors.length) {
  for (const error of errors) console.error('错误：' + error);
  process.exit(1);
}
console.log(`校验通过：${filePath}`);
