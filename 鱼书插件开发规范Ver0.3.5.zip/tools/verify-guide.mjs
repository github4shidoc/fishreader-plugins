import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function run(script, args = []) {
  const result = spawnSync(process.execPath, [path.join(root, script), ...args], {
    cwd: root,
    encoding: 'utf8'
  });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${script} 失败`);
}

const files = walk(root);
for (const file of files.filter(file => file.endsWith('.json'))) {
  JSON.parse(fs.readFileSync(file, 'utf8'));
}

for (const file of files.filter(file => file.endsWith('.schema.json'))) {
  const schema = JSON.parse(fs.readFileSync(file, 'utf8'));
  const visit = value => {
    if (!value || typeof value !== 'object') return;
    if (typeof value.pattern === 'string') new RegExp(value.pattern);
    for (const child of Object.values(value)) visit(child);
  };
  visit(schema);
}

const relativeNames = files.map(file => path.relative(root, file).replaceAll('\\', '/'));
if (relativeNames.some(name => /(^|\/)theme(?:[-./]|$)/i.test(name))) {
  throw new Error('开发包中不应包含主题插件文件');
}

for (const script of [
  'examples/source-basic/smoke-test.mjs',
  'examples/source-network/smoke-test.mjs',
  'examples/dictionary-basic/smoke-test.mjs',
  'examples/tts-basic/smoke-test.mjs'
]) run(script);

for (const file of relativeNames.filter(name => name.startsWith('dist/') && name.endsWith('.fishplugin.json'))) {
  run('tools/validate-package.mjs', [file]);
}

console.log(`开发包自检通过：${relativeNames.length} 个文件`);
