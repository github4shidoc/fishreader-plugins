import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import crypto from 'node:crypto';

const [directoryArg, outputArg] = process.argv.slice(2);
if (!directoryArg) {
  console.error('用法：node tools/build-plugin.mjs <插件目录> [输出文件]');
  process.exit(2);
}

const directory = path.resolve(directoryArg);
const manifestPath = path.join(directory, 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

function modulePath(name) {
  if (typeof name !== 'string' || !name || name.startsWith('/') || name.includes('\\') || name.split('/').includes('..')) {
    throw new Error(`非法模块路径：${String(name)}`);
  }
  const resolved = path.resolve(directory, name);
  if (resolved !== directory && !resolved.startsWith(directory + path.sep)) {
    throw new Error(`模块路径越界：${name}`);
  }
  return resolved;
}

const sourcePath = modulePath(manifest.entryModule || 'index.js');
const source = fs.readFileSync(sourcePath, 'utf8');
manifest.contentHash = 'sha256:' + crypto.createHash('sha256').update(source, 'utf8').digest('hex');
const modules = {};

if (manifest.managementModule) {
  modules[manifest.managementModule] = fs.readFileSync(
    modulePath(manifest.managementModule), 'utf8'
  );
}

const pluginPackage = { schemaVersion: 1, manifest, source };
if (Object.keys(modules).length > 0) pluginPackage.modules = modules;

const output = JSON.stringify(pluginPackage, null, 2) + '\n';
const bytes = Buffer.byteLength(output, 'utf8');
if (Buffer.byteLength(source, 'utf8') > 4 * 1024 * 1024) {
  throw new Error('主模块超过 4 MiB');
}
for (const [name, value] of Object.entries(modules)) {
  if (Buffer.byteLength(value, 'utf8') > 4 * 1024 * 1024) {
    throw new Error(`${name} 超过 4 MiB`);
  }
}
if (bytes > 5 * 1024 * 1024) throw new Error('插件包超过 5 MiB');

const fallback = path.join(directory, `${manifest.pluginId || 'plugin'}-${manifest.version || '0.0.0'}.fishplugin.json`);
const outputPath = path.resolve(outputArg || fallback);
fs.writeFileSync(outputPath, output, 'utf8');
console.log(`已生成：${outputPath} (${bytes} bytes)`);
