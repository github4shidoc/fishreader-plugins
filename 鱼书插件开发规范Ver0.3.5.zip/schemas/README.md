# Schema 使用说明

这里的 Schema 只覆盖鱼书 0.3.5 对第三方公开的书源、字典和 TTS 插件契约，不包含尚未完成的主题插件。

- `plugin/plugin-package.schema.json`：插件包顶层结构。
- `common.schema.json`：各 Schema 共用的基础定义。
- `plugin/source-plugin-manifest.schema.json`：Manifest。
- `plugin/*-result.schema.json`：各入口返回值。
- `plugin/execution-request.schema.json`：宿主执行入口时的请求。
- `plugin/execution-result.schema.json`：统一执行结果外壳。
- `plugin/host-call.schema.json`：宿主桥接调用结构。

Schema 用于编辑器提示、CI 和静态校验；业务上还要遵守 `docs/` 中的跨入口约束，例如 `bookKey`、`chapterKey` 稳定性和媒体类型一致性。

如果 Schema 与目标鱼书版本冲突，以该版本应用随附的 Schema 为准，不要根据错误信息随意放宽字段。
