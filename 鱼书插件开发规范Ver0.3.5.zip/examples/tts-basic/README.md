# TTS 插件模板

这是一个带管理页面的可配置模板。导入后打开插件页面，填写已获授权的 TTS 地址、方法、请求头和正文模板，并按页面提示授权域名。

构建和检查：

```bash
node tools/build-plugin.mjs examples/tts-basic dist/fishreader-tts-template.fishplugin.json
node examples/tts-basic/smoke-test.mjs
node tools/validate-package.mjs dist/fishreader-tts-template.fishplugin.json
```

模板占位符支持文字、声音和速度。发布正式插件时应改 `pluginId`、名称和版本，限制可配置内容，不要把账号令牌打入包中。

TTS 只服务文字阅读页朗读，不是有声书播放器接口。
