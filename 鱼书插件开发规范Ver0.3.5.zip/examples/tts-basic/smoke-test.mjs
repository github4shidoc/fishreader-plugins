import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const config = {
  url: 'https://tts.example.com/speak?q={text}&voice={voiceKey}&speed={speed}',
  method: 'GET',
  voiceKey: 'female-1',
  voiceName: '女声一',
  locale: 'zh-CN',
  headers: { Referer: 'https://tts.example.com/' },
  body: '',
  contentType: 'audio/mpeg'
};
const moduleObject = { exports: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'main.js'), 'utf8'), {
  module: moduleObject,
  exports: moduleObject.exports,
  reader: Object.freeze({ storage: Object.freeze({ get: async () => config }) })
});

assert.equal(typeof moduleObject.exports.ttsVoices, 'function');
assert.equal(typeof moduleObject.exports.ttsSynthesize, 'function');
const voices = await moduleObject.exports.ttsVoices({});
assert.equal(voices[0].voiceKey, 'female-1');
const request = await moduleObject.exports.ttsSynthesize({
  text: '你好，鱼书',
  voiceKey: 'female-1',
  speed: 1,
  pitch: 1
});
assert.match(request.url, /%E4%BD%A0%E5%A5%BD/);
assert.match(request.url, /voice=female-1/);
assert.equal(request.method, 'GET');
console.log('tts-basic smoke test: OK');
