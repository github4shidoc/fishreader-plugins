'use strict';

const CONFIG_KEY = 'tts.config';

function text(value) {
  return typeof value === 'string' ? value : '';
}

function replacementValue(name, input) {
  if (/^voiceKey$/i.test(name)) return text(input.voiceKey);
  if (/^(?:speed|speakSpeed)$/i.test(name)) return String(input.speed);
  return text(input.text);
}

function replace(template, input, encode) {
  return text(template)
    .replace(/\{\{\s*(?:java\.)?(?:encodeURI|encodeURIComponent)\s*\(\s*(text|speakText|voiceKey)\s*\\?\)\s*\}\}/gi,
      (_match, name) => encodeURIComponent(replacementValue(name, input)))
    .replace(/\{\{\s*(text|speakText|speed|speakSpeed|voiceKey)\s*\}\}/gi,
      (_match, name) => encode ? encodeURIComponent(replacementValue(name, input)) :
        replacementValue(name, input))
    .replace(/\{(text|speakText|speed|speakSpeed|voiceKey)\}/gi,
      (_match, name) => encode ? encodeURIComponent(replacementValue(name, input)) :
        replacementValue(name, input))
    .replace(/\$(?:\{)?(text|speakText|speed|speakSpeed|voiceKey)(?:\})?/gi,
      (_match, name) => encode ? encodeURIComponent(replacementValue(name, input)) :
        replacementValue(name, input));
}

async function loadConfig() {
  const value = await reader.storage.get(CONFIG_KEY);
  if (!value || typeof value !== 'object') return null;
  return value;
}

module.exports.ttsVoices = async function () {
  const config = await loadConfig();
  return [{
    voiceKey: text(config && config.voiceKey) || 'default',
    name: text(config && config.voiceName) || 'TTS 模板音色',
    locale: text(config && config.locale) || 'zh-CN',
    description: config ? '已配置网络接口' : '请先打开插件页面配置接口'
  }];
};

module.exports.ttsSynthesize = async function (input) {
  const config = await loadConfig();
  if (!config || !/^https?:\/\//i.test(text(config.url))) {
    throw new Error('请先打开插件页面配置 TTS 接口');
  }
  const rawHeaders = config.headers && typeof config.headers === 'object' ? config.headers : {};
  const headers = {};
  Object.keys(rawHeaders).forEach((name) => {
    headers[name] = replace(String(rawHeaders[name]), input, false);
  });
  return {
    url: replace(config.url, input, true),
    method: text(config.method).toUpperCase() || 'GET',
    headers,
    body: replace(config.body, input, false),
    contentType: text(config.contentType) || 'audio/mpeg',
    cacheKey: `${input.voiceKey}:${input.speed}:${input.text}`
  };
};
