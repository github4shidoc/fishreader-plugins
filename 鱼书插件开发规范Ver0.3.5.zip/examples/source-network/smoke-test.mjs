import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const htmlByPath = new Map([
  ['/search', '<article class="book" data-id="1"><a class="title" href="/book/1">网络示例书</a><span class="author">示例作者</span><img src="/cover.jpg"></article>'],
  ['/category/hot', '<article class="book" data-id="1"><a class="title" href="/book/1">网络示例书</a><span class="author">示例作者</span><img src="/cover.jpg"></article>'],
  ['/book/1', '<h1>网络示例书</h1><span class="author">示例作者</span><p class="intro">简介</p><img class="cover" src="/cover.jpg"><a class="chapters" href="/book/1/chapters">目录</a>'],
  ['/book/1/chapters', '<div class="chapter"><a href="/chapter/1">第一章</a></div>'],
  ['/chapter/1', '<article class="content">第一段 第二段</article>']
]);

function select(request) {
  const html = request.html;
  const values = {
    '.book@data-id': [...html.matchAll(/<article[^>]*data-id="([^"]+)"/g)].map(match => match[1]),
    '.book .title@text': [...html.matchAll(/class="title"[^>]*>([^<]+)/g)].map(match => match[1]),
    '.book .author@text': [...html.matchAll(/class="author"[^>]*>([^<]+)/g)].map(match => match[1]),
    '.book .title@href': [...html.matchAll(/class="title"[^>]*href="([^"]+)"/g)].map(match => match[1]),
    '.book img@src': [...html.matchAll(/<img[^>]*src="([^"]+)"/g)].map(match => match[1]),
    'h1@text': html.match(/<h1>([^<]+)/)?.[1] || null,
    '.author@text': html.match(/class="author"[^>]*>([^<]+)/)?.[1] || null,
    '.intro@text': html.match(/class="intro"[^>]*>([^<]+)/)?.[1] || null,
    '.cover@src': html.match(/class="cover"[^>]*src="([^"]+)"/)?.[1] || null,
    '.chapters@href': html.match(/class="chapters"[^>]*href="([^"]+)"/)?.[1] || null,
    '.chapter a@text': [...html.matchAll(/class="chapter"[^>]*>\s*<a[^>]*>([^<]+)/g)].map(match => match[1]),
    '.chapter a@href': [...html.matchAll(/class="chapter"[^>]*>\s*<a[^>]*href="([^"]+)"/g)].map(match => match[1]),
    '.content@text': html.match(/class="content"[^>]*>([^<]+)/)?.[1] || null
  };
  const suffix = request.value === 'attribute' ? '@' + request.attribute : '@text';
  return values[request.selector + suffix] ?? (request.all ? [] : null);
}

const reader = {
  http: { fetch: async request => {
    const url = new URL(request.url);
    const body = htmlByPath.get(url.pathname);
    if (!body) return { status: 404, url: request.url, headers: {}, body: '' };
    return { status: 200, url: request.url, headers: { 'content-type': 'text/html' }, body };
  } },
  html: {
    parse: async selectRequest => select(selectRequest),
    parseBatch: async ({ requests }) => requests.map(select)
  }
};

const source = fs.readFileSync(new URL('index.js', import.meta.url), 'utf8');
const moduleObject = { exports: {} };
vm.runInNewContext(source, { module: moduleObject, exports: moduleObject.exports, reader, URL, encodeURIComponent }, { timeout: 5000 });
const api = moduleObject.exports;
const books = await api.search({ keyword: '示例', page: 1 });
assert.equal(books.length, 1);
const detail = await api.detail(books[0]);
assert.equal(detail.title, '网络示例书');
const catalog = await api.catalog(detail);
assert.equal(catalog.length, 1);
const content = await api.content({ ...catalog[0], bookKey: detail.bookKey });
assert.equal(content.contentType, 'text');
assert.ok(content.content.includes('第一段'));
const explore = await api.explore({ category: 'hot', page: 1 });
assert.equal(explore.length, 1);
console.log('Network source smoke test: OK');
