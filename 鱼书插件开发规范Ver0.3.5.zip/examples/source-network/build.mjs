import fs from 'node:fs';
import crypto from 'node:crypto';

const base = new URL('./', import.meta.url);
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', base), 'utf8'));
const source = fs.readFileSync(new URL(manifest.entryModule, base), 'utf8');
manifest.contentHash = 'sha256:' + crypto.createHash('sha256').update(source, 'utf8').digest('hex');
const output = JSON.stringify({ schemaVersion: 1, manifest, source }, null, 2) + '\n';
if (Buffer.byteLength(source, 'utf8') > 4 * 1024 * 1024) throw new Error('主模块超过 4 MiB');
if (Buffer.byteLength(output, 'utf8') > 5 * 1024 * 1024) throw new Error('插件包超过 5 MiB');
fs.writeFileSync(new URL('fishreader-network-source.fishplugin.json', base), output, 'utf8');
console.log('已生成 fishreader-network-source.fishplugin.json');
