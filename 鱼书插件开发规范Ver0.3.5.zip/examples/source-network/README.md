# 网络书源模板

演示 `reader.http.fetch`、`reader.html.parseBatch`、相对 URL 处理、搜索、发现、详情、目录和正文。

`api.example.com` 是占位域名，真机不会提供示例数据；本地 smoke test 使用模拟响应：

```bash
node build.mjs
node smoke-test.mjs
```

开发时替换 `ORIGIN`、选择器和解析逻辑，同时修改 Manifest 的最小域名权限。不要保留占位域名发布。
