'use strict';

const ORIGIN = 'https://api.example.com';

function absoluteUrl(value, base) {
  if (!value) return '';
  try { return new URL(String(value), base).toString(); } catch (_) { return ''; }
}

async function request(url) {
  const response = await reader.http.fetch({
    url,
    method: 'GET',
    headers: { Accept: 'text/html,application/xhtml+xml' },
    charset: 'utf-8',
    timeoutMs: 30000
  });
  if (response.status < 200 || response.status >= 300) {
    throw new Error(`HTTP ${response.status}: ${url}`);
  }
  return response;
}

async function parseMany(html, definitions) {
  return await reader.html.parseBatch({
    requests: definitions.map(definition => ({ html, all: true, limit: 500, ...definition }))
  });
}

async function parseList(url) {
  const response = await request(url);
  const [ids, titles, authors, links, covers] = await parseMany(response.body, [
    { selector: '.book', value: 'attribute', attribute: 'data-id' },
    { selector: '.book .title', value: 'text' },
    { selector: '.book .author', value: 'text' },
    { selector: '.book .title', value: 'attribute', attribute: 'href' },
    { selector: '.book img', value: 'attribute', attribute: 'src' }
  ]);
  const count = Math.min(ids.length, titles.length, links.length);
  const books = [];
  for (let index = 0; index < count; index++) {
    const title = String(titles[index] || '').trim();
    if (!title) continue;
    books.push({
      bookKey: 'example:' + String(ids[index] || links[index]),
      title,
      author: String(authors[index] || '').trim(),
      bookUrl: absoluteUrl(links[index], response.url),
      coverUrl: absoluteUrl(covers[index], response.url),
      mediaType: 'text'
    });
  }
  return books;
}

module.exports.search = async function ({ keyword, page }) {
  if (!String(keyword || '').trim() || page < 1) return [];
  return parseList(`${ORIGIN}/search?q=${encodeURIComponent(keyword)}&page=${page}`);
};

module.exports.exploreMenu = async function () {
  return [{ key: 'hot', title: '热门', group: '推荐' }];
};

module.exports.explore = async function ({ category, page }) {
  return parseList(`${ORIGIN}/category/${encodeURIComponent(category)}?page=${page}`);
};

module.exports.detail = async function (input) {
  const response = await request(input.bookUrl);
  const [title, author, intro, cover, toc] = await reader.html.parseBatch({ requests: [
    { html: response.body, selector: 'h1', value: 'text' },
    { html: response.body, selector: '.author', value: 'text' },
    { html: response.body, selector: '.intro', value: 'text' },
    { html: response.body, selector: '.cover', value: 'attribute', attribute: 'src' },
    { html: response.body, selector: '.chapters', value: 'attribute', attribute: 'href' }
  ] });
  return {
    bookKey: input.bookKey,
    title: String(title || input.title || '').trim(),
    author: String(author || input.author || '').trim(),
    intro: String(intro || '').trim(),
    coverUrl: absoluteUrl(cover, response.url),
    bookUrl: response.url,
    tocUrl: absoluteUrl(toc, response.url),
    mediaType: 'text'
  };
};

module.exports.catalog = async function (input) {
  const response = await request(input.tocUrl || input.bookUrl);
  const [titles, links] = await parseMany(response.body, [
    { selector: '.chapter a', value: 'text' },
    { selector: '.chapter a', value: 'attribute', attribute: 'href' }
  ]);
  const count = Math.min(titles.length, links.length);
  return Array.from({ length: count }, (_, index) => ({
    chapterKey: input.bookKey + ':chapter:' + absoluteUrl(links[index], response.url),
    title: String(titles[index] || '').trim(),
    ordinal: index,
    chapterUrl: absoluteUrl(links[index], response.url),
    isVolume: false,
    isLocked: false,
    mediaType: 'text'
  }));
};

module.exports.content = async function (input) {
  const response = await request(input.chapterUrl);
  const content = await reader.html.parse({
    html: response.body,
    selector: '.content',
    value: 'text',
    all: false,
    limit: 1
  });
  if (!String(content || '').trim()) throw new Error('正文为空');
  return { contentType: 'text', content: String(content).trim(), baseUrl: response.url };
};
