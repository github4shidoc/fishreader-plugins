import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const moduleObject = { exports: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'main.js'), 'utf8'), {
  module: moduleObject,
  exports: moduleObject.exports
});

assert.equal(typeof moduleObject.exports.dictionary, 'function');
const result = await moduleObject.exports.dictionary({ word: '鱼书', context: '' });
assert.equal(result.title, '示例字典');
assert.match(result.text, /FishReader/);
console.log('dictionary-basic smoke test: OK');
