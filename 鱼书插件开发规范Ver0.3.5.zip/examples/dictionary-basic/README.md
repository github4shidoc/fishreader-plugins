# 字典插件示例

无网络示例，内置“鱼书”“阅读”“插件”三个词条。

从开发包根目录构建和检查：

```bash
node tools/build-plugin.mjs examples/dictionary-basic dist/fishreader-dictionary-example.fishplugin.json
node examples/dictionary-basic/smoke-test.mjs
node tools/validate-package.mjs dist/fishreader-dictionary-example.fishplugin.json
```

接入网络词典时，增加最小 `networkDomains`，并在 `dictionary` 入口中通过 `reader.http.fetch` 获取后返回纯文本或受限 HTML。
