'use strict';

const ENTRIES = {
  '鱼书': 'FishReader 的中文名称。',
  '阅读': '获取、理解并使用文字信息的过程。',
  '插件': '在受限接口范围内扩展宿主功能的独立模块。'
};

module.exports.dictionary = async function ({ word, context }) {
  const key = String(word || context || '').trim();
  const explanation = ENTRIES[key] || `“${key}”暂未收录。你可以在 main.js 中接入获授权的词典服务。`;
  return {
    title: '示例字典',
    text: `${key}\n${explanation}`
  };
};
