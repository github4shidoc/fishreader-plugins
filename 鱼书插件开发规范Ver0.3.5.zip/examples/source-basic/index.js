'use strict';

const ITEM_KEY = 'org.example.fishreader.quickstart:item:1';
const CHAPTER_KEY = 'org.example.fishreader.quickstart:item:1:chapter:1';

module.exports.search = async function ({ page }) {
  if (page !== 1) return [];
  return [{
    bookKey: ITEM_KEY,
    title: '示例内容',
    author: '示例作者',
    intro: '用于验证插件安装和四个必需入口。',
    latestChapter: '第 1 章'
  }];
};

module.exports.detail = async function ({ bookKey }) {
  return {
    bookKey: bookKey || ITEM_KEY,
    title: '示例内容',
    author: '示例作者',
    intro: '这是一个不访问网络的最小可运行示例。'
  };
};

module.exports.catalog = async function () {
  return [{
    chapterKey: CHAPTER_KEY,
    title: '第一章',
    ordinal: 0,
    isVolume: false,
    isLocked: false
  }];
};

module.exports.content = async function () {
  return {
    contentType: 'text',
    content: '如果你能看到这段文字，说明插件的检索、详情、目录和正文入口已经连通。'
  };
};
