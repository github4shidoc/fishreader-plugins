import fs from 'node:fs';
import crypto from 'node:crypto';

const directory = new URL('./', import.meta.url);
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', directory), 'utf8'));
const source = fs.readFileSync(new URL('index.js', directory), 'utf8');
manifest.contentHash = 'sha256:' + crypto.createHash('sha256').update(source, 'utf8').digest('hex');
const requiredEntrypoints = ['search', 'detail', 'catalog', 'content'];

if (manifest.schemaVersion !== 1) throw new Error('manifest.schemaVersion must be 1');
if (manifest.sourceFormat !== 'fishreader-js') throw new Error('sourceFormat must be fishreader-js');
if (!Array.isArray(manifest.entrypoints) ||
    requiredEntrypoints.some((name) => !manifest.entrypoints.includes(name))) {
  throw new Error('required entrypoint is missing');
}
if (!Array.isArray(manifest.permissions?.networkDomains)) {
  throw new Error('permissions.networkDomains must be an array');
}
if (Buffer.byteLength(source, 'utf8') > 4 * 1024 * 1024) {
  throw new Error('entry module exceeds 4 MiB');
}

const pluginPackage = {
  schemaVersion: 1,
  manifest,
  source
};
const output = `${JSON.stringify(pluginPackage, null, 2)}\n`;
if (Buffer.byteLength(output, 'utf8') > 5 * 1024 * 1024) {
  throw new Error('plugin package exceeds 5 MiB');
}

const outputUrl = new URL('fishreader-quickstart.fishplugin.json', directory);
fs.writeFileSync(outputUrl, output, 'utf8');
console.log(`Created ${outputUrl.pathname}`);
