import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const packageUrl = new URL('fishreader-quickstart.fishplugin.json', import.meta.url);
const bytes = fs.readFileSync(packageUrl);
const pluginPackage = JSON.parse(bytes.toString('utf8'));

assert.ok(bytes.length > 0 && bytes.length <= 5 * 1024 * 1024);
assert.equal(pluginPackage.schemaVersion, 1);
assert.equal(pluginPackage.manifest.schemaVersion, 1);

const moduleObject = { exports: {} };
vm.runInNewContext(pluginPackage.source, {
  module: moduleObject,
  exports: moduleObject.exports
}, { timeout: 5_000 });

const api = moduleObject.exports;
for (const name of ['search', 'detail', 'catalog', 'content']) {
  assert.equal(typeof api[name], 'function', `${name} must be a function`);
}

const summaries = await api.search({ keyword: '示例', page: 1 });
assert.ok(Array.isArray(summaries) && summaries.length === 1);
assert.equal(typeof summaries[0].bookKey, 'string');
assert.equal(typeof summaries[0].title, 'string');

const detail = await api.detail({ bookKey: summaries[0].bookKey, bookUrl: '' });
assert.equal(detail.bookKey, summaries[0].bookKey);
assert.equal(typeof detail.title, 'string');

const chapters = await api.catalog({
  bookKey: detail.bookKey,
  bookUrl: detail.bookUrl || '',
  tocUrl: detail.tocUrl || ''
});
assert.ok(Array.isArray(chapters) && chapters.length === 1);
assert.equal(chapters[0].ordinal, 0);

const content = await api.content({
  bookKey: detail.bookKey,
  chapterKey: chapters[0].chapterKey,
  chapterUrl: chapters[0].chapterUrl || ''
});
assert.equal(content.contentType, 'text');
assert.ok(typeof content.content === 'string' && content.content.length > 0);

console.log('Quickstart plugin smoke test: OK');
