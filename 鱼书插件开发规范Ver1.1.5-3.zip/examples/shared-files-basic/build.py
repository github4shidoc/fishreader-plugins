"""Build the standalone shared-file bridge example."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / "shared-files-basic.fishweb"
FILES = ("index.html", "shared-files.json", "app.mjs", "fish-shared-files.mjs")
with ZipFile(TARGET, "w", compression=ZIP_DEFLATED) as archive:
    for name in FILES:
        archive.write(ROOT / name, name)
print(TARGET)
