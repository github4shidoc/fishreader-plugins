import { openSharedDirectory } from './fish-shared-files.mjs';

const buttons = Object.fromEntries(['open', 'write', 'read', 'close']
  .map(id => [id, document.getElementById(id)]));
const output = document.getElementById('output');
let session;

function show(value) { output.textContent = String(value); }
function refresh() {
  buttons.open.disabled = !!session;
  for (const name of ['write', 'read', 'close']) buttons[name].disabled = !session;
}
function close() {
  session?.client.close();
  session = undefined;
  try { globalThis.FishSharedFiles?.close(); } catch (_) {}
  refresh();
}
async function run(action) {
  try { await action(); } catch (error) { show(error); }
}
buttons.open.addEventListener('click', () => run(async () => {
  if (!globalThis.FishSharedFiles?.open) throw new Error('当前环境没有共享文件接口');
  session = await openSharedDirectory();
  show('已打开命名空间：' + session.client.namespace);
  refresh();
}));
buttons.write.addEventListener('click', () => run(async () => {
  const file = await session.root.getFileHandle('note.txt', { create: true });
  const writer = await file.createWritable({ durable: true });
  try {
    await writer.write('鱼书共享文件示例\n');
    await writer.close();
  } catch (error) {
    await writer.abort();
    throw error;
  }
  show('note.txt 已提交');
}));
buttons.read.addEventListener('click', () => run(async () => {
  const file = await session.root.getFileHandle('note.txt');
  const snapshot = await file.getFile();
  show(await snapshot.text());
}));
buttons.close.addEventListener('click', () => { close(); show('已关闭'); });
window.addEventListener('pagehide', close);
refresh();
