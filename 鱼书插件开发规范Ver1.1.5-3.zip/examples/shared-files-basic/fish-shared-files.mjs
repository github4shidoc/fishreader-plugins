/** Generic FishReader shared application files. Binary data never uses JSON. */
const encode=new TextEncoder(),decode=new TextDecoder();
const segment=name=>{if(typeof name!=='string'||!name||name==='.'||name==='..'||/[\\/\0:]/.test(name))throw Error('Invalid shared file name');return name;};
const join=(path,name)=>path?path+'/'+segment(name):segment(name);
const absolute=path=>{if(typeof path!=='string'||path.split('/').some(n=>{try{segment(n);return false;}catch{return true;}}))throw Error('Invalid shared path');return path;};
const collect=new FinalizationRegistry(({client,id})=>client.queueRelease(id));
class Snapshot {
  constructor(client,value){this.client=client;this.id=value.handle;this.size=value.size;this.lastModified=value.lastModified;collect.register(this,{client,id:this.id});}
}
export class SharedFileClient {
  constructor(port,{forwarded=false}={}){
    this.port=port;this.forwarded=forwarded;this.pending=new Map();this.id=0;this.closed=false;this.brokers=new Set();this.brokerPeers=new WeakMap();
    this.releaseQueue=[];this.releaseHead=0;this.releaseActive=0;
    this.ready=new Promise((resolve,reject)=>{this.resolveReady=resolve;this.rejectReady=reject;});
    this.ready.catch(()=>{});this.readyTimer=setTimeout(()=>this.fail(Error('Shared-file initialization timeout')),15000);
    port.onmessage=event=>this.receive(event.data);port.onmessageerror=()=>this.fail(Error('Shared-file message decoding failed'));port.start?.();
  }
  receive(data){
    try{
      if(data instanceof ArrayBuffer){if(!this.binary)throw Error('Unexpected shared-file payload');const message=this.binary;this.binary=null;this.complete(message,data);return;}
      const message=typeof data==='string'?JSON.parse(data):data;
      if(message.type==='ready'){clearTimeout(this.readyTimer);this.namespace=message.namespace;this.path=message.path;this.maxChunkBytes=message.maxChunkBytes;this.resolveReady(message);return;}
      if(message.type==='error'){this.fail(Error(message.error));return;}
      if(message.buffer instanceof ArrayBuffer){this.complete(message,message.buffer);return;}
      if(message.payload){if(this.binary)throw Error('Shared-file payload ordering mismatch');this.binary=message;return;}
      this.complete(message);
    }catch(error){this.fail(error);}
  }
  complete(message,buffer){const pending=this.pending.get(message.id);if(!pending)throw Error('Unknown shared-file reply');
    if(buffer&&(!Number.isSafeInteger(message.value?.bytes)||message.value.bytes<0||message.value.bytes>buffer.byteLength))throw Error('Invalid shared-file binary reply');
    this.pending.delete(message.id);clearTimeout(pending.timer);
    if(message.error){const error=Error(message.error);error.name=message.name||'Error';pending.reject(error);return;}
    pending.resolve({value:message.value||{},bytes:buffer?new Uint8Array(buffer,0,message.value.bytes):null});
  }
  request(op,body={},payload){
    if(this.closed)return Promise.reject(Error('Shared-file session closed'));
    const id=++this.id,q={...body,id,op};let bytes;
    if(payload!==undefined){const view=ArrayBuffer.isView(payload)?new Uint8Array(payload.buffer,payload.byteOffset,payload.byteLength):new Uint8Array(payload);bytes=view.buffer instanceof ArrayBuffer&&view.byteOffset===0&&view.byteLength===view.buffer.byteLength?view.buffer:view.slice().buffer;q.payloadLength=bytes.byteLength;}
    return new Promise((resolve,reject)=>{const timer=setTimeout(()=>this.fail(Error('Shared-file request timeout: '+op)),60000);this.pending.set(id,{resolve,reject,timer});
      try{if(this.forwarded)this.port.postMessage({request:q,buffer:bytes});else{this.port.postMessage(JSON.stringify(q));if(bytes!==undefined)this.port.postMessage(bytes);}}
      catch(error){this.fail(error);}
    });
  }
  createWorkerPort(){
    const channel=new MessageChannel(),local=channel.port1;this.brokers.add(local);this.brokerPeers.set(channel.port2,local);
    local.onmessage=async({data})=>{try{const {request,buffer}=data;if(!request||!Number.isSafeInteger(request.id)||request.id<=0)throw Error('Invalid shared-file Worker request');const {id,op,...body}=request;
      const result=await this.request(op,body,buffer);const bytes=result.bytes;
      local.postMessage({id,value:result.value,...(bytes?{buffer:bytes.buffer}:{})},bytes?[bytes.buffer]:[]);
    }catch(error){local.postMessage({id:data.request?.id,error:String(error),name:error.name});}};
    local.start();local.postMessage({type:'ready',namespace:this.namespace,path:this.path,maxChunkBytes:this.maxChunkBytes});return channel.port2;
  }
  releaseWorkerPort(port){const local=this.brokerPeers.get(port);if(local){local.close();this.brokers.delete(local);this.brokerPeers.delete(port);}}
  queueRelease(handle){if(this.closed)return;this.releaseQueue.push(handle);this.pumpReleases();}
  pumpReleases(){
    while(!this.closed&&this.releaseActive<4&&this.releaseHead<this.releaseQueue.length){const handle=this.releaseQueue[this.releaseHead++];this.releaseActive++;this.request('release',{handle}).catch(()=>{}).finally(()=>{this.releaseActive--;this.pumpReleases();});}
    if(this.releaseHead===this.releaseQueue.length){this.releaseQueue.length=0;this.releaseHead=0;}
  }
  fail(error){if(this.closed)return;this.closed=true;this.releaseQueue.length=0;this.releaseHead=0;clearTimeout(this.readyTimer);this.rejectReady(error);for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(error);}this.pending.clear();this.port.close();for(const p of this.brokers)p.close();this.brokers.clear();}
  close(){this.fail(Error('Shared-file session closed'));}
  handle(descriptor){if(descriptor?.namespace!==this.namespace||!['file','directory'].includes(descriptor.kind))throw Error('Invalid native shared-file descriptor');if(descriptor.path)absolute(descriptor.path);return descriptor.kind==='directory'?new SharedDirectory(this,descriptor.path):new SharedFile(this,descriptor.path);}
}
class SharedBlob {
  constructor(snapshot,start=0,end=snapshot.size){this.snapshot=snapshot;this.start=start;this.end=end;this.size=end-start;this.lastModified=snapshot.lastModified;this.type='';}
  slice(start=0,end=this.size){const normalize=n=>Math.max(0,Math.min(this.size,n<0?this.size+n:n));start=normalize(start);end=Math.max(start,normalize(end));return new SharedBlob(this.snapshot,this.start+start,this.start+end);}
  async readBytes(start=0,end=this.size){if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||end<start||end>this.size||end-start>this.snapshot.client.maxChunkBytes)throw Error('Shared-file chunk range invalid');return(await this.snapshot.client.request('read',{handle:this.snapshot.id,offset:this.start+start,length:end-start})).bytes;}
  async arrayBuffer(){if(this.size<=this.snapshot.client.maxChunkBytes){const bytes=await this.readBytes();return bytes.byteOffset===0&&bytes.byteLength===bytes.buffer.byteLength?bytes.buffer:bytes.slice().buffer;}const result=new Uint8Array(this.size);for(let at=0;at<this.size;){const b=await this.readBytes(at,Math.min(this.size,at+this.snapshot.client.maxChunkBytes));if(!b.length)throw Error('Incomplete shared file');result.set(b,at);at+=b.length;}return result.buffer;}
  async text(){return decode.decode(await this.arrayBuffer());}
  stream(){let at=0;return new ReadableStream({pull:async controller=>{if(at===this.size){controller.close();return;}const bytes=await this.readBytes(at,Math.min(this.size,at+this.snapshot.client.maxChunkBytes));if(!bytes.length)throw Error('Incomplete shared stream');at+=bytes.length;controller.enqueue(bytes);}});}
}
class SharedFile {
  constructor(client,path,metadata){this.client=client;this.path=path;this.kind='file';this.name=path.split('/').pop();this.metadata=metadata;}
  // Advisory directory/file-entry metadata; getFile() still takes a fresh
  // immutable snapshot. No extra native request and no changed read semantics.
  get listedMetadata(){const m=this.metadata;return Number.isSafeInteger(m?.size)&&m.size>=0&&Number.isFinite(m.lastModified)?{size:m.size,lastModified:m.lastModified}:null;}
  get nativeShared(){return {namespace:this.client.namespace,path:this.path,kind:'file'};}
  async getFile(){const snapshot=new Snapshot(this.client,(await this.client.request('file',{path:this.path,snapshot:true})).value);const file=new SharedBlob(snapshot);file.name=this.name;return file;}
  async createWritable(options={}){
    const client=this.client,handle=(await client.request('writeOpen',{path:this.path,durable:!!options.durable})).value.handle;let position=0,closed=false;
    const check=()=>{if(closed)throw Error('Shared writer closed');};
    const writeBytes=async data=>{const view=typeof data==='string'?encode.encode(data):ArrayBuffer.isView(data)?new Uint8Array(data.buffer,data.byteOffset,data.byteLength):new Uint8Array(data);
      for(let at=0;at<view.byteLength;){const chunk=view.subarray(at,Math.min(view.byteLength,at+client.maxChunkBytes)),length=chunk.byteLength,n=(await client.request('write',{handle,offset:position,length},chunk)).value.bytes;if(!Number.isInteger(n)||n<=0||n>length)throw Error('Incomplete shared write');position+=n;at+=n;}};
    const writer={async write(value){check();if(value?.type==='write'){if(value.position!==undefined)position=value.position;value=value.data;}if(position===0&&value instanceof SharedBlob&&value.snapshot.client===client&&value.start===0&&value.size===value.snapshot.size){position=(await client.request('copy',{handle,source:value.snapshot.id})).value.bytes;return;}if(value?.slice&&typeof value.arrayBuffer==='function'&&!ArrayBuffer.isView(value)){
          for(let at=0;at<value.size;){const end=Math.min(value.size,at+Math.min(8*1024*1024,client.maxChunkBytes));await writeBytes(await value.slice(at,end).arrayBuffer());at=end;}
        }else await writeBytes(value);},async truncate(n){check();await client.request('truncate',{handle,length:n});position=Math.min(position,n);},async flush(){check();await client.request('flush',{handle});},
      async close(){check();const value=(await client.request('commit',{handle,...(options.lastModified===undefined?{}:{mtime:options.lastModified})})).value;closed=true;return value;},async abort(){if(closed)return;closed=true;await client.request('abort',{handle});}};
    let tail=Promise.resolve(),closing=false;
    const schedule=fn=>{if(closing)return Promise.reject(Error('Shared writer closing'));return tail=tail.then(fn);};
    for(const name of ['write','truncate','flush']){const fn=writer[name];writer[name]=(...args)=>schedule(()=>fn(...args));}
    const close=writer.close,abort=writer.abort;
    writer.close=()=>{if(closing)return Promise.reject(Error('Shared writer closing'));closing=true;return tail=tail.then(close);};
    writer.abort=async()=>{closing=true;await tail.catch(()=>{});return abort();};return writer;
  }
}
class SharedDirectory {
  constructor(client,path=''){this.client=client;this.path=path;this.kind='directory';this.name=path?path.split('/').pop():client.namespace;}
  get nativeShared(){return {namespace:this.client.namespace,path:this.path,kind:'directory'};}
  async getDirectoryHandle(name,{create=false}={}){const path=join(this.path,name);await this.client.request('directory',{path,create});return new SharedDirectory(this.client,path);}
  async getFileHandle(name,{create=false}={}){const path=join(this.path,name),value=(await this.client.request('file',{path,create})).value;return new SharedFile(this.client,path,value);}
  async *entries(){const values=(await this.client.request('list',{path:this.path})).value.entries;for(const value of values){segment(value.name);const path=join(this.path,value.name);yield[value.name,value.kind==='directory'?new SharedDirectory(this.client,path):new SharedFile(this.client,path,value)];}}
  async removeEntry(name,{recursive=false}={}){await this.client.request('remove',{path:join(this.path,name),recursive});}
}
export async function directoryFromPort(port,descriptor){const client=new SharedFileClient(port,{forwarded:true});await client.ready;return client.handle(descriptor);}
export async function openSharedDirectory(){
  if(!globalThis.FishSharedFiles)throw Error('请更新鱼书应用：需要默认共享目录二进制文件接口');
  let listener,timer;const connected=new Promise((resolve,reject)=>{listener=event=>{if(event.data==='fish-files-v1'&&event.ports.length===1&&(!event.source||event.source===window))resolve(event.ports[0]);};window.addEventListener('message',listener);timer=setTimeout(()=>reject(Error('Shared-file port unavailable')),10000);});
  let client;try{FishSharedFiles.open();client=new SharedFileClient(await connected);await client.ready;return {root:new SharedDirectory(client),client,path:client.path};}
  catch(error){connected.catch(()=>{});client?.close();throw error;}finally{clearTimeout(timer);window.removeEventListener('message',listener);}
}
