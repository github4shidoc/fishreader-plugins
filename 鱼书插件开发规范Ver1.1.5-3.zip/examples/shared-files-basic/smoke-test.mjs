import fs from 'node:fs';
import path from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const expected = ['index.html', 'shared-files.json', 'app.mjs', 'fish-shared-files.mjs'];
const archive = fs.readFileSync(path.join(root, 'shared-files-basic.fishweb'));
let end = -1;
for (let i = archive.length - 22; i >= Math.max(0, archive.length - 65557); i--) {
  if (archive.readUInt32LE(i) === 0x06054b50 && i + 22 + archive.readUInt16LE(i + 20) === archive.length) {
    end = i;
    break;
  }
}
if (end < 0) throw new Error('缺少 ZIP 结束目录');
const count = archive.readUInt16LE(end + 10);
if (count !== expected.length) throw new Error('共享文件示例条目数量错误');
let cursor = archive.readUInt32LE(end + 16);
const found = new Set();
for (let i = 0; i < count; i++) {
  if (archive.readUInt32LE(cursor) !== 0x02014b50) throw new Error('ZIP 中央目录损坏');
  const method = archive.readUInt16LE(cursor + 10);
  const compressed = archive.readUInt32LE(cursor + 20);
  const nameLength = archive.readUInt16LE(cursor + 28);
  const extraLength = archive.readUInt16LE(cursor + 30);
  const commentLength = archive.readUInt16LE(cursor + 32);
  const localOffset = archive.readUInt32LE(cursor + 42);
  const name = archive.subarray(cursor + 46, cursor + 46 + nameLength).toString('utf8');
  if (!expected.includes(name) || found.has(name)) throw new Error('意外的 ZIP 条目：' + name);
  if (archive.readUInt32LE(localOffset) !== 0x04034b50) throw new Error('ZIP 文件头损坏');
  const dataOffset = localOffset + 30 + archive.readUInt16LE(localOffset + 26) + archive.readUInt16LE(localOffset + 28);
  const packed = archive.subarray(dataOffset, dataOffset + compressed);
  const content = method === 8 ? inflateRawSync(packed) : method === 0 ? packed : null;
  if (!content?.equals(fs.readFileSync(path.join(root, name)))) throw new Error('ZIP 内容不一致：' + name);
  found.add(name);
  cursor += 46 + nameLength + extraLength + commentLength;
}
if (expected.some(name => !found.has(name))) throw new Error('ZIP 缺少文件');
const declaration = JSON.parse(fs.readFileSync(path.join(root, 'shared-files.json'), 'utf8'));
if (declaration.version !== 1 || !/^[A-Za-z0-9_-]{1,64}$/.test(declaration.namespace)) {
  throw new Error('shared-files.json 声明无效');
}
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
if (!html.includes('./app.mjs') || !fs.readFileSync(path.join(root, 'app.mjs'), 'utf8').includes('openSharedDirectory')) {
  throw new Error('入口未使用共享文件帮助模块');
}
console.log('shared-files 示例归档、声明和入口检查通过');
