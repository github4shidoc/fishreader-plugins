# 共享文件接口最小示例

此独立 `.fishweb` 含根目录 `shared-files.json`，声明 `FishSharedDemo` 命名空间。点击“打开目录”后才创建会话，点击“写入示例文本”才会写入共享文件。该目录位于应用共享下载目录，可能被其他使用相同 namespace 的网页包访问；示例不存放账号或密钥。导入或更新 `.fishweb` 需要鱼书 Pro。

在本目录运行 `python build.py`，再将 `shared-files-basic.fishweb` 从“网页与订阅 → 网页”导入。页面依赖鱼书 1.1.2 的 `FishSharedFiles` 桥；不支持时会显示错误。若另一个页面占用同一 namespace，请先关闭它再重试。

`fish-shared-files.mjs` 是仓库通用帮助模块的副本；其 `openSharedDirectory`、`SharedFileClient` 和 Worker 端 `directoryFromPort` 只是 JavaScript 封装，底层协议见[共享文件接口规范](../../docs/19-1.1.2-共享文件接口.md)。`node smoke-test.mjs` 只核对 ZIP 条目与声明；目录权限、持久化和并发须在设备中验收。
