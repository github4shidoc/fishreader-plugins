# `.fishweb` 最小示例

这是可导入的独立本地网页包，展示根目录 `index.html`、相对路径 CSS、JavaScript 和静态图标。它不属于插件管理中的 `.fishplugin.json` 包。鱼书 1.1.2 导入或更新 `.fishweb` 需要 Pro。

在本目录执行：

```bash
python build.py
```

得到 `fishweb-basic.fishweb` 后，在鱼书 1.1.2 的“网页与订阅 → 网页 → 导入 HTML / .fishweb”中选择该文件。页面显示桥接对象是否存在；它不会在未获用户操作时发起请求或播放。

包格式和更新规则见[1.1.2 `.fishweb` 网页包格式](../../docs/17-1.1.2-fishweb网页包.md)。
