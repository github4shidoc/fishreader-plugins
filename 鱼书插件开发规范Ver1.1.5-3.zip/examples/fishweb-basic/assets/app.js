const status = document.querySelector('#status');
const available = [
  ['网页接口', globalThis.FishPlayerWebVideo],
  ['视频接口', globalThis.fishreaderwebviewvideo]
].filter(([, bridge]) => bridge !== undefined).map(([label]) => label);
status.textContent = available.length ? `可用：${available.join('、')}` : '当前环境未提供鱼书网页接口';
