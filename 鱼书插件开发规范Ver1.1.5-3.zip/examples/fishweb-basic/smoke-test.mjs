import fs from 'node:fs';
import path from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const archive = fs.readFileSync(path.join(root, 'fishweb-basic.fishweb'));
const expected = ['index.html', 'assets/app.js', 'assets/style.css', 'assets/icon.svg'];
const found = new Map();
let end = -1;
for (let i = archive.length - 22; i >= Math.max(0, archive.length - 65557); i--) {
  if (archive.readUInt32LE(i) === 0x06054b50 && i + 22 + archive.readUInt16LE(i + 20) === archive.length) {
    end = i;
    break;
  }
}
if (end < 0) throw new Error('缺少有效 ZIP 结束目录');
let cursor = archive.readUInt32LE(end + 16);
const count = archive.readUInt16LE(end + 10);
for (let i = 0; i < count; i++) {
  if (archive.readUInt32LE(cursor) !== 0x02014b50) throw new Error('ZIP 目录损坏');
  const method = archive.readUInt16LE(cursor + 10);
  const compressed = archive.readUInt32LE(cursor + 20);
  const nameLength = archive.readUInt16LE(cursor + 28);
  const extraLength = archive.readUInt16LE(cursor + 30);
  const commentLength = archive.readUInt16LE(cursor + 32);
  const localOffset = archive.readUInt32LE(cursor + 42);
  const name = archive.subarray(cursor + 46, cursor + 46 + nameLength).toString('utf8');
  if (!expected.includes(name) || found.has(name)) throw new Error(`意外的 ZIP 条目：${name}`);
  if (archive.readUInt32LE(localOffset) !== 0x04034b50) throw new Error('ZIP 文件头损坏');
  const dataOffset = localOffset + 30 + archive.readUInt16LE(localOffset + 26) + archive.readUInt16LE(localOffset + 28);
  const stored = archive.subarray(dataOffset, dataOffset + compressed);
  const data = method === 8 ? inflateRawSync(stored) : method === 0 ? stored : null;
  if (!data || !data.equals(fs.readFileSync(path.join(root, name)))) throw new Error(`ZIP 内容不一致：${name}`);
  found.set(name, true);
  cursor += 46 + nameLength + extraLength + commentLength;
}
if (expected.some(name => !found.has(name))) throw new Error('ZIP 缺少入口或包内资源');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
for (const name of ['assets/app.js', 'assets/style.css', 'assets/icon.svg']) {
  if (!html.includes(`./${name}`)) throw new Error(`入口未使用相对资源：${name}`);
}
console.log('fishweb 示例归档、入口和相对资源检查通过');
