"""Build the standalone fishweb example with UTF-8 ZIP entry names."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / "fishweb-basic.fishweb"
with ZipFile(TARGET, "w", compression=ZIP_DEFLATED) as archive:
    for name in ("index.html", "assets/app.js", "assets/style.css", "assets/icon.svg"):
        archive.write(ROOT / name, name)
print(TARGET)
