import fs from 'node:fs';
import path from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { Batch, PROTOCOL } from './fish-native-gpu.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const expected = ['index.html', 'app.mjs', 'fish-native-gpu.mjs',
  'sample.vert.spv', 'sample.frag.spv'];
const zip = fs.readFileSync(path.join(root, 'native-gpu-basic.fishweb'));
let end = -1;
for (let i = zip.length - 22; i >= Math.max(0, zip.length - 65557); i--) {
  if (zip.readUInt32LE(i) === 0x06054b50 && i + 22 + zip.readUInt16LE(i + 20) === zip.length) {
    end = i; break;
  }
}
if (end < 0) throw new Error('无效 ZIP 目录');
let cursor = zip.readUInt32LE(end + 16);
const names = [];
for (let i = 0; i < zip.readUInt16LE(end + 10); i++) {
  if (zip.readUInt32LE(cursor) !== 0x02014b50) throw new Error('ZIP 条目无效');
  const method = zip.readUInt16LE(cursor + 10);
  const compressed = zip.readUInt32LE(cursor + 20);
  const length = zip.readUInt16LE(cursor + 28);
  const extra = zip.readUInt16LE(cursor + 30);
  const comment = zip.readUInt16LE(cursor + 32);
  const local = zip.readUInt32LE(cursor + 42);
  const name = zip.subarray(cursor + 46, cursor + 46 + length).toString('utf8');
  if (zip.readUInt32LE(local) !== 0x04034b50 || !expected.includes(name) || names.includes(name)) {
    throw new Error(`ZIP 条目不匹配：${name}`);
  }
  const offset = local + 30 + zip.readUInt16LE(local + 26) + zip.readUInt16LE(local + 28);
  const bytes = zip.subarray(offset, offset + compressed);
  const actual = method === 8 ? inflateRawSync(bytes) : method === 0 ? bytes : null;
  if (!actual?.equals(fs.readFileSync(path.join(root, name)))) throw new Error(`ZIP 内容不匹配：${name}`);
  names.push(name);
  cursor += 46 + length + extra + comment;
}
if (expected.some(name => !names.includes(name))) throw new Error('缺少网页入口或图形资源');
for (const name of ['sample.vert.spv', 'sample.frag.spv']) {
  if (fs.readFileSync(path.join(root, name)).readUInt32LE(0) !== 0x07230203) throw new Error(`${name} 不是 SPIR-V`);
}
const packet = new Batch(1).begin().end().finish();
const words = new Uint32Array(packet);
if (words[0] !== PROTOCOL.magic || words[1] !== 1 || words[2] !== 1 || words[3] !== 2 ||
  packet.byteLength % 4 !== 0) throw new Error('FGU1 包头不匹配');
console.log('native-gpu 示例归档、SPIR-V 与 FGU1 编码检查通过');
