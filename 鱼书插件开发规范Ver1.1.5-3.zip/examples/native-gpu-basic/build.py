"""Build an importable fishweb containing the native GPU example."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / 'native-gpu-basic.fishweb'
with ZipFile(TARGET, 'w', compression=ZIP_DEFLATED) as archive:
    for name in ('index.html', 'app.mjs', 'fish-native-gpu.mjs',
                 'sample.vert.spv', 'sample.frag.spv'):
        archive.write(ROOT / name, name)
print(TARGET)
