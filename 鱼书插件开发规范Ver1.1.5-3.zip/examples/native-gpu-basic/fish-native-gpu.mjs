/** FishReader Native GPU protocol v1. Generic graphics, independent of emulators. */
export const PROTOCOL = Object.freeze({ magic: 0x31554746, version: 1, maxBytes: 16 * 1024 * 1024, inFlight: 2 });
export const ADMISSION = Object.freeze({maxPending:6,maxBytes:32*1024*1024,maxUnaccepted:2});
export const READBACK = Object.freeze({magic:0x31524746,version:1,maxBytes:8*1024*1024,maxRequests:128});
const bits = new DataView(new ArrayBuffer(4));
const f32 = value => { if (!Number.isFinite(value)) throw new TypeError('Nonfinite float'); bits.setFloat32(0,value,true);return bits.getUint32(0,true); };
const uint = value => { if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) throw new TypeError('Expected uint32');return value; };
const sint = value => { if (!Number.isInteger(value) || value < -0x80000000 || value > 0x7fffffff) throw new TypeError('Expected int32');return value>>>0; };
const targetFormats=new Set([37,103,9,16,44,70,77,91,76,83,97,100,109,15,22,43,50,10,17,38,71,78,92,2,4,8,58,122,123,98,99,101]);
const validTargetFormat=f=>Number.isInteger(f)&&(f===0||f===1||(f>=0x10000&&f<=0x1ffff&&targetFormats.has(f&0xffff)));
export function vulkanTargetFormat(format){if(!targetFormats.has(format))throw new RangeError('Unsupported Vulkan target format');return 0x10000|format;}
const compressedFormat=f=>(f>=131&&f<=146)||(f>=157&&f<=184);
const validImageFormat=f=>validTargetFormat(f)||(Number.isInteger(f)&&f>=0x10000&&f<=0x1ffff&&compressedFormat(f&0xffff));
export function vulkanImageFormat(format){if(!Number.isInteger(format)||(!targetFormats.has(format)&&!compressedFormat(format)))throw new RangeError('Unsupported Vulkan image format');return 0x10000|format;}

export class Batch {
  constructor(sequence) {
    this.storage=new ArrayBuffer(4096);this.words=new Uint32Array(this.storage);this.length=4;
    this.words.set([PROTOCOL.magic,1,uint(sequence),0]);
  }
  command(op,args=[],payload) {
    const bytes=payload ? new Uint8Array(payload.buffer ?? payload,payload.byteOffset ?? 0,payload.byteLength) : null;
    const extra=bytes ? Math.ceil(bytes.byteLength/4) : 0;
    const needed=(this.length+2+args.length+extra)*4;
    if (needed>PROTOCOL.maxBytes) throw new RangeError('Split uploads into smaller batches');
    if(needed>this.storage.byteLength){const storage=new ArrayBuffer(Math.min(PROTOCOL.maxBytes,Math.max(needed,this.storage.byteLength*2)));
      new Uint8Array(storage).set(new Uint8Array(this.storage,0,this.length*4));this.storage=storage;this.words=new Uint32Array(storage);}
    this.words[this.length++]=op;this.words[this.length++]=2+args.length+extra;
    for(const arg of args)this.words[this.length++]=uint(arg);
    if(bytes){new Uint8Array(this.storage,this.length*4,bytes.byteLength).set(bytes);this.length+=extra;}
    this.words[3]++;return this;
  }
  buffer(id,bytes,usage=1) {return this.command(1,[id,bytes,usage]);}
  resetResources() {if(this.length!==4)throw new Error('Resource reset must be the only command');return this.command(77);}
  deviceBuffer(id,bytes) {if(!uint(bytes)||bytes%4)throw new RangeError('Device buffer size must be a positive multiple of four');return this.command(43,[id,bytes]);}
  readBuffer(request,id,offset,bytes) {
    if(!uint(request)||!uint(id)||uint(offset)%4||!uint(bytes)||bytes%4||bytes>READBACK.maxBytes||offset>0xffffffff-bytes)throw new RangeError('Invalid GPU readback range');
    return this.command(58,[request,id,offset,bytes]);
  }
  imageBufferCopy(op,image,buffer,{offset=0,level=0,x=0,y=0,width,height,rowLength=0,aspect=1}={}) {
    if(![44,45].includes(op)||!uint(width)||!uint(height)||uint(level)>=14||uint(offset)%4||(rowLength&&uint(rowLength)<width))throw new RangeError('Invalid image transfer region');
    if(![1,2,4].includes(aspect)||(op===45&&aspect!==1))throw new RangeError('Invalid image transfer aspect');
    return this.command(op,[image,buffer,offset,level,x,y,width,height,rowLength,...(aspect===1?[]:[aspect])]);
  }
  copyImageToBuffer(image,buffer,region) {return this.imageBufferCopy(44,image,buffer,region);}
  copyBufferToImage(image,buffer,region) {return this.imageBufferCopy(45,image,buffer,region);}
  // Capability rawImageSubresources. Kept separate from the legacy wire form.
  imageSubresourceCopy(op,image,buffer,{offset=0,level=0,x=0,y=0,width,height,rowLength=0,aspect=1,layer=0}={}) {
    if(![44,45].includes(op)||!uint(image)||!uint(buffer)||!uint(width)||!uint(height)||uint(level)>=14||uint(layer)>=256||
      uint(offset)%4||(rowLength&&uint(rowLength)<width)||![1,2,4].includes(aspect))throw new RangeError('Invalid raw image subresource transfer');
    return this.command(op,[image,buffer,offset,level,x,y,width,height,rowLength,aspect,layer]);
  }
  readImageSubresource(image,buffer,region) {return this.imageSubresourceCopy(44,image,buffer,region);}
  writeImageSubresource(image,buffer,region) {return this.imageSubresourceCopy(45,image,buffer,region);}
  restoreOcclusionResults(id,first,values) {
    if(!uint(id)||uint(first)>=4096||!(values instanceof Uint32Array)||!values.length||values.length>4096-first)
      throw new RangeError('Invalid restored occlusion result range');
    return this.command(76,[id,first,values.length],values);
  }
  copyImage(source,destination,{sourceLevel=0,destinationLevel=0,sourceX=0,sourceY=0,destinationX=0,destinationY=0,width,height}={}) {
    if(uint(source)===uint(destination)||uint(sourceLevel)>=14||uint(destinationLevel)>=14||!uint(width)||!uint(height))throw new RangeError('Invalid image copy');
    return this.command(52,[source,destination,sourceLevel,destinationLevel,sourceX,sourceY,destinationX,destinationY,width,height]);
  }
  blitImage(source,destination,{sourceLevel=0,destinationLevel=0,sourceX=0,sourceY=0,destinationX=0,destinationY=0,sourceWidth,sourceHeight,width,height,linear=false}={}) {
    if(!uint(source)||!uint(destination)||source===destination||uint(sourceLevel)>=14||uint(destinationLevel)>=14)throw new RangeError('Invalid image blit');
    for(const [at,size] of [[sourceX,sourceWidth],[sourceY,sourceHeight],[destinationX,width],[destinationY,height]])
      if(!uint(size)||uint(at)+size>0x7fffffff)throw new RangeError('Invalid image blit region');
    return this.command(74,[source,destination,sourceLevel,destinationLevel,sourceX,sourceY,destinationX,destinationY,sourceWidth,sourceHeight,width,height,linear?1:0]);
  }
  rasterDynamic({depthBias=0,depthBiasClamp=0,depthSlope=0,lineWidth=1}={}) {
    if(!(lineWidth>0))throw new RangeError('Line width must be positive');
    return this.command(50,[depthBias,depthBiasClamp,depthSlope,lineWidth].map(f32));
  }
  writeBuffer(id,offset,data) {return this.command(2,[id,offset,data.byteLength],data);}
  shader(id,spirv,{resources=false}={}) {return this.command(resources?20:3,[id,spirv.byteLength],spirv);}
  pipeline(id,vertexShader,fragmentShader,{stride=0,attributes=[],depthTest=false,depthWrite=false,blend=false,cullBack=false,offscreen=false,topology=0}={}) {
    return this.command(4,[id,vertexShader,fragmentShader,stride,attributes.length,
      (depthTest?1:0)|(depthWrite?2:0)|(blend?4:0)|(cullBack?8:0)|(offscreen?16:0),topology,
      ...attributes.flatMap(a=>[a.location,a.components,a.offset])]);
  }
  rasterPipeline(id,vertexShader,fragmentShader,{stride=0,attributes=[],depthTest=false,depthWrite=false,blend=false,offscreen=false,targetFormat=0,
    topology=3,restart=false,fragmentDisabled=false,polygonMode=0,depthCompare=3,cull=0,frontFace=0,colorMask=15,
    srcColor=6,dstColor=7,colorOp=0,srcAlpha=1,dstAlpha=7,alphaOp=0,constants=[0,0,0,0],stencil=null,vertexLayout=0}={}) {
    if(!validTargetFormat(targetFormat)||(targetFormat&&!offscreen))throw new RangeError('Invalid render target format');
    if(constants.length!==4)throw new RangeError('Expected four blend constants');
    if(fragmentDisabled&&fragmentShader!==0)throw new RangeError('Disabled fragment stage must use shader ID zero');
    if(uint(polygonMode)>2)throw new RangeError('Invalid polygon mode');
    let prefix=targetFormat?[targetFormat]:[];
    if(stencil){
      if(!offscreen)throw new RangeError('Stencil pipeline requires an attachment target');
      const face=({compare=7,fail=0,depthFail=0,pass=0}={})=>[compare,fail,depthFail,pass].map(v=>{if(uint(v)>7)throw new RangeError('Invalid stencil operation');return v;});
      prefix=[targetFormat,stencil.enabled===false?0:1,...face(stencil.front),...face(stencil.back??stencil.front)];
    }
    if(vertexLayout){
      if(stride||attributes.length)throw new RangeError('Use either vertexLayout or inline attributes');
      prefix=[uint(vertexLayout),stencil?1:0,...(stencil?prefix:[targetFormat,0,7,0,0,0,7,0,0,0])];
    }
    return this.command(vertexLayout?39:stencil?34:targetFormat?27:23,[...prefix,id,vertexShader,fragmentShader,stride,attributes.length,
      (depthTest?1:0)|(depthWrite?2:0)|(blend?4:0)|(offscreen?16:0)|(restart?32:0)|(fragmentDisabled?64:0)|(polygonMode<<7),topology,
      depthCompare,cull,frontFace,colorMask,srcColor,dstColor,colorOp,srcAlpha,dstAlpha,alphaOp,
      ...constants.map(f32),...attributes.flatMap(a=>[a.location,a.components,a.offset])]);
  }
  texture(id,width,height) {return this.command(5,[id,width,height]);}
  image2D(id,width,height,{format=0,levels=1,swizzle=[0,0,0,0]}={}) {
    if(!validImageFormat(format)||!width||!height||!levels||uint(levels)>14||levels>Math.floor(Math.log2(Math.max(width,height)))+1||swizzle.length!==4||swizzle.some(v=>uint(v)>6))throw new RangeError('Invalid image descriptor');
    return this.command(41,[id,width,height,levels,format,...swizzle]);
  }
  writeImageLevel(id,level,pixels,{rowLength=0}={}) {
    if(uint(level)>=14)throw new RangeError('Invalid image mip level');
    return this.command(42,[id,level,uint(rowLength),pixels.byteLength],pixels);
  }
  imageArray(id,width,height,layers,{format=0,levels=1,swizzle=[0,0,0,0]}={}) {
    if(!uint(id)||!uint(width)||!uint(height)||width>8192||height>8192||!uint(layers)||layers>256||!validImageFormat(format)||!uint(levels)||levels>14||levels>Math.floor(Math.log2(Math.max(width,height)))+1||swizzle.length!==4||swizzle.some(v=>uint(v)>6))throw new RangeError('Invalid image array descriptor');
    return this.command(73,[id,width,height,levels,format,...swizzle,layers]);
  }
  writeImageLayer(id,level,layer,pixels,{rowLength=0}={}) {
    if(!uint(id)||uint(level)>=14||uint(layer)>=256)throw new RangeError('Invalid image array layer or mip level');
    return this.command(48,[id,level,layer,uint(rowLength),pixels.byteLength],pixels);
  }
  imageCube(id,edge,{format=0,levels=1,swizzle=[0,0,0,0]}={}) {
    if(!validImageFormat(format)||!uint(edge)||!uint(levels)||levels>14||levels>Math.floor(Math.log2(edge))+1||swizzle.length!==4||swizzle.some(v=>uint(v)>6))throw new RangeError('Invalid cube image descriptor');
    return this.command(47,[id,edge,levels,format,...swizzle]);
  }
  writeImageFace(id,level,face,pixels,{rowLength=0}={}) {
    if(uint(level)>=14||uint(face)>=6)throw new RangeError('Invalid cube face or mip level');
    return this.command(48,[id,level,face,uint(rowLength),pixels.byteLength],pixels);
  }
  writeImageRegion(id,level,pixels,{face=0,x=0,y=0,width,height,rowLength=0}={}) {
    if(!uint(id)||uint(level)>=14||uint(face)>=256||!uint(width)||!uint(height)||
      uint(x)>0xffffffff-width||uint(y)>0xffffffff-height||(uint(rowLength)&&rowLength<width)||
      !pixels.byteLength||pixels.byteLength>1024*1024)throw new RangeError('Invalid image upload region');
    return this.command(63,[id,level,face,x,y,width,height,rowLength,pixels.byteLength],pixels);
  }
  clearImage(id,{level=0,face=0,value=[0,0,0,0],scalar='float'}={}) {
    if(!uint(id)||uint(level)>=14||uint(face)>=256||value.length!==4||!['float','uint','sint'].includes(scalar))throw new RangeError('Invalid image clear');
    return this.command(64,[id,level,face,...Array.from(value,scalar==='float'?f32:scalar==='uint'?uint:sint)]);
  }
  computePipeline(id,shader) {
    if(!uint(id)||!uint(shader))throw new RangeError('Invalid compute pipeline IDs');
    return this.command(66,[id,shader]);
  }
  storageImage2D(id,width,height,format=0) {
    if(!uint(id)||!uint(width)||!uint(height)||width>8192||height>8192||!validTargetFormat(format))throw new RangeError('Invalid storage image');
    return this.command(70,[id,width,height,format]);
  }
  bindStorageImage(set,binding,id) {
    if(uint(set)>=4||uint(binding)>=16||!uint(id))throw new RangeError('Invalid storage image binding');return this.command(71,[set,binding,id]);
  }
  bindSampler(set,binding,id) {
    if(uint(set)>=4||uint(binding)>=16||!uint(id))throw new RangeError('Invalid sampler binding');return this.command(72,[set,binding,id]);
  }
  bindComputePipeline(id) {
    if(!uint(id))throw new RangeError('Invalid compute pipeline ID');return this.command(67,[id]);
  }
  dispatch(x,y=1,z=1) {
    if([x,y,z].some(v=>!uint(v)||v>65535))throw new RangeError('Invalid compute dispatch size');return this.command(68,[x,y,z]);
  }
  copyBuffer(source,destination,sourceOffset,destinationOffset,bytes) {
    if(!uint(source)||!uint(destination)||!uint(bytes)||bytes%4||uint(sourceOffset)%4||uint(destinationOffset)%4||sourceOffset>0xffffffff-bytes||destinationOffset>0xffffffff-bytes||
      (source===destination&&sourceOffset+bytes>destinationOffset&&destinationOffset+bytes>sourceOffset))throw new RangeError('Invalid GPU buffer copy');
    return this.command(69,[source,destination,sourceOffset,destinationOffset,bytes]);
  }
  pushConstants(offset,data) {
    if(!(data instanceof ArrayBuffer)&&!ArrayBuffer.isView(data))throw new TypeError('Expected push constant binary data');
    const bytes=data.byteLength;
    if(uint(offset)%4||!bytes||bytes%4||bytes>128||offset>128-bytes)throw new RangeError('Push constants exceed 128 bytes or alignment');
    return this.command(65,[offset,bytes],data);
  }
  textureLevels(id,width,height,levels) {
    if(!width||!height||!levels||uint(levels)>14||levels>Math.floor(Math.log2(Math.max(width,height)))+1)throw new RangeError('Invalid texture mip count');
    return this.command(28,[id,width,height,levels]);
  }
  writeTextureLevel(id,level,rgba8) {if(uint(level)>=14)throw new RangeError('Invalid mip level');return this.command(29,[id,level,rgba8.byteLength],rgba8);}
  sampler(id,{minFilter=1,magFilter=1,mipmapMode=0,addressU=2,addressV=2,lodBias=0,minLod=0,maxLod=1000,anisotropy=1}={}) {
    if([minFilter,magFilter,mipmapMode].some(v=>uint(v)>1)||[addressU,addressV].some(v=>uint(v)>4)||
      ![lodBias,minLod,maxLod].every(Number.isFinite)||minLod<0||maxLod<minLod)throw new RangeError('Invalid sampler');
    if(!Number.isFinite(anisotropy)||anisotropy<1||anisotropy>16)throw new RangeError('Invalid anisotropy');
    const args=[id,minFilter,magFilter,mipmapMode,addressU,addressV,f32(lodBias),f32(minLod),f32(maxLod)];
    return anisotropy===1?this.command(30,args):this.command(51,[...args,f32(anisotropy)]);
  }
  bindTextureSampler(set,binding,image,sampler) {
    if(uint(set)>=4||uint(binding)>=16)throw new RangeError('Descriptor set/binding out of range');
    return this.command(31,[set,binding,image,sampler]);
  }
  renderTarget(id,width,height,format=0) {
    if(!validTargetFormat(format))throw new RangeError('Invalid render target format');
    return format?this.command(26,[id,width,height,format]):this.command(18,[id,width,height]);
  }
  beginTarget(id,{load=false,color=[0,0,0,1],depth=1}={}) {
    if(color.length!==4)throw new Error('RGBA color required');
    return this.command(19,[id,load?1:0,...color.map(f32),f32(depth)]);
  }
  depthStencilAttachment(id,width,height) {return this.command(32,[id,width,height]);}
  attachmentTarget(id,width,height,depthAttachment,format=0) {
    if(!validTargetFormat(format)||!uint(depthAttachment))throw new RangeError('Invalid attachment target');
    return this.command(33,[id,width,height,format,depthAttachment]);
  }
  rebindTargetDepth(id,depthAttachment) {
    if(!uint(id)||!uint(depthAttachment)||id===depthAttachment)throw new RangeError('Invalid attachment rebind');
    return this.command(53,[id,depthAttachment]);
  }
  rebindTargetColor(id,format) {
    if(!uint(id)||![0,0x10025,0x1002b,0x1002c,0x10032].includes(format))throw new RangeError('Invalid attachment color view');
    return this.command(75,[id,format]);
  }
  copyDepthStencil(source,destination,{sourceX=0,sourceY=0,destinationX=0,destinationY=0,width,height}={}) {
    if(!uint(source)||!uint(destination)||source===destination||!uint(width)||!uint(height))throw new RangeError('Invalid depth/stencil copy');
    return this.command(54,[source,destination,uint(sourceX),uint(sourceY),uint(destinationX),uint(destinationY),width,height]);
  }
  bindDepthTexture(set,binding,id,{sampler=0,aspect=2}={}) {
    if(uint(set)>=4||uint(binding)>=16||!uint(id)||(aspect!==2&&aspect!==4))throw new RangeError('Invalid sampled depth/stencil view');
    return this.command(55,[set,binding,id,uint(sampler),aspect]);
  }
  prepareDepthTexture(id) {
    if(!uint(id))throw new RangeError('Invalid depth/stencil image');
    return this.command(56,[id]);
  }
  beginAttachmentTarget(id,{loadColor=false,loadDepthStencil=false,color=[0,0,0,1],depth=1,stencil=0,storeColor=true,storeDepthStencil=true}={}) {
    if(color.length!==4||!Number.isFinite(depth)||depth<0||depth>1||uint(stencil)>255)throw new RangeError('Invalid attachment clear');
    const args=[id,+!!loadColor,+!!loadDepthStencil,...color.map(f32),f32(depth),stencil];
    if(!storeColor||!storeDepthStencil)args.push(+!!storeColor|(+!!storeDepthStencil<<1));
    return this.command(37,args);
  }
  beginOrderedTarget(id,{loadColor=false,loadDepthStencil=false,color=[0,0,0,1],depth=1,stencil=0,storeColor=true,storeDepthStencil=true}={}) {
    if(color.length!==4||!Number.isFinite(depth)||depth<0||depth>1||uint(stencil)>255)throw new RangeError('Invalid ordered attachment clear');
    const args=[id,+!!loadColor,+!!loadDepthStencil,...color.map(f32),f32(depth),stencil];
    if(!storeColor||!storeDepthStencil)args.push(+!!storeColor|(+!!storeDepthStencil<<1));
    return this.command(46,args);
  }
  stencilState({faces=3,reference=0,compareMask=255,writeMask=255}={}) {
    if(!uint(faces)||faces>3||[reference,compareMask,writeMask].some(v=>uint(v)>255))throw new RangeError('Invalid stencil state');
    return this.command(35,[faces,reference,compareMask,writeMask]);
  }
  clearDepthStencil({aspects=3,depth=1,stencil=0}={}) {
    if(!uint(aspects)||aspects>3||!Number.isFinite(depth)||depth<0||depth>1||uint(stencil)>255)throw new RangeError('Invalid depth/stencil clear');
    return this.command(36,[aspects,f32(depth),stencil]);
  }
  clearDepthStencilRect({aspects=3,depth=1,stencil=0,x=0,y=0,width,height}={}) {
    if(!uint(aspects)||aspects>3||!Number.isFinite(depth)||depth<0||depth>1||uint(stencil)>255||uint(x)>0x7fffffff||uint(y)>0x7fffffff)throw new RangeError('Invalid depth/stencil rectangle clear');
    return this.command(57,[aspects,f32(depth),stencil,x,y,uint(width),uint(height)]);
  }
  vertexLayout(id,{bindings=[],attributes=[]}={}) {
    if(bindings.length>16||attributes.length>32)throw new RangeError('Vertex layout limit exceeded');
    return this.command(38,[id,bindings.length,attributes.length,
      ...bindings.flatMap(b=>[b.binding,b.stride,b.instance?1:0]),
      ...attributes.flatMap(a=>[a.location,a.binding,a.format,a.offset])]);
  }
  vertexBinding(binding,buffer,offset=0) {if(uint(binding)>=16)throw new RangeError('Vertex binding out of range');return this.command(40,[binding,buffer,offset]);}
  writeTexture(id,rgba8) {return this.command(6,[id,rgba8.byteLength],rgba8);}
  begin(color=[0,0,0,1],depth=1) {if(color.length!==4)throw new Error('RGBA color required');return this.command(7,[...color.map(f32),f32(depth)]);}
  bindPipeline(id) {return this.command(8,[id]);}
  vertex(id,offset=0) {return this.command(9,[id,offset]);}
  index(id,offset=0,bytes=2) {return this.command(10,[id,offset,bytes]);}
  uniform(id,offset,bytes) {return this.command(11,[id,offset,bytes]);}
  sample(slot,id) {return this.command(12,[slot,id]);}
  bindBuffer(set,binding,id,offset,bytes) {
    if(uint(set)>=4||uint(binding)>=16)throw new RangeError('Descriptor set/binding out of range');
    return this.command(21,[set,binding,id,offset,bytes]);
  }
  bindTexture(set,binding,id) {
    if(uint(set)>=4||uint(binding)>=16)throw new RangeError('Descriptor set/binding out of range');
    return this.command(22,[set,binding,id]);
  }
  bindTextureView(set,binding,id,format,{sampler=0,components=null}={}) {
    if(uint(set)>=4||uint(binding)>=16||!uint(id))throw new RangeError('Invalid image view binding');
    uint(sampler);
    if(components===null){
      if(![37,43,44,50].includes(format))throw new RangeError('Invalid legacy view format');
      return this.command(49,[set,binding,id,sampler,format]);
    }
    if(!targetFormats.has(format)||components.length!==4||Array.from(components).some(v=>uint(v)>6))throw new RangeError('Invalid component view');
    return this.command(49,[set,binding,id,sampler,format,...components]);
  }
  viewport(x,y,width,height) {return this.command(13,[x,y,width,height].map(f32));}
  scissor(x,y,width,height) {return this.command(24,[sint(x),sint(y),uint(width),uint(height)]);}
  clearDepth(depth=1) {if(!Number.isFinite(depth)||depth<0||depth>1)throw new RangeError('Depth clear out of range');return this.command(25,[f32(depth)]);}
  draw(count,instances=1,first=0,firstInstance=0) {return this.command(14,[count,instances,first,firstInstance]);}
  drawIndexed(count,instances=1,first=0,baseVertex=0,firstInstance=0) {return this.command(15,[count,instances,first,baseVertex>>>0,firstInstance]);}
  end() {return this.command(16);}
  occlusionPool(id,count=256) {
    if(!uint(id)||!uint(count)||count>4096)throw new RangeError('Invalid occlusion pool');
    return this.command(59,[id,count]);
  }
  beginOcclusion(id,index,{precise=false}={}) {
    if(!uint(id)||uint(index)>=4096)throw new RangeError('Invalid occlusion index');
    return this.command(60,[id,index,precise?1:0]);
  }
  endOcclusion(id,index) {
    if(!uint(id)||uint(index)>=4096)throw new RangeError('Invalid occlusion index');
    return this.command(61,[id,index]);
  }
  copyOcclusionResults(id,first,count,buffer,offset=0,stride=4) {
    if(!uint(id)||uint(first)>=4096||!uint(count)||count>4096-first||!uint(buffer)||(uint(offset)&3)||uint(stride)<4||stride%4||offset+(count-1)*stride+4>0xffffffff)throw new RangeError('Invalid occlusion result range');
    return this.command(62,stride===4?[id,first,count,buffer,offset]:[id,first,count,buffer,offset,stride]);
  }
  destroy(kind,id) {return this.command(17,[kind,id]);}
  finish() {return this.storage.slice(0,this.length*4);}
}

/** This transport can also run in a Web Worker after transferring the connected port. */
function expectedReadbacks(bytes,onValidated){
  const words=new Uint32Array(bytes),expected=new Map();let at=4,total=0,presents=0;
  for(let n=0;n<words[3];n++){
    if(at+2>words.length||words[at+1]<2||words[at+1]>words.length-at)throw new Error('Malformed GPU command envelope');
    if(words[at]===7)presents=1;
    if(words[at]===58){
      if(words[at+1]!==6)throw new Error('Malformed readback command');
      const request=words[at+2],id=words[at+3],offset=words[at+4],length=words[at+5];
      if(!request||!id||!length||(offset%4)||(length%4)||offset>0xffffffff-length||expected.has(request)||expected.size>=READBACK.maxRequests||length>READBACK.maxBytes-total)throw new Error('Invalid or excessive readback requests');
      expected.set(request,length);total+=length;
    }
    at+=words[at+1];
  }
  if(at!==words.length)throw new Error('Trailing GPU command bytes');
  if(typeof onValidated==='function')onValidated(presents);
  return expected;
}
export class GpuChannel {
  // Additive JS-only capability. Existing callers keep the same result object.
  // The optional submit callback runs after full envelope/readback validation.
  static get packetInfoVersion(){return 1;}
  constructor(port,{admission=false,compactCompletion=false,initialStatus={},onAccepted=()=>{},admissionWindow=ADMISSION.maxUnaccepted}={}) {
    if(!Number.isInteger(admissionWindow)||admissionWindow<1||admissionWindow>ADMISSION.maxPending)throw new RangeError('Invalid GPU admission window');
    this.port=port;this.sequence=0;this.pending=new Map();this.lastStatus={...initialStatus};this.closed=false;
    this.admission=admission;this.onAccepted=onAccepted;this.admissionWindow=admissionWindow;
    this.pendingBytes=0;this.unacceptedCount=0;
    port.onmessage=event=>{
      if(event.data instanceof ArrayBuffer){try{this.receiveReadbacks(event.data);}catch(error){this.fail(error);}return;}
      let message;try{message=JSON.parse(event.data);}catch{return;}
      // Merge only the small changing receipt; never re-copy capability tables
      // into each promise result or mutate an earlier completion's snapshot.
      if(message.status){if(message.status.statusDelta===true)Object.assign(this.lastStatus,message.status);else this.lastStatus={...message.status};}
      if(message.type==='error') {this.fail(new Error(message.status?.error||message.error||'GPU error'));return;}
      const pending=this.pending.get(message.sequence);if(!pending)return;
      if(message.type==='accepted'){
        if(!this.admission||pending.accepted){this.fail(new Error('Unexpected GPU admission'));return;}
        pending.accepted=true;--this.unacceptedCount;
        try{this.onAccepted(message.sequence);}catch(error){this.fail(error);}return;
      }
      if(message.type==='complete'){pending.complete=true;pending.status=message.status??this.lastStatus;this.resolvePending(message.sequence,pending);}
      else{this.forgetPending(message.sequence,pending);clearTimeout(pending.timer);pending.reject(new Error(message.error||'GPU batch rejected'));}
    };
    port.onmessageerror=()=>this.fail(new Error('GPU channel message error'));
    port.start();
    if(admission)port.postMessage(compactCompletion?'fish-gpu-admission-v2':'fish-gpu-admission-v1');
  }
  canSubmit(bytes=0){
    return this.pending.size<(this.admission?ADMISSION.maxPending:PROTOCOL.inFlight)&&
      (!this.admission||this.unacceptedCount<this.admissionWindow)&&this.pendingBytes+bytes<=ADMISSION.maxBytes;
  }
  nextSequence() {return ++this.sequence;}
  receiveReadbacks(buffer){
    if(buffer.byteLength<16||buffer.byteLength%4||buffer.byteLength>16+READBACK.maxRequests*8+READBACK.maxBytes)throw new Error('Invalid GPU readback envelope');
    const words=new Uint32Array(buffer),pending=this.pending.get(words[2]);
    if(words[0]!==READBACK.magic||words[1]!==1||!pending||pending.results||!words[3]||words[3]!==pending.expected.size)throw new Error('Unexpected GPU readback result');
    const results=new Map();let at=4;
    for(let n=0;n<words[3];n++){
      if(at+2>words.length)throw new Error('Truncated GPU readback entry');
      const request=words[at++],bytes=words[at++];
      if(!bytes||bytes%4||pending.expected.get(request)!==bytes||results.has(request)||bytes/4>words.length-at)throw new Error('GPU readback range mismatch');
      results.set(request,new Uint8Array(buffer,at*4,bytes));at+=bytes/4;
    }
    if(at!==words.length)throw new Error('Trailing GPU readback bytes');
    pending.results=results;this.resolvePending(words[2],pending);
  }
  resolvePending(sequence,pending){
    if(!pending.complete||(pending.expected.size&&!pending.results))return;
    this.forgetPending(sequence,pending);clearTimeout(pending.timer);
    pending.resolve(pending.results?{...pending.status,readbacks:pending.results}:pending.status);
  }
  forgetPending(sequence,pending){
    this.pending.delete(sequence);this.pendingBytes-=pending.bytes;
    if(!pending.accepted)--this.unacceptedCount;
  }
  batch() {return new Batch(this.nextSequence());}
  submitWasm(memory,offset,length) {
    if(this.closed||this.detached||!this.canSubmit(length))return Promise.reject(new Error('GPU channel unavailable or queue full'));
    const buffer=memory?.buffer;
    if(!buffer||!Number.isInteger(offset)||offset<0||!Number.isInteger(length)||length<16||length>PROTOCOL.maxBytes||length%4||offset%4||offset>buffer.byteLength||length>buffer.byteLength-offset)
      return Promise.reject(new Error('Invalid WASM packet range'));
    // Snapshot only this batch, never the whole guest heap. The guest can reuse
    // its writer immediately; do not transfer/detach WebAssembly.Memory.
    const bytes=new Uint8Array(length);bytes.set(new Uint8Array(buffer,offset,length));
    return this.submit(bytes.buffer);
  }
  releasePort() {
    if(this.closed||this.detached||this.pending.size||this.sequence!==0)throw new Error('Move GPU port before creating the first batch');
    this.detached=true;this.port.onmessage=null;this.port.onmessageerror=null;
    return this.port;
  }
  submit(batch,onValidated) {
    if(this.closed)return Promise.reject(new Error('GPU channel closed'));
    if(this.detached)return Promise.reject(new Error('GPU channel moved to Worker'));
    const bytes=batch instanceof Batch?batch.finish():batch;
    if(!(bytes instanceof ArrayBuffer)||bytes.byteLength<16||bytes.byteLength>PROTOCOL.maxBytes||bytes.byteLength%4)return Promise.reject(new Error('Invalid binary packet'));
    if(!this.canSubmit(bytes.byteLength))return Promise.reject(new Error('GPU queue full; await admission or completion'));
    const sequence=new Uint32Array(bytes,0,4)[2];
    if(this.pending.has(sequence))return Promise.reject(new Error('Duplicate sequence'));
    let expected;try{expected=expectedReadbacks(bytes,onValidated);}catch(error){return Promise.reject(error);}
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{
        let diagnostic='';
        try{diagnostic=JSON.stringify(this.readStatus?.()??this.lastStatus);}catch(error){diagnostic=String(error);}
        this.fail(new Error(`GPU batch ${sequence} timeout; status: ${diagnostic}; close and reopen the session`));
      },15000);
      this.pending.set(sequence,{resolve,reject,timer,expected,complete:false,accepted:false,bytes:bytes.byteLength,results:null,status:null});
      this.pendingBytes+=bytes.byteLength;++this.unacceptedCount;
      // An ArkWeb native port is not a browser-to-browser Worker port.
      // Use the inline ArrayBuffer representation here, not a transferred-buffer
      // reference. This remains binary, but structured cloning may copy bytes.
      try{this.port.postMessage(bytes);}catch(error){this.fail(error);}
    });
  }
  fail(error) {for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(error);}this.pending.clear();this.pendingBytes=this.unacceptedCount=0;this.closed=true;this.port.close();}
  close() {this.fail(new Error('GPU channel closed'));}
}

// Preserve surface dimensions while it scrolls out of view. Cropping its size
// would change the viewport/projection and recreate the swapchain on every scroll.
export function surfaceRectangle(r,viewportWidth,viewportHeight) {
  if(![r.x,r.y,r.width,r.height,viewportWidth,viewportHeight].every(Number.isFinite))throw new Error('Invalid surface geometry');
  if(r.width<1||r.height<1)return null;
  if(r.width>8192||r.height>8192)throw new Error('GPU surface exceeds dimension limit');
  return {x:Math.max(-r.width,Math.min(r.x,viewportWidth,8192)),
    y:Math.max(-r.height,Math.min(r.y,viewportHeight,8192)),width:r.width,height:r.height};
}

export async function openGpu(element) {
  if(!globalThis.FishNativeGPU)throw new Error('需要支持 FishNativeGPU 的鱼书版本');
  const bridge=globalThis.FishNativeGPU;
  const rect=()=>{const r=surfaceRectangle(element.getBoundingClientRect(),innerWidth,innerHeight);return r?JSON.stringify(r):null;};
  const initialRect=rect();if(!initialRect)throw new Error('GPU surface must have a visible size');
  let listener,timeout;
  const connected=new Promise((resolve,reject)=>{
    listener=event=>{if(event.data==='fish-gpu-v1'&&event.ports.length===1&&(!event.source||event.source===window))resolve(event.ports[0]);};
    window.addEventListener('message',listener);
    timeout=setTimeout(()=>reject(new Error('GPU message port unavailable')),5000);
  });
  let port;
  try {bridge.open(initialRect);port=await connected;}
  catch(error){connected.catch(()=>{});try{bridge.close();}catch{}throw error;}
  finally {clearTimeout(timeout);window.removeEventListener('message',listener);}
  const oldBackground=document.documentElement.style.background;
  const oldBodyBackground=document.body.style.background;
  document.documentElement.style.background='transparent';document.body.style.background='transparent';
  const gpu=new GpuChannel(port);
  gpu.readStatus=()=>JSON.parse(bridge.status());
  const closeChannel=gpu.close.bind(gpu);
  let observer,resizeFrame=0,lastRect=initialRect;
  const resize=()=>{
    if(gpu.closed||resizeFrame)return;
    resizeFrame=requestAnimationFrame(()=>{
      resizeFrame=0;if(gpu.closed)return;
      try {const next=rect();if(next&&next!==lastRect){bridge.resize(next);lastRect=next;}}
      catch(error){gpu.fail(error);gpu.close();}
    });
  };
  gpu.close=()=>{observer?.disconnect();window.removeEventListener('scroll',resize,true);window.removeEventListener('resize',resize);
    window.removeEventListener('orientationchange',resize);window.visualViewport?.removeEventListener('resize',resize);
    cancelAnimationFrame(resizeFrame);resizeFrame=0;
    closeChannel();try{bridge.close();}catch{}document.documentElement.style.background=oldBackground;document.body.style.background=oldBodyBackground;};
  try {
    const deadline=performance.now()+10000;
    while(performance.now()<deadline){const status=JSON.parse(bridge.status());if(status.error)throw new Error(status.error);
      if(status.ready){gpu.lastStatus=status;observer=new ResizeObserver(resize);observer.observe(element);window.addEventListener('resize',resize);window.addEventListener('scroll',resize,true);window.addEventListener('orientationchange',resize);window.visualViewport?.addEventListener('resize',resize);return gpu;}
      await new Promise(resolve=>setTimeout(resolve,25));}
    throw new Error('Vulkan surface initialization timed out');
  } catch(error){gpu.close();throw error;}
}
