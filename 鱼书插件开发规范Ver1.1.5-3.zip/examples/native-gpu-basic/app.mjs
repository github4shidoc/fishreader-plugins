import { openGpu } from './fish-native-gpu.mjs';

const surface = document.querySelector('#surface');
const status = document.querySelector('#status');
let gpu = null;

async function shader(name) {
  const response = await fetch(`./${name}`);
  if (!response.ok) throw new Error(`${name}: HTTP ${response.status}`);
  return response.arrayBuffer();
}

async function start() {
  if (gpu) return;
  const bridge = globalThis.FishNativeGPU;
  if (!bridge?.capabilities || JSON.parse(bridge.capabilities()).protocol !== 'FGU1') {
    status.textContent = '当前页面没有 FGU1 图形接口';
    return;
  }
  document.querySelector('#start').disabled = true;
  try {
    const [vertexShader, fragmentShader] = await Promise.all([
      shader('sample.vert.spv'), shader('sample.frag.spv')
    ]);
    gpu = await openGpu(surface);
    const vertices = new Float32Array([
      -0.75, -0.65, 1, 0.2, 0.2,
       0.75, -0.65, 0.2, 1, 0.3,
       0.00,  0.75, 0.2, 0.5, 1
    ]);
    await gpu.submit(gpu.batch()
      .shader(1, vertexShader).shader(2, fragmentShader)
      .buffer(3, vertices.byteLength, 1).writeBuffer(3, 0, vertices)
      .pipeline(4, 1, 2, { stride: 20, attributes: [
        { location: 0, components: 2, offset: 0 },
        { location: 1, components: 3, offset: 8 }
      ] }));
    const result = await gpu.submit(gpu.batch()
      .begin([0.06, 0.09, 0.14, 1]).bindPipeline(4).vertex(3).draw(3).end());
    status.textContent = `已完成绘制批次 ${result.sequence ?? '—'}；设备：${gpu.lastStatus.device ?? '未知'}`;
  } catch (error) {
    gpu?.close(); gpu = null;
    status.textContent = `绘制失败：${String(error)}`;
  } finally {
    document.querySelector('#start').disabled = false;
  }
}

function stop() {
  gpu?.close(); gpu = null;
  status.textContent = '会话已释放';
}

document.querySelector('#start').addEventListener('click', () => { void start(); });
document.querySelector('#stop').addEventListener('click', stop);
window.addEventListener('pagehide', stop);
