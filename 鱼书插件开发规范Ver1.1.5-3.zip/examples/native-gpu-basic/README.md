# 原生 Vulkan 图形接口最小示例

本例是独立 `.fishweb`，通过 `FishNativeGPU` / `FGU1` 绘制一个彩色三角形。`sample.vert`、`sample.frag` 是着色器源，包中实际加载预编译的 `.spv`。`fish-native-gpu.mjs` 是与鱼书 1.1.2 接口配套的通用 JS 帮助模块副本，已去除特定应用页面事件；它的版本和插件包 SDK `1.0` 无关。

在本目录执行 `python build.py` 生成 `native-gpu-basic.fishweb`，再由鱼书 1.1.2 的“网页与订阅 → 网页”导入。当前 `.fishweb` 导入和更新需鱼书 Pro；已导入的单文件 HTML 也可调用同一 GPU 桥接。页面点击“开始绘制”后检测能力、打开会话、上传资源并提交显示批次；点击“停止”或离开页面时释放会话。此例不需要网络或账号。

离线运行 `node smoke-test.mjs` 只检查示例归档、着色器字节和协议包编码；实际画面须在支持 Vulkan 的鱼书设备上验证。完整接口及限制见[1.1.2 原生 Vulkan 图形接口](../../docs/18-1.1.2-Vulkan图形接口.md)。
