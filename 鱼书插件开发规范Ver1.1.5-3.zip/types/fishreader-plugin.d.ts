/** FishReader HarmonyOS 1.1.5 public plugin SDK 1.0 editor declarations; guide Ver1.1.5-2. */

type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

interface FishReaderHttpRequest {
  url: string;
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD';
  headers?: Record<string, string>;
  body?: string;
  bodyBase64?: string;
  charset?: string;
  contentType?: string;
  responseType?: 'text' | 'bytes';
  followRedirects?: boolean;
  timeoutMs?: number;
  dnsIp?: string;
}

/** Only for request objects returned by searchPrepareBatch. */
interface FishReaderPreparedHttpRequest extends FishReaderHttpRequest {
  retry?: number;
}

interface FishReaderHttpResponse {
  status: number;
  url: string;
  headers: Record<string, string>;
  body: string;
  data?: number[];
}

interface FishReaderHttpBatchItem {
  index?: number;
  ok: boolean;
  result?: FishReaderHttpResponse;
  noData?: boolean;
  error?: string;
  timedOut?: boolean;
}

interface FishReaderHtmlParseRequest {
  html: string;
  selector: string;
  value?: 'text' | 'textNodes' | 'ownText' | 'html' | 'all' | 'innerHTML' | 'outerHTML' | 'attribute';
  attribute?: string;
  all?: boolean;
  limit?: number;
}

interface FishReaderDatabaseStatement {
  sql: string;
  bindArgs?: Array<string | number | boolean | null | Uint8Array>;
}

interface FishReaderDatabaseQuery extends FishReaderDatabaseStatement {
  maximumRows?: number;
}

interface FishReaderDatabaseResult {
  columns: string[];
  rows: Array<Record<string, JsonValue>>;
  truncated: boolean;
}

interface FishReaderBookSummary {
  bookKey: string;
  title: string;
  sourceKey?: string;
  sourceName?: string;
  author?: string;
  intro?: string;
  coverUrl?: string;
  bookUrl?: string;
  latestChapter?: string;
  wordCount?: string;
  types?: string[];
  publicationStatus?: string;
  kind?: string;
  lastUpdated?: string;
  mediaType?: '' | 'text' | 'comic' | 'audiobook' | 'video' | 'file';
}

interface FishReaderBookDetail extends FishReaderBookSummary {
  tocUrl?: string;
  canReName?: boolean;
  downloadUrls?: string[];
  chapterCount?: number;
}

interface FishReaderSearchTarget {
  sourceKey: string;
  name: string;
  groups?: string[];
  homeUrl?: string;
  iconUrl?: string;
  iconMode?: 'url' | 'embedded';
  iconRevision?: string;
  metadataDeferred?: boolean;
  /** Target classification; common values include text, comic, audiobook, video and file. */
  mediaType?: string;
}

interface FishReaderPreparedSearchItem {
  sourceKey: string;
  sourceName: string;
  request?: FishReaderPreparedHttpRequest;
  parseContext?: Record<string, JsonValue>;
  books?: FishReaderBookSummary[];
  fallback?: boolean;
  errorMessage?: string;
  timedOut?: boolean;
}

interface FishReaderBatchSearchItem {
  sourceKey: string;
  sourceName: string;
  books: FishReaderBookSummary[];
  errorMessage?: string;
  timedOut?: boolean;
}

interface FishReaderChapter {
  chapterKey: string;
  title: string;
  ordinal: number;
  chapterUrl?: string;
  /** Portable JSON context, at most 262144 UTF-8 bytes; forwarded as content input.chapter. */
  locator?: Record<string, JsonValue>;
  isVolume?: boolean;
  isLocked?: boolean;
  mediaType?: '' | 'text' | 'comic' | 'audiobook' | 'video' | 'file';
  /** Publication/update time supplied by the content provider, at most 128 characters. */
  updateTime?: string;
}

interface FishReaderContent {
  content: string;
  contentType?: 'text' | 'audio' | 'video' | 'structured';
  mediaUrl?: string;
  mediaUrls?: string[];
  mediaHeaders?: Record<string, string>;
  mediaEncryption?: { algorithm: 'cenc'; keyHex: string };
  toneOptions?: Array<{ value: string; label: string }>;
  message?: string;
  baseUrl?: string;
  title?: string;
  imageStyle?: string;
}

interface FishReaderImageResult {
  dataBase64: string;
  contentType?: string;
}

interface FishReaderActionResult {
  handled?: boolean;
  value?: JsonValue;
  openUrl?: string;
  messages?: JsonValue[];
  uiEffects?: JsonValue[];
  browser?: JsonValue;
}

interface FishReaderEntrypointInput {
  [key: string]: JsonValue | undefined;
}

interface FishReaderExploreMenuInput extends FishReaderEntrypointInput {
  exploreStateJson?: string;
  filtersJson?: string;
}

interface FishReaderExploreInput extends FishReaderEntrypointInput {
  category: string;
  page: number;
  exploreStateJson?: string;
}

interface FishReaderExploreMenuItem {
  key: string;
  title: string;
  group?: string;
  filterType?: 'select' | 'toggle' | 'text' | 'button';
  options?: string[];
  value?: string;
  stateJson?: string;
  resultCategoryKey?: string;
}

interface FishReaderContentInput extends FishReaderEntrypointInput {
  bookKey: string;
  chapterKey: string;
  sourceKey?: string;
  bookUrl?: string;
  tocUrl?: string;
  chapterUrl?: string;
  cacheBookId?: string;
  customVariable?: string;
  mediaType?: string;
  book?: Record<string, JsonValue>;
  chapter?: Record<string, JsonValue>;
}

interface FishReaderWebViewRequest {
  url: string;
  html?: string;
  headers?: Record<string, string>;
  javaScript?: string;
  sourceRegex?: string;
  overrideRegex?: string;
  fallbackOnPageEnd?: boolean;
  verificationJavaScript?: string;
  completionJavaScript?: string;
  delayMs?: number;
  timeoutMs?: number;
}

interface FishReaderCatalogTransaction {
  bookId: string;
  transactionId: string;
}

interface FishReaderCatalogBegin extends FishReaderCatalogTransaction {
  generation: string;
  sourceBinding?: string;
  fingerprint?: string;
  chapterCount: number;
}

interface FishReaderCatalogManifest {
  schemaVersion: number;
  bookIdHash: string;
  ownerPluginId: string;
  generation: string;
  sourceBinding: string;
  fingerprint: string;
  chapterCount: number;
  updatedAtMs: number;
  chunks: Array<{ index: number; offset: number; length: number }>;
}

interface FishReaderRuntimeApi {
  environment?: {
    info(): Promise<{
      version: string;
      buildNumber: number;
      device: string;
      id: string;
      userAgent: string;
      qysgBrowserVersion: number;
    }>;
  };
  http: {
    fetch(request: FishReaderHttpRequest): Promise<FishReaderHttpResponse>;
    fetchBatch(request: { requests: FishReaderHttpRequest[]; concurrency?: number }): Promise<FishReaderHttpBatchItem[]>;
  };
  cookie: {
    get(url: string): Promise<string>;
    getBatch(urls: string[]): Promise<Record<string, string>>;
    set(url: string, cookie: string): Promise<boolean>;
    clear(url?: string): Promise<boolean>;
  };
  storage: {
    get(key: string): Promise<JsonValue>;
    getBatch(keys: string[]): Promise<Record<string, JsonValue>>;
    set(key: string, value: JsonValue): Promise<boolean>;
    removeBatch(keys: string[]): Promise<boolean>;
    removeByPrefix(prefix: string): Promise<number>;
  };
  source: {
    getVariable(): Promise<JsonValue>;
    setVariable(value: JsonValue): Promise<boolean>;
  };
  database: {
    execute(request: FishReaderDatabaseStatement): Promise<boolean>;
    batch(request: { statements: FishReaderDatabaseStatement[] }): Promise<number>;
    query(request: FishReaderDatabaseQuery): Promise<FishReaderDatabaseResult>;
    queryJson(request: FishReaderDatabaseStatement): Promise<JsonValue>;
  };
  html: {
    parse(request: FishReaderHtmlParseRequest): Promise<string | string[] | null>;
    parseBatch(request: { requests: FishReaderHtmlParseRequest[] }): Promise<Array<string | string[] | null>>;
  };
  file: {
    read(request: { path: string; charset?: string }): Promise<string | number[]>;
    write(request: { path: string; content?: string; data?: number[]; charset?: string }): Promise<string>;
    delete(path: string): Promise<boolean>;
    download(request: { url: string }): Promise<string>;
    readTextFolder(request: { path: string; charset?: string }): Promise<string>;
  };
  archive: {
    zipEntry(request: { path?: string; url?: string; data?: number[]; entry: string }): Promise<number[]>;
    extract(request: { path: string }): Promise<string>;
    gzipEncode(request: { data: number[] }): Promise<number[]>;
    gzipDecode(request: { data: number[] }): Promise<number[]>;
    inflateDecode(request: { data: number[] }): Promise<number[]>;
  };
  text: {
    convert(request: { text: string; direction?: 't2s' | 's2t' }): Promise<string>;
    decode(request: { data: number[]; charset: string }): Promise<string>;
    encode(request: { text: string; charset: string }): Promise<number[]>;
  };
  crypto: {
    digest(request: { algorithm: string; text?: string; data?: number[] }): Promise<{ algorithm: string; hex: string; base64: string }>;
    hmac(request: { algorithm: string; key?: string; keyData?: number[]; text?: string; data?: number[] }): Promise<{ algorithm: string; hex: string; base64: string }>;
    cipher(request: { transformation: string; operation: 'encrypt' | 'decrypt'; key: number[]; iv?: number[]; data: number[] }): Promise<{ transformation: string; data: number[] }>;
    asymmetric(request: { transformation: string; operation: 'encrypt' | 'decrypt'; publicKey?: string; privateKey?: string; usePublicKey?: boolean; data: number[] }): Promise<{ transformation: string; data: number[] }>;
    sign(request: { algorithm: string; privateKey: string; data: number[] }): Promise<{ transformation: string; data: number[] }>;
    verify(request: { algorithm: string; publicKey: string; data: number[]; signature: number[] }): Promise<boolean>;
  };
  webview: {
    execute(request: FishReaderWebViewRequest): Promise<FishReaderHttpResponse>;
  };
  result: {
    emit(value: JsonValue): boolean | Promise<boolean>;
  };
  catalogCache: {
    begin(request: FishReaderCatalogBegin): Promise<string>;
    writeChunk(request: FishReaderCatalogTransaction & { index: number; value: JsonValue }): Promise<boolean>;
    commit(request: FishReaderCatalogTransaction & { deferActivation?: boolean }): Promise<boolean>;
    abort(request: FishReaderCatalogTransaction): Promise<boolean>;
    readManifest(request: string | { bookId: string; generation?: string }): Promise<FishReaderCatalogManifest | null>;
    readChunk(request: { bookId: string; generation: string; index: number }): Promise<JsonValue>;
    deleteBook(bookId: string): Promise<boolean>;
  };
}

declare const reader: Readonly<FishReaderRuntimeApi>;

interface FishReaderManagementApi {
  ready: Promise<void>;
  call(operation: string, args?: Record<string, JsonValue>): Promise<JsonValue>;
  http: {
    fetch(request: FishReaderHttpRequest): Promise<FishReaderHttpResponse>;
    downloadDataFile(request: FishReaderHttpRequest): Promise<{ token: string; size: number }>;
  };
  storage: {
    get(key: string): Promise<JsonValue>;
    set(key: string, value: JsonValue): Promise<boolean>;
    removeBatch(keys: string[]): Promise<boolean>;
  };
  catalogCache: FishReaderRuntimeApi['catalogCache'];
  database: Pick<FishReaderRuntimeApi['database'], 'execute' | 'batch' | 'query'>;
  source: FishReaderRuntimeApi['source'];
  cookie: Pick<FishReaderRuntimeApi['cookie'], 'get' | 'set' | 'clear'>;
  crypto: Pick<FishReaderRuntimeApi['crypto'], 'digest'>;
  html: Pick<FishReaderRuntimeApi['html'], 'parse'>;
  plugin: {
    execute(entrypoint: 'manage', input?: Record<string, JsonValue>): Promise<JsonValue>;
    registerFileImport?(entrypoint: string, handler: () => void | Promise<void>): void;
    validateSourcesAsync(input: { sourceKeys: string[]; keyword?: string; concurrency?: number }): Promise<{ executionId: string }>;
    executionStatus(executionId: string): Promise<Record<string, JsonValue>>;
    requestNetworkDomains(domains: string[]): Promise<{ granted: boolean; domains: string[] }>;
  };
  ui: {
    pickTextFile(): Promise<string>;
    pickDataFile(): Promise<{ token: string; size: number }>;
    pickDataFiles?(): Promise<Array<{ token: string; size: number; name: string; error?: string }>>;
    readDataFile(token: string, offset: number, maximumBytes: number): Promise<{ offset: number; nextOffset: number; size: number; eof: boolean; base64: string }>;
    closeDataFile(token: string): Promise<boolean>;
    createExportFile(suggestedName: string): Promise<{ token: string }>;
    writeExportFile(token: string, base64: string): Promise<{ size: number }>;
    finishExportFile(token: string): Promise<{ size: number }>;
    cancelExportFile(token: string): Promise<boolean>;
    openLoginBrowser(request: string | { url: string; title?: string }): Promise<JsonValue>;
    takeLaunchUrl?(): Promise<string>;
    takeLaunchAction?(): Promise<{ id: string; targetKey: string } | null>;
    close(): Promise<boolean>;
  };
}

declare const FishReader: Readonly<FishReaderManagementApi>;

/** Available to a fishreader-html plugin page, not to an imported standalone webpage. */
interface FishReaderPageNavigationBridge { setDepth(depth: number): void; }
declare const FishReaderPageNavigation: FishReaderPageNavigationBridge | undefined;

interface FishReaderWebVideoEpisode {
  id: string;
  title: string;
  episodeNumber?: number;
  /** Required by legacy/full-list mode; may be empty only after inlineEpisodeRequest capability succeeds. */
  url?: string;
  headers?: Record<string, string>;
  localRelay?: boolean;
  posterUrl?: string;
  durationMs?: number;
  danmakuEpisodeId?: number;
  mediaOptions?: FishReaderWebVideoMediaOptions;
}

interface FishReaderWebVideoMediaOptions {
  encryptionMethod?: string;
  decryptionKeyHex?: string;
  keyIdHex?: string;
  ivHex?: string;
  /** Compatibility alias for ivHex; ivHex wins when both are present. */
  defaultIvHex?: string;
}

interface FishReaderWebVideoSeason {
  id: string;
  title: string;
  episodes: FishReaderWebVideoEpisode[];
}

interface FishReaderWebVideoQualityOption {
  id: string;
  label?: string;
  resolution?: string;
  bitrate?: number;
}

interface FishReaderWebVideoExternalSubtitle {
  url: string;
  title?: string;
  language?: string;
  codec?: string;
  streamIndex?: number;
  headers?: Record<string, string>;
}

interface FishReaderWebVideoLiveLine { id?: string; title?: string; url: string; }
interface FishReaderWebVideoLiveProgram {
  start?: string;
  end?: string;
  title?: string;
  startMs?: number;
  endMs?: number;
}

interface FishReaderWebVideoSkipSettings {
  introMs?: number;
  outroMs?: number;
  introMode?: 'hint' | 'skip';
  outroMode?: 'hint' | 'skip';
}

interface FishReaderWebVideoPlaybackRequest {
  version?: number;
  url?: string;
  /** Route media through the app's loopback Range/HLS relay when supported. */
  localRelay?: boolean;
  autoPlayNext?: boolean;
  title?: string;
  seriesTitle?: string;
  /** A real HTTP(S) document URL is required to infer a default media Referer. */
  pageUrl?: string;
  headers?: Record<string, string>;
  mediaOptions?: FishReaderWebVideoMediaOptions;
  danmaku?: { provider?: string; externalSubjectType?: string; externalSubjectId?: string;
    searchTitle?: string; sourceUrl?: string };
  danmakuComposer?: { enabled: boolean; submitEvent: string; placeholder?: string };
  inlineProgressEvent?: string;
  inlineEndedEvent?: string;
  inlineBackEvent?: string;
  inlineRefreshEvent?: string;
  inlineReturnEvent?: string;
  currentSeasonId?: string;
  currentEpisodeId?: string;
  seasons?: FishReaderWebVideoSeason[];
  skip?: FishReaderWebVideoSkipSettings;
  skipChangeEvent?: string;
  /** Optional Harmony webpage event name for the latest episode and position on return. */
  progressEvent?: string;
  /** Stable webpage-owned record key echoed in the progress event. */
  progressKey?: string;
  /** Optional webpage event used to re-resolve the current episode URL. */
  refreshEvent?: string;
  /** Optional webpage event used by the open player to resolve another episode. */
  episodeRequestEvent?: string;
  qualityRequestEvent?: string;
  qualityOptions?: FishReaderWebVideoQualityOption[];
  qualitySelectedId?: string;
  qualityTitle?: string;
  selectedVideoIndex?: number;
  selectedAudioIndex?: number;
  /** -1 disables subtitles. */
  selectedSubtitleIndex?: number;
  externalSubtitles?: FishReaderWebVideoExternalSubtitle[];
  liveChannelMode?: boolean;
  liveLines?: FishReaderWebVideoLiveLine[];
  liveLineIndex?: number;
  livePrograms?: FishReaderWebVideoLiveProgram[];
  /** Seconds before the effective end at which the next episode is resolved. */
  prefetchNextSeconds?: number;
  /** Optional in-play progress event interval in seconds. */
  progressIntervalSeconds?: number;
  /** Resume position for the initially selected episode only. */
  startPositionMs?: number;
  sessionId?: string;
}

interface FishReaderWebVideoCapabilities {
  inlineEpisodeRequest?: boolean;
  nativeInlinePlayer?: boolean;
  seamlessInlineFullscreen?: boolean;
  generic?: {
    qualitySwitch?: boolean;
    prefetchNext?: boolean;
    progressInterval?: boolean;
    startPosition?: boolean;
    danmakuReference?: boolean;
    specifiedDanmakuSource?: boolean;
    danmakuComposer?: boolean;
    danmakuSubmitResult?: boolean;
    inlineOverlayOcclusion?: boolean;
    localRelay?: boolean;
  };
}

interface FishReaderWebVideoEpisodeRequestDetail {
  version: number;
  sessionId: string;
  requestId: string;
  progressKey: string;
  seasonId: string;
  episodeId: string;
  episodeNumber: number;
  purpose?: 'prefetch' | 'switch';
  lineIndex?: number;
}

interface FishReaderWebVideoQualityRequestDetail {
  requestId: string;
  sessionId: string;
  progressKey: string;
  seasonId: string;
  episodeId: string;
  qualityId: string;
  positionMs: number;
}

interface FishReaderWebVideoEpisodeResponse {
  sessionId: string;
  requestId: string;
  url?: string;
  headers?: Record<string, string>;
  localRelay?: boolean;
  mediaOptions?: FishReaderWebVideoMediaOptions;
  posterUrl?: string;
  durationMs?: number;
  qualityOptions?: FishReaderWebVideoQualityOption[];
  qualitySelectedId?: string;
  selectedVideoIndex?: number;
  selectedAudioIndex?: number;
  selectedSubtitleIndex?: number;
  externalSubtitles?: FishReaderWebVideoExternalSubtitle[];
  liveLines?: FishReaderWebVideoLiveLine[];
  liveLineIndex?: number;
  livePrograms?: FishReaderWebVideoLiveProgram[];
  error?: string;
}

interface FishReaderWebVideoProgressDetail {
  version: number;
  sessionId: string;
  progressKey: string;
  seasonId: string;
  episodeId: string;
  episodeNumber: number;
  positionMs: number;
  durationMs: number;
  completed: boolean;
  started?: boolean;
  stopped?: boolean;
  isPaused?: boolean;
  updatedAt: number;
  sequence: number;
}

interface FishReaderWebPageBridge {
  httpGetAsync(url: string, headersJson: string, responseMode?: string): Promise<string>;
  httpPostAsync(url: string, body: string, headersJson: string, responseMode?: string): Promise<string>;
  httpRequestAsync?(method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', url: string,
    body: string, headersJson: string, responseMode?: string): Promise<string>;
  httpGetBinaryAsync(url: string, headersJson: string, maxBytes?: number): Promise<string>;
  httpGetTextAsync(url: string, headersJson: string, responseMode?: string): Promise<string>;
  jsvmExecuteAsync(code: string): Promise<string>;
  getSyncHttpEndpointAsync?(): Promise<string>;
  getStorageAsync(key: string): Promise<string>;
  parseUrlAsync(url: string): Promise<string>;
  readFileAsync(path: string): Promise<string>;
  pickFileAsync(suffix: string): Promise<string>;
  /** Imported local webpage entry main frame only; returns an operation-specific string. */
  nodeRuntimeRequestAsync?(requestJson: string): Promise<string>;
  webpageBookLookupAsync?(key: string): Promise<string>;
  webpageBookListAsync?(): Promise<string>;
  webpageBookDownloadAsync?(requestJson: string): Promise<string>;
  webpageBookStatus?(taskId: string): string;
  webpageBookOpenAsync?(key: string): Promise<string>;
  webpageBookSearchSourceAsync?(keyword: string, autoSearch?: boolean): Promise<string>;
  webpageSecretGetAsync?(key: string): Promise<string>;
  webpageSecretSetAsync?(key: string, value: string): Promise<string>;
  webpageHttpSessionAsync?(url: string, method: string, body: string, headersJson: string,
    sessionKey: string, includeCookies: boolean, optionsJson?: string): Promise<string>;
  webpageVerifyAsync?(requestJson: string): Promise<string>;
  webpageVerifySubmitAsync?(code: string): Promise<string>;
  webpageVerifyCancel?(): void;
  setStorage(key: string, value: string): void | string;
  sniffAsync?(url: string, optionsJson: string): Promise<string>;
  openWebView(url: string): void;
  toast(message: string): void | string;
}

/** Optional seventh argument of webpageHttpSessionAsync, JSON-encoded before calling. */
interface FishReaderBrowserSessionOptions {
  transport?: 'http' | 'browser';
  timeoutMs?: number;
  maxBytes?: number;
  readDocument?: boolean;
  responseType?: 'text' | 'base64' | 'media';
  resource?: boolean;
  crossOrigin?: 'same-origin' | 'cors';
  routing?: 'origin';
  mediaFailureEvent?: string;
}

interface FishReaderVerifyCapabilities {
  version: number;
  retainedSession?: boolean;
  transport?: 'browser';
  originRouting?: boolean;
  sessionRouting?: boolean;
  managedContexts?: boolean;
  binaryResponse?: boolean;
  mediaRelay?: boolean;
  browserResources?: boolean;
  browserCors?: boolean;
  mediaFailureEvents?: boolean;
  sameOrigin?: boolean;
  manualConfirmation?: boolean;
  maxBrowserContexts?: number;
  maxConcurrentRequests?: number;
  maxResponseBytes?: number;
}

interface FishReaderBrowserSessionReply {
  status: number;
  url: string;
  headers: Record<string, string>;
  body: string;
  responseType?: 'base64' | 'media';
  routing?: 'origin';
}

interface FishReaderWebVideoBridge {
  play(input: string): void;
  playInline?(requestJson: string, rectJson: string): void;
  updateInlineRect?(rectJson: string): void;
  setInlineOccluded?(occluded: boolean): void;
  closeInline?(): void;
  /** JSON-encoded FishReaderWebVideoCapabilities. */
  capabilities?(): string;
  /** Answers one pending episode request; false means stale/invalid response. */
  respondEpisode?(responseJson: string): boolean;
  respondQuality?(responseJson: string): boolean;
  respondDanmaku?(responseJson: string): boolean;
  pendingProgress?(): string;
  acknowledgeProgress?(payloadJson: string): void;
}

interface FishReaderDiscoverBridge {
  capabilities(): string;
  requestAsync(requestJson: string): Promise<string>;
  openDetailAsync(requestJson: string): Promise<string>;
}

/** A source-kind plugin currently installed and enabled in FishReader. */
interface FishReaderWebContentPlugin {
  pluginId: string;
  name: string;
  version: string;
  entrypoints: Array<'searchTargets' | 'search' | 'exploreMenu' | 'explore' |
    'detail' | 'catalog' | 'content' | 'image' | 'loginCheck'>;
  exploreCategories: Array<{ key: string; title: string; group: string }>;
}

interface FishReaderWebContentPluginRequest {
  pluginId: string;
  entrypoint: FishReaderWebContentPlugin['entrypoints'][number];
  input?: Record<string, unknown>;
}

interface FishReaderWebContentPluginReply {
  schemaVersion: 1;
  ok: boolean;
  pluginId: string;
  entrypoint: string;
  durationMs?: number;
  result?: unknown;
  error?: { code: string; message: string; retryable?: boolean };
}

/** Only for the main frame of an imported local HTML or .fishweb entry. */
interface FishReaderPluginsBridge {
  capabilities(): string;
  /** JSON-encoded FishReaderWebContentPlugin[]. */
  listAsync(): Promise<string>;
  /** JSON-encoded FishReaderWebContentPluginReply. */
  invokeAsync(requestJson: string): Promise<string>;
}

/** Available only to a user-imported local webpage entry main frame. */
interface FishReaderWebpageResourceBridge {
  getAppVersion(): string;
  requestAsync(requestJson: string): Promise<string>;
  listInstalledAsync(type: 'plugin' | 'web'): Promise<string>;
  importPackageAsync(requestJson: string): Promise<string>;
  updateLocalHtmlAsync(requestJson: string): Promise<string>;
}

interface FishReaderWebpageResourceHttpRequest {
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD';
  headers?: Record<string, string>;
  body?: string;
  bodyBase64?: string;
  timeoutMs?: number;
  maxRedirects?: number;
}

interface FishReaderWebpageResourcePackageRequest {
  type: 'plugin' | 'web';
  sourceId: string;
  name: string;
  version: string;
  filename: string;
  bytes: number;
  sha256: string;
  urls: Array<{ url: string; headers?: Record<string, string>;
    parts?: Array<{ url: string; bytes: number; sha256: string }> }>;
  encryption?: { algorithm: 'AES-256-GCM'; keyHex: string; iv: string; tag: string;
    aad: string; cipherSha256: string; cipherBytes: number };
  /** Optional event identifier, 1-64 ASCII letters, digits, underscores or hyphens. */
  progressId?: string;
  /** Only updateLocalHtmlAsync accepts targetIds. */
  targetIds?: string[];
}

interface FishReaderNodeScriptRequest {
  /** ensureModule is a compatibility no-op on HarmonyOS 0.9.6. */
  op: 'status' | 'ensureModule' | 'pickFiles' | 'downloadFiles' | 'writeText' | 'configure' | 'call' | 'remove';
  id?: string;
  name?: string;
  source?: string;
  files?: Array<{ name: string; url: string; checksum?: string; checksumUrl?: string; optional?: boolean }>;
  archiveEntry?: string;
  archiveEntryCandidates?: string[];
  archiveFiles?: string[];
  /** Retain the selected ZIP inside this webpage's bundle under a safe file name. */
  archiveKeepAs?: string;
  archiveKeepForEntries?: string[];
  fileName?: string;
  text?: string;
  entry?: string;
  readyPath?: string;
  path?: string;
  method?: 'GET' | 'POST';
  body?: string;
  timeout?: number;
  /** With setupPath, initialize once per active script process before the call. */
  setupKey?: string;
  setupPath?: string;
  setupMethod?: 'GET' | 'POST';
  setupBody?: string;
}

interface FishReaderNodeScriptBundle {
  id: string;
  name: string;
  source: string;
  files: Array<{ name: string; size: number; md5: string; text?: string }>;
  entry?: string;
  readyPath?: string;
}

interface FishReaderNodeScriptStatus {
  /** True on HarmonyOS 0.9.6; older hosts may report a missing module. */
  moduleInstalled: boolean;
  bundles: FishReaderNodeScriptBundle[];
}

interface FishReaderNodeScriptOperationResult {
  cancelled?: boolean;
  bundle?: FishReaderNodeScriptBundle;
  removed?: string;
  archiveEntry?: string;
  archivePrefix?: string;
}

interface FishReaderWebMediaStatus {
  title: string;
  artist?: string;
  album?: string;
  artwork?: string;
  state: 'playing' | 'paused';
  /** Seconds. */
  position: number;
  /** Seconds. */
  duration: number;
}

/** The active webpage main frame owns this system media session. */
interface FishReaderWebMediaBridge {
  capabilities(): string;
  publish(statusJson: string): void;
  clear(): void;
}

/** Snapshot returned as JSON text by FishReaderClub.getPalette(). */
interface FishReaderHtmlPalette {
  darkMode: boolean;
  page: string;
  surface: string;
  surfaceMuted: string;
  divider: string;
  primaryText: string;
  secondaryText: string;
  hintText: string;
  accent: string;
  accentSoft: string;
  onAccent: string;
  border: string;
  navigationFill: string;
  danger: string;
}

/** Palette is shared by imported local webpages and fishreader-html management pages.
 *  Consent/data methods are present only on imported local webpage entry frames. */
interface FishReaderClubBridge {
  /** JSON-encoded FishReaderHtmlPalette; does not require bookshelf/statistics consent. */
  getPalette(): string;
  getConsent?(): string;
  setConsentAsync?(section: 'recommendations' | 'rankings', enabled: boolean): Promise<string>;
  recommendationsAsync?(): Promise<string>;
  coverBase64Async?(relativePath: string): Promise<string>;
  bookshelfGroupsAsync?(): Promise<string>;
  /** Opens an active bookshelf book by the id returned from bookshelfGroupsAsync; "missing" also covers a locked hidden book. */
  openBookshelfBookAsync?(bookId: string): Promise<'ok' | 'missing'>;
  rankingsAsync?(): Promise<string>;
  metadataAsync?(bookIdsJson: string): Promise<string>;
}

/** Only a saved .fishweb root index.html frame with shared-files.json may open this channel. */
interface FishSharedFilesBridge {
  /** Initiates the channel; wait for fish-files-v1 and its ready message. */
  open(): void;
  /** Releases ports, snapshots, writers and namespace ownership. */
  close(): void;
}

/** Inbound HTTP request delivered to an imported local webpage's main frame. */
interface FishHttpServiceRequest {
  method: string;
  url: string;
  target: string;
  headers: Record<string, string>;
  port: number;
  signal: AbortSignal;
  body: Uint8Array;
  text(): Promise<string>;
  json(): Promise<JsonValue>;
  arrayBuffer(): Promise<ArrayBuffer>;
}

interface FishHttpServiceHandle {
  readonly port: number;
  readonly urls: readonly string[];
  readonly closed: boolean;
  close(): Promise<void>;
}

type FishHttpServiceReply = Response | string | ArrayBuffer | ArrayBufferView | JsonValue | {
  status?: number;
  headers?: Record<string, string> | Headers;
  body?: JsonValue | ArrayBuffer | ArrayBufferView;
};

/** The app's document-start helper; FishHttpServiceNative is its internal transport. */
interface FishHttpServiceBridge {
  readonly version: 1;
  listen(port: number, handler: (request: FishHttpServiceRequest) => FishHttpServiceReply | Promise<FishHttpServiceReply>): Promise<FishHttpServiceHandle>;
  closeAll(): void;
}

/** Imported local HTML / fishweb root only. All bridge results are strings. */
interface FishReaderBooksBridge {
  capabilities(): string;
  /** Returns JSON {read,progress,addToShelf}; authorization is document-scoped. */
  authorizeAsync(writeProgress:boolean, addToShelf?:boolean):Promise<string>;
  requestAsync(requestJson:string):Promise<string>;
}
interface FishReaderTextProgress {
  version:1; kind:'text'; chapterIndex:number; chapterKey:string; characterOffset:number;
  anchorBefore:string; anchorAfter:string; contentHash:string; chapterFraction:number;
}
interface FishReaderWebComicProgress {
  version:1; kind:'comic'; chapterIndex:number; chapterKey:string;
  imageIndex:number; imageKey:string; imageOffsetRatio:number;
}
interface FishReaderWebAudioProgress {
  version:1; kind:'audio'; chapterIndex:number; chapterKey:string;
  positionMs:number; durationMs:number; playbackSpeed:number;
}
type FishReaderWebReadingProgress = FishReaderTextProgress | FishReaderWebComicProgress | FishReaderWebAudioProgress;
interface FishReaderWebBookSummary {
  id:string; importId:string|null; title:string; author:string; type:string; locationType:string;
  kind:'text'|'comic'|'audio'; hidden:boolean; groups:string[]; tags:string[]; chapters:number;
  progress:FishReaderWebReadingProgress; progressUpdatedAt:number;
  source:{pluginId:string;sourceKey:string;bookKey:string;detailUrl:string}|null;
}
type FishReaderBookReference = {bookId:string;importId?:string}|{bookId?:string;importId:string};
type FishReaderBookSessionRequest = FishReaderBookReference & {token:string};
type FishReaderBookSortBy = 'title'|'author'|'progressUpdatedAt'|'importedAt'|'updatedAt';
type FishReaderBookRequest =
  | {op:'list';offset?:number;limit?:number;sortBy?:FishReaderBookSortBy;sortOrder?:'asc'|'desc'}
  | (FishReaderBookReference & {op:'detail'|'getProgress'})
  | (FishReaderBookReference & {op:'cover';offset?:number;limit?:number})
  | (FishReaderBookReference & {op:'open';clientId:string;takeover?:boolean})
  | (FishReaderBookSessionRequest & {op:'heartbeat'|'close'})
  | (FishReaderBookSessionRequest & {op:'saveProgress';progress:FishReaderWebReadingProgress;checkpoint?:boolean})
  | (FishReaderBookSessionRequest & {op:'catalog'|'resources';offset?:number;limit?:number})
  | (FishReaderBookSessionRequest & {op:'chapter';chapterIndex:number;chapterKey?:string})
  | (FishReaderBookSessionRequest & {op:'importData';section?:'metadata'|'toc'|'images'|'resources';offset?:number;limit?:number})
  | (FishReaderBookSessionRequest & {op:'resource';path:string;offset?:number;limit?:number})
  | (FishReaderBookSessionRequest & {op:'files';path?:string;directoryId?:string;offset?:number;limit?:number})
  | (FishReaderBookSessionRequest & {op:'fileSource'|'releaseFile';fileId:string})
  | (FishReaderBookSessionRequest & {op:'readFile';fileId:string;offset?:number;limit?:number})
  | {op:'addToShelf';bookId:string}
  | {op:'addToShelf';pluginId:string;detail:FishReaderBookDetail;catalog:FishReaderChapter[]};
interface FishReaderBookError {
  ok:false;code:'BOOK_BUSY'|'SESSION_REVOKED'|'USE_PLUGIN_API'|'BOOK_REQUEST_FAILED';error?:string;
}
interface FishReaderBookCatalogEntry {
  chapterIndex:number;chapterKey:string;title:string;kind:'text'|'comic'|'audio';isVolume:boolean;updatedAt:number;
}
interface FishReaderBookFile {
  fileId:string;name:string;directory:boolean;size:number;relativePath:string;mediaType:string;
  entry?:Record<string,JsonValue>;
}
interface FishReaderImportedTextChapter {
  schemaVersion:number;bookId:string;chapterIndex:number;chapterKey:string;title:string;kind:'text';
  format:'plain'|'html'|'xhtml';content:string;contentHash:string;sourceRevision:string;updatedAt:number;
}
interface FishReaderImportedComicChapter {
  schemaVersion:number;bookId:string;chapterIndex:number;chapterKey:string;title:string;kind:'comic';
  pages:Array<{imageKey:string;file:FishReaderBookFile}>;contentHash:string;updatedAt:number;
}
interface FishReaderImportedAudioChapter {
  schemaVersion:number;bookId:string;chapterIndex:number;chapterKey:string;title:string;kind:'audio';
  media:FishReaderBookFile;durationMs:number;byteSize?:number;contentHash:string;updatedAt:number;
}
type FishReaderImportedChapter = FishReaderImportedTextChapter | FishReaderImportedComicChapter | FishReaderImportedAudioChapter;
/** File offsets are BYTES, limit <= 1 MiB, total may be -1 if unknown. */
interface FishReaderBookBinary {
  ok:true;base64:string;mediaType:string;offset:number;total:number;nextOffset:number;complete:boolean;
}
interface FishReaderBookOpenResult {
  ok:true;token:string;book:FishReaderWebBookSummary;checkpointMissed:boolean;
}
interface FishReaderTransferTaskRequest {type:'dataTransfer';title?:string;}
interface FishReaderTransferTaskStatus {id:string;type:'dataTransfer';running:boolean;transferredBytes:number;error:string;}
interface FishReaderTasksBridge {
  registerAsync(requestJson:string):Promise<string>;
  statusAsync():Promise<string>;
  /** Returns the plain string 'ok'. */
  stopAsync():Promise<string>;
}


interface FishSharedFilesDeclaration {
  version: 1;
  /** 1-64 ASCII letters, digits, underscore or hyphen. */
  namespace: string;
}

interface FishSharedFilesReadyMessage {
  type: 'ready';
  namespace: string;
  /** Physical path for diagnostics only; never hardcode. */
  path: string;
  maxChunkBytes: 33554432;
}

/** FGU1 is a separate binary protocol for imported local webpage entry frames. */
interface FishNativeGPUBridge {
  /** JSON FishNativeGPUCapabilities. */
  capabilities(): string;
  /** One session at a time; JSON viewport rect, returns JSON session limits. */
  open(rectJson: string): string;
  resize(rectJson: string): void;
  /** JSON FishNativeGPUStatus. */
  status(): string;
  close(): void;
}

interface FishNativeGPUCapabilities {
  version: 1;
  backend: 'vulkan';
  transport: 'arraybuffer-messageport';
  protocol: 'FGU1';
  maxInFlight: 2;
  maxPacketBytes: 16777216;
  emulatorSpecific: false;
}

interface FishNativeGPUStatus {
  ready: boolean;
  error: string;
  device?: string;
  extensions?: string;
  sequence?: number;
  submitted?: number;
  completed?: number;
  inFlight?: number;
  peakInFlight?: number;
  queued?: number;
  asyncBatches?: boolean;
  completionEvents?: boolean;
  admissionReceipts?: boolean;
  compactCompletion?: boolean;
  maxPending?: number;
  maxPendingBytes?: number;
  resourceReset?: boolean;
  drawableWidth?: number;
  drawableHeight?: number;
  offscreenTargets?: boolean;
  typedRenderTargets?: boolean;
  genericTargetFormats?: boolean;
  targetFormats?: number[];
  rasterState?: boolean;
  rasterDynamic?: boolean;
  rasterLimits?: unknown;
  signedViewport?: boolean;
  clearDepth?: boolean;
  depthStencilAttachments?: boolean;
  depthStencilFormat?: number;
  depthStencilRectClear?: boolean;
  depthOnlyPipelines?: boolean;
  attachmentRebind?: boolean;
  attachmentColorViews?: boolean;
  attachmentStoreControl?: boolean;
  independentAttachmentExtents?: boolean;
  tileColorRead?: boolean;
  tileCoherentAccelerated?: boolean;
  vertexInputLayouts?: boolean;
  vertexFormats?: number[];
  descriptorSets?: boolean;
  storageBufferClass?: boolean;
  resourceReplacePrefix?: boolean;
  packedBufferAlignment?: number;
  graphicsPushConstants?: number;
  uniformBufferStandardLayout?: boolean;
  shaderFloat16?: boolean;
  shaderInt16?: boolean;
  vertexStorageWrites?: boolean;
  fragmentStorageWrites?: boolean;
  textureLevels?: boolean;
  independentSamplers?: boolean;
  typedImageUploads?: boolean;
  sampledFormats?: number[];
  linearSampledFormats?: number[];
  formatSampling?: boolean;
  compressedImageUploads?: boolean;
  imageRegionUploads?: boolean;
  imageClear?: boolean;
  imageArrays?: boolean;
  cubeImages?: boolean;
  imageComponentViews?: boolean;
  typedColorViews?: boolean;
  extendedSamplers?: boolean;
  rgba4Attachments?: boolean;
  deviceImageTransfers?: boolean;
  imageCopies?: boolean;
  imageBlit?: boolean;
  depthAspectCopies?: boolean;
  depthAspectSampling?: boolean;
  rawImageSubresources?: boolean;
  rawBufferReadback?: boolean;
  separateImageSamplers?: boolean;
  computeBuffers?: boolean;
  computeDispatches?: number;
  storageImages?: boolean;
  storageImageFormats?: number[];
  storageImageExtendedFormats?: boolean;
  binaryReadback?: boolean;
  maxReadbackBytes?: number;
  occlusionQueries?: boolean;
  restoreOcclusionResults?: boolean;
  resourceBytes?: number;
  peakResourceBytes?: number;
  stagingPoolBytes?: number;
  memorySuballocation?: boolean;
  memoryBlocks?: number;
  memoryBlockBytes?: number;
  asyncBufferWrites?: number;
  asyncPipelineCompile?: boolean;
  compiledPipelines?: number;
  pipelineCompileUs?: number;
  pipelineCacheLoadedBytes?: number;
  draws?: number;
  recordUs?: number;
  presentUs?: number;
  fenceResidenceUs?: number;
  statusDelta?: boolean;
  [key: string]: unknown;
}

declare const FishReaderDiscover: Readonly<FishReaderDiscoverBridge> | undefined;
declare const FishReaderPlugins: Readonly<FishReaderPluginsBridge> | undefined;
declare const FishReaderWebpageResource: Readonly<FishReaderWebpageResourceBridge> | undefined;
declare const FishReaderWebMedia: Readonly<FishReaderWebMediaBridge> | undefined;
declare const FishReaderClub: Readonly<FishReaderClubBridge> | undefined;
declare const FishNativeGPU: Readonly<FishNativeGPUBridge> | undefined;
declare const FishSharedFiles: Readonly<FishSharedFilesBridge> | undefined;
declare const FishHttpService: Readonly<FishHttpServiceBridge> | undefined;
declare const FishReaderBooks: Readonly<FishReaderBooksBridge> | undefined;
declare const FishReaderTasks: Readonly<FishReaderTasksBridge> | undefined;
declare const FishPython: Readonly<{ capabilities(): string; requestAsync(payloadJson: string): Promise<string>;
  cancel(requestId: string): boolean }> | undefined;

declare const FishPlayerWebVideo: Readonly<FishReaderWebPageBridge>;
declare const fishreaderwebviewvideo: Readonly<FishReaderWebVideoBridge>;
declare const fishplayerwebviewvideo: Readonly<FishReaderWebVideoBridge>;

interface NodeModuleLike {
  exports: Record<string, (input: any) => any>;
}

declare const module: NodeModuleLike;
