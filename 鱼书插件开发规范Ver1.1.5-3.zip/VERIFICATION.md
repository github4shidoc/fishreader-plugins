# Ver1.1.5-2 开发包验证说明

日期：2026-11-06。本版以完整 Ver1.1.5 的 136 个文件为基线，保留全部文件，新增书籍与长时任务专章，共 137 个文件；旧版目录及归档保留。开发指南版本 1.1.5-2，应用仍为 1.1.5，插件协议 `schemaVersion:1`、SDK `1.0` 未变。

## 1.1.5-2 核对与验证

- 对照网页代理与书籍数据、文件、入架、会话及长时任务实现，核对公开方法、JSON 信封、隐藏标记、导入元数据、原始章节、原始文件范围读取与进度交接。插件内容复用已有插件接口；入架复用原生方法。
- 长时任务明确使用 `MODE_DATA_TRANSFER` / `SUBMODE_LIVE_VIEW_NOTIFICATION`；成功 HTTP 收发才增加字节统计，关联实况通知最多每两秒更新一次，无周期性重新注册。文档区分真实传输、系统通知更新与空闲运行限制。
- `node tools/verify-guide.mjs` 通过：137 个文件、2,232 项契约配方、全部示例、5 个插件包、JSON / Schema / 链接与归档检查通过。
- `tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts` 通过；新网页类型使用独立名称，保留原有内容插件类型。
- 宿主书籍数据、文件、入架、会话、长时任务、HTTP 及原生漫画 / 有声书回归检查共 165 项通过。覆盖排序先于分页、默认顺序兼容、同值稳定顺序、非法参数、原始导入数据不经排版、文件范围与路径边界、独立进度读写、原生入架委托、独占交接、旧 token 拒绝、后台任务清理及静默通知；HTTP 测试使用真实本机 TCP，桥接和系统服务使用测试替身。
- 删除此前草稿的网页专用分页 / 正文正规化、章节准备任务、图片解码、播放列表改写、固定章节缓存及预载。未新增阅读网页或应用固定 HTTP 业务路由。
- Harmony 默认 Debug HAP 完整构建通过。本轮未安装到设备；局域网实际访问、原生 / 网页交接、复杂 EPUB 显示和熄屏长时任务仍需真机验证。未新增浏览器阅读页面。

## Ver1.1.5 验证记录（历史）

日期：2026-11-04。本包以完整的 Ver1.1.2 开发包为底包，保留旧版示例、Schema、工具和历史章节，再增补 1.1.5 接口说明。应用源码当前声明 `versionName: 1.1.5` / `versionCode: 10115`；普通插件协议 `schemaVersion: 1`、建议 SDK `1.0` 均未改版。

## 当前接口与旧版兼容性核对

- 对照 `WebViewPage.ets`、`WebHttpServiceClient.ets`、`WebHttpServiceSession.ets`，确认已导入本地网页入口可用 `FishHttpService.listen()` / `closeAll()`；文档说明页面权限、请求与响应结构、局域网绑定、资源限制和生命周期。`FishHttpServiceNative` 与消息端口仅是内部传输协议。
- 对照 `HarmonySourcePluginService.ets`，确认 `catalog` 目录项接受可选 `updateTime`（最多 128 字符）；目录项与摘要的 `mediaType` 均接受 `file`。此前 1.1.2 类型声明已列出 `file`，但结果 Schema 漏列，本版已修正。
- 对照当前管理页文件选择实现与此前 50 个文件的接口说明，确认 `FishReader.ui.pickDataFiles()` 的单次上限改为 200；单文件 100 MiB 上限、分块读取和逐项错误语义仍适用。历史章节保留原版本说明，同时指向当前限制。
- 对照网页代理注册、网页内容插件桥和普通插件宿主操作，未发现旧版已公开方法被移除或改名；此次可确认的旧接口行为变化为多文件选择上限。网页桥仍限制为已导入的本地网页入口；商店专用及宿主内部辅助接口不计入公开契约。
- 普通插件宿主 `storage.set` / `source.setVariable` 在搜索执行通道中的持久化改为等待异步写入完成；公开调用本来就是异步返回，本包不承诺内部写入方式或未等待调用时的时序。需要先写后读时应等待调用结果。

## 本版可复现检查

- 在开发包根目录执行 `node tools/verify-guide.mjs`：通过，报告 136 个文件；包含 2,232 项契约配方、5 个示例插件包、网页与插件示例、Schema、链接、禁用术语、原生图形及共享文件归档检查。
- 在仓库根目录执行 `node --test scripts/tests/harmony-web-http-service.test.mjs scripts/tests/harmony-chapter-update-date.test.cjs scripts/tests/plugin-multi-file-import.test.mjs`：50 项通过。
- 当前包没有使用被用户排除的特定内容格式称呼，使用通用的“内容提供”与接口名称。
- 上述是源码核对和离线检查。本次未执行 HAP 构建、安装或真机联调；HTTP 服务的局域网连通、目录时间显示及 200 文件选择仍需设备验证。

## 1.1.2 验证记录（历史）

日期：2026-11-03。本开发包以 Ver1.1.1 正式包为底稿，其上游正式基线为 Ver0.9.6；不采用 Ver0.9.8 草稿。Ver1.1.2 同步规范和应用版本号，并新增已导入网页调用内容插件及书架导航的接口；其他公开接口沿用 Ver1.1.1。应用声明为 `versionName: 1.1.2` / `versionCode: 10112`，普通插件协议 `schemaVersion: 1` 不变。

## HTML 配色与内部接口核对

- `WebViewPage.ets` 注册 `FishReaderClub.getPalette()`，调用 `requireSavedBookPage()` 限定已导入本地网页入口主框架，返回同步 JSON 字符串；该方法本身不检查书架或阅读统计授权。
- `HtmlPlugin.ets` 在插件管理页控制器附着时注册同名 `FishReaderClub.getPalette()`，只开放这一方法；配色按与独立网页相同的外观设置、系统深色模式和字段计算，不暴露书架或阅读统计方法。
- 对照 `FishReaderAppearance.ets` 与 `currentPalette()`：返回 `darkMode` 和 13 个颜色字段，随应用外观设置及跟随系统深色模式计算；没有专用配色变更事件。颜色支持 `#RRGGBB` 与 ArkTS 顺序的 `#AARRGGBB`，CSS 示例进行了转换。
- `loadWebsiteStorage` / `saveWebsiteStorage` 由 `WebsiteStorageGlue.ets` 注入脚本调用；`FishReaderAudioStatistics.state` 由播放状态观察脚本调用。已在完整参考中列出内部用途及网页应使用的公开路径。

## 网页调用内容插件核对

- `WebViewPage.ets` 注册 `FishReaderPlugins` 的 `capabilities`、`listAsync` 和 `invokeAsync`，调用前沿用 `requireSavedBookPage()` 校验已导入本地入口主框架；执行期间结合网页生命周期与当前地址检查，避免删除、关闭或导航后继续返回结果。
- `WebpageContentPluginService.ets` 只列出已安装且启用的内容插件，只允许目标、搜索、发现、详情、目录、正文、图片处理与登录状态等数据入口；调用前再次核对插件声明。宿主缓存字段、管理、支付、回调和内部批量调度入口不开放。
- 调用复用 `HarmonySourcePluginService.executeSource()` 的隔离执行、插件网络权限及结果标准化；单次请求最多 1 MiB UTF-16 代码单元，同一网页最多 4 个并发调用。
- 内容结果标准化现在接受 `mediaType: "file"`，使本地网页能读取文件类详情的 `downloadUrls`；`video` 仍按原契约返回媒体地址。该桥不自动播放或下载。
- 独立执行 `normalizePluginMediaType` 验证 `video`、`file` 与大写 `FILE` 均被正确归一化，未知值仍被拒绝；类型声明的摘要和章节 `mediaType` 同步包含 `file`。
- `harmony-search-media-filter.test.cjs` 的 6 项检查通过：应用聚合搜索页仍按既有策略隐藏视频/文件结果；网页桥直接调用指定插件，不经过该展示筛选。

## 网页书架导航核对

- `WebViewPage.ets` 仅在已导入本地网页入口注册 `FishReaderClub.openBookshelfBookAsync(bookId)`，与 `bookshelfGroupsAsync()` 使用相同的页面校验和 `recommendations` 授权。
- `WebpageBookImportService.ets` 将书架 ID 交给应用书籍打开回调；原 `webpageBookOpenAsync(key)` 仍先按当前网页的导入标识查找，不能借此打开其他网页导入的书籍。
- `FishReaderAppShell.ets` 打开前刷新书架，核对 ID 仍存在，复用隐藏分组访问限制，并按当前书籍类型及本地/插件标志分流至阅读、漫画或有声书页面。
- 离线编译只能证明接口和路由能构建；仍需在设备上分别用文字、漫画、有声书、已移除书籍和未解锁的隐藏书籍验证导航结果。

## 0.9.8 草稿差异核对

本地 Ver0.9.8 目录及 ZIP 相对 Ver0.9.6 为新增 8 个文件、修改 23 个文件、未删除文件。实质增量集中在 `.fishweb` 的格式说明和示例；普通插件的 Schema 和 SDK 契约没有新字段。两版自检分别通过，但自检只覆盖静态文档、示例和归档结构，不能证明网页包在设备上完成导入与运行。

按用户提供的发布状态，Ver0.9.8 作为未发布草稿处理，不作为本版底包或兼容性承诺。草稿的版本页、更新记录和“0.9.8 起”描述会使读者误以为该版已正式发布；草稿也没有覆盖当前 1.1.2 源码中的 `.fishweb` Pro 导入/更新要求和包内相对图标。草稿写的“HTML 与 `.fishweb` 不能互相覆盖”只适用于文件选择器入口；现行通用网页资源桥允许双向转换，已在本版明确区分。经当前源码核对，ZIP 根目录入口、相对资源和主框架桥接规则可以纳入 1.1.2，已按现行行为整理为独立章节。仅靠本地档案无法确定 0.9.8 当时未发布的具体原因。

## 其他接口核对

- `FishNativeGPU`：对照 `WebViewPage.ets`、`WebGpuSession.ets`、原生 `protocol.h` / `renderer.cpp` 和通用 JS 帮助模块，核对入口权限、代理方法、二进制消息端口、77 个 opcode、能力字段、队列与回执边界；补齐颜色附件视图、原始子资源、缓冲读回、查询恢复及资源重置。
- `FishSharedFiles`：对照已注册网页代理、`WebSharedFilesSession.ets` 和通用 JS 帮助模块，核对根入口权限、声明、命名空间、端口消息、文件操作与大小上限；增加可导入示例及声明 Schema。
- 网页会话：对照 `WebViewPage.ets`、`BrowserSession.ets`、`OriginRequestRouter.ets`、`WebSyncHttpGateway.ets`，补齐以前完整网页参考未逐项展开的同步 HTTP 入口、会话 HTTP 和人工验证方法。
- 逐项比对独立网页代理注册的 40 个方法、其他网页代理注册方法与普通插件宿主的 16 个公开操作，确认文档中有对应方法名；网页私有持久化脚本辅助方法和内部状态观察器没有作为第三方接口发布。
- `.fishweb`：对照 `SubscriptionWebsiteStore.ets`、`WebpageResourceService.ets` 与 `FishWebPackageService.ets`，核对 Pro 导入、包内相对图标、资源桥流式下载/校验/更新；历史 ZIP 结构继续适用。
- 普通插件包协议 `schemaVersion: 1` 和建议插件 SDK `1.0` 未变；图形协议 `FGU1` 独立计版。

## 可复现离线检查

在开发包根目录运行 `node tools/verify-guide.mjs`：

- 开发包自检通过，报告 135 个文件。
- 插件与网页示例冒烟检查通过；契约配方覆盖 2,232 项。
- 5 个 `dist` 示例包通过静态校验；JSON、Schema 正则、JS 语法、版本号、相对链接及禁用术语检查通过。
- `.fishweb` 示例 ZIP 入口、包内图标与源文件一致；原生图形示例 ZIP、SPIR-V magic 和 `FGU1` 包头检查通过；共享文件示例 ZIP、声明和入口检查通过。
- 对照 `WebViewPage.ets` 与 `HtmlPlugin.ets` 的配色返回对象，`darkMode` 和 13 个颜色字段的名称及顺序完全一致。

在仓库根目录运行 `node --test scripts/tests/plugin-page-actions.test.mjs scripts/tests/plugin-multi-file-import.test.mjs`：23 项通过。新增书架导航接口后，鸿蒙默认 Debug HAP 构建成功，ArkTS 编译通过；构建仍有其他模块的警告。此前的构建已核对 `entry-default-unsigned.hap` 中 `pack.info` 与 `module.json` 的应用版本为 `1.1.2` / `10112`。此前的一次版本号构建曾遇到 `build.log` 的 `EBUSY` 文件占用，原样重试后通过。

此前运行 `node --test scripts/tests/harmony-browser-session.test.cjs scripts/tests/harmony-external-html-import.test.cjs scripts/tests/harmony-website-update-menu.test.cjs scripts/tests/harmony-subscription-website-refresh.test.cjs`：16 项中 15 项通过。失败项为 `fishweb import requires Pro before reading or installing the package`：测试替身缺少 `runTask`，在会员错误断言前抛出 `TypeError`；该测试与本次 `HtmlPlugin.ets` 配色桥变更无关。图形工具的 `sdk_test.mjs`、`checkpoint_resources_test.mjs` 和 `compact_completion_test.mjs` 均通过。

构建与离线检查不等于真机验收；`openBookshelfBookAsync` 的三类书籍导航、`FishReaderPlugins` 的实际页面调用、复杂插件的完整内容获取链路、插件管理页配色读取及外观切换后的重新读取仍需在目标设备上验证。
