# Schema 使用说明

这里的 Schema 覆盖本开发包公开的内容、字典、TTS、网页播放与部分网页桥接契约，不包含主题类插件。主规范为 1.1.5-2，对应应用版本为 1.1.5；部分 Schema 沿用已验证的旧版公开契约。网页资源描述 Schema 已扩展 `.fishweb` 下载/更新、分片和进度 ID。`.fishweb` 本体是 ZIP 格式，不适用 JSON Schema；根目录的 `shared-files.json` 可单独校验，且仍受运行时 4096 字节上限约束。见[网页包格式](../docs/17-1.1.2-fishweb网页包.md)和[共享文件说明](../docs/19-1.1.2-共享文件接口.md)。`FishNativeGPU` 的绘图批次是二进制 `FGU1`，见[图形接口说明](../docs/18-1.1.2-Vulkan图形接口.md)。

- `plugin/plugin-package.schema.json`：插件包顶层结构。
- `common.schema.json`：各 Schema 共用的基础定义。
- `plugin/source-plugin-manifest.schema.json`：Manifest。
- `plugin/*-result.schema.json`：各入口返回值。
- `plugin/image-result.schema.json`：图片变换返回值。
- `plugin/action-result.schema.json`：受控交互动作返回值。
- `plugin/execution-request.schema.json`：宿主执行入口时的请求。
- `plugin/execution-result.schema.json`：统一执行结果外壳。
- `plugin/host-call.schema.json`：宿主桥接调用结构。
- `plugin/web-video-playback-request.schema.json`：网页调用系统视频播放器的结构化请求。
- `plugin/webpage-resource-http-request.schema.json`：本地 HTML 的通用 HTTPS 请求。
- `plugin/webpage-resource-package-request.schema.json`：本地 HTML 导入或更新插件包与网页的资源描述；调用 `importPackageAsync` 时不可包含 `targetIds`。
- `plugin/web-media-status.schema.json`：本地 HTML 发布系统媒体会话的状态。
- `web/shared-files.schema.json`：`.fishweb` 根目录共享文件声明。

Schema 用于编辑器提示、CI 和静态校验；业务上还要遵守 `docs/` 中的跨入口约束，例如 `bookKey`、`chapterKey` 稳定性和媒体类型一致性。

0.5.1 增加章节 `locator` 对象及执行入口 `image`、`payAction`、`callback`。JSON Schema 不能直接表达序列化后的 UTF-8 字节上限，`locator` 的 256 KiB 限制仍须运行时检查。示例回归会验证顶层字段和此边界。

0.7.9 保留 `webPageActions`、`urlSchemes` 和登录声明约束；网页视频请求保留按集取链、预取、实时进度、断点、刷新事件，以及 `mediaOptions.ivHex/defaultIvHex`。未启用按集取链时，每集仍必须有真实 HTTP(S) URL；Schema 允许省略或留空 URL 仅用于能力探测成功后的动态模式，不能替代运行时检查。主题入口不再支持。章节 `locator` 字段已按鸿蒙运行时校验逻辑保留在本包的 `source-result.schema.json` 中。鸿蒙搜索/发现单次上限已更新为 5,000 项。

`tools/validate-package.mjs` 是零依赖包结构校验，不是完整 JSON Schema 引擎。需要通用 Schema 校验时使用支持 Draft 2020-12 的工具，并加载本目录的引用文件。

若本包 Schema、应用内 Schema 与实际公开运行时校验出现差异，应记录具体版本与字段并核对宿主实现；不要根据单条错误信息擅自放宽权限、长度或身份约束。
