# 网页视频播放器桥接协议

本协议适用于网页容器中的普通网页、导入的单文件 HTML 和 1.0.3 起导入的 `.fishweb` 入口网页；`.fishweb` 的包内资源与主框架边界见[格式说明](17-1.1.2-fishweb网页包.md)。

网页调用主接口 `fishreaderwebviewvideo.play(payload)`。兼容别名
`fishplayerwebviewvideo.play(payload)` 行为一致。

`payload` 必须是字符串：旧页面可以直接传 HTTP(S) 视频地址；需要选集或片首片尾时，
传入 `JSON.stringify(request)`，不要直接传 JavaScript 对象。

新增能力必须先探测，不能根据应用版本号或 User-Agent 推断：

```js
const player = window.fishreaderwebviewvideo;
let capabilities = {};
try { capabilities = JSON.parse(player?.capabilities?.() || '{}'); } catch (_) {}
const inlineEpisodeRequest = capabilities.inlineEpisodeRequest === true &&
  typeof player?.respondEpisode === 'function';
```

```js
window.addEventListener('fishreaderwebviewvideo:skipchange', (event) => {
  // 由网页自行保存；播放器不会持久化片首片尾设置。
  saveSkipSettings(event.detail);
});
window.addEventListener('fishreaderwebviewvideo:progress', (event) => {
  // 可选：启用 progressIntervalSeconds 后播放期间也更新，退出时补送最后状态。
  saveViewingProgress(event.detail);
});
window.addEventListener('fishreaderwebviewvideo:refresh', async (event) => {
  // 可选：网页根据当前集 ID 重新解析媒体，随后自行再次调用 play。
  await refreshCurrentEpisode(event.detail);
});
window.addEventListener('fishreaderwebviewvideo:episode-request', async (event) => {
  // 可选：播放器保持打开；网页解析目标集后，以相同 sessionId/requestId 回应。
  const detail = event.detail;
  try {
    // purpose === 'prefetch' 只是预取，不要更新观看记录、导航或调用 play。
    const media = await resolveEpisodeMedia(detail.episodeId);
    fishreaderwebviewvideo.respondEpisode(JSON.stringify({
      sessionId: detail.sessionId, requestId: detail.requestId,
      url: media.url, headers: media.headers, mediaOptions: media.mediaOptions
    }));
  } catch (error) {
    fishreaderwebviewvideo.respondEpisode(JSON.stringify({
      sessionId: detail.sessionId, requestId: detail.requestId, error: String(error)
    }));
  }
});

fishreaderwebviewvideo.play(JSON.stringify({
  version: 1,
  url: 'https://example.com/s1e2.m3u8',
  title: '示例剧集 第2集',
  seriesTitle: '示例剧集',
  pageUrl: 'https://example.com/watch/s1e2', // 使用实际 HTTP(S) 页面地址
  headers: { Referer: 'https://example.com/watch/s1e2' },
  mediaOptions: {
    encryptionMethod: 'cenc',
    decryptionKeyHex: '00112233445566778899aabbccddeeff',
    keyIdHex: 'ffeeddccbbaa99887766554433221100',
    ivHex: '00000000000000000000000000000001'
  },
  currentSeasonId: 's1',
  currentEpisodeId: 'e2',
  seasons: [{
    id: 's1',
    title: '第一季',
    episodes: [
      { id: 'e1', title: '第1集', url: 'https://example.com/s1e1.m3u8' },
      {
        id: 'e2',
        title: '第2集',
        url: 'https://example.com/s1e2.m3u8',
        headers: { Authorization: 'Bearer ...' },
        posterUrl: 'https://example.com/e2.jpg',
        durationMs: 1800000
      }
    ]
  }],
  skip: {
    introMs: 90000,
    outroMs: 60000,
    introMode: 'hint',
    outroMode: 'skip'
  },
  skipChangeEvent: 'fishreaderwebviewvideo:skipchange',
  // 可选：仅需要播放记录回传的网页设置以下两项。
  progressEvent: 'fishreaderwebviewvideo:progress',
  progressKey: 'site-owned-series-id',
  progressIntervalSeconds: 10,
  startPositionMs: 120000,
  episodeRequestEvent: 'fishreaderwebviewvideo:episode-request',
  prefetchNextSeconds: 30,
  refreshEvent: 'fishreaderwebviewvideo:refresh'
}));
```

说明：

- `url`、`title`、`seriesTitle`、`pageUrl`、`headers`、季/集、当前季/集和片首片尾字段均为可选扩展；旧 URL 调用不受影响。
- `title` 是当前视频的完整标题，单集也应显式传递；存在选集时建议同时传作品名
  `seriesTitle`。播放器切集后会以 `seriesTitle + episode.title` 更新顶部标题和弹幕搜索词。
- `id` 使用字符串。缺省时宿主会按数组位置补稳定 ID；无效或非 HTTP(S) 的集会被忽略。
- 鸿蒙网页可先读取 `JSON.parse(fishreaderwebviewvideo.capabilities()).inlineEpisodeRequest`，并确认 `respondEpisode` 存在。支持时可在播放请求中传 `episodeRequestEvent`；只需为当前集提供 HTTP(S) URL，其余集保留 ID/标题并将 URL 留空。播放器手动切集或自动连播时保持当前页面，通过网页桥接派发该名称的 `CustomEvent`，`detail` 含 `version`、`sessionId`、`requestId`、`progressKey`、目标 `seasonId`、`episodeId`、`episodeNumber`。网页验证标识并重新解析目标集地址及轨道，然后调用 `respondEpisode(JSON.stringify({sessionId, requestId, url, headers, mediaOptions, posterUrl, durationMs}))`；失败时可回传 `error`。播放器只消费本次请求对应的应答，30 秒无应答会显示超时；宿主不负责取链或选轨。未启用时仍要求每集都有有效 URL，并按原路径直接切集；旧宿主无该能力时网页应继续使用原路径。
- 单集 `headers` 覆盖全局同名 `headers`；宿主会补网页 User-Agent 和可取得的 Cookie。默认 Referer 只从有效 HTTP(S) 页面地址推导，详见[0.9.6 行为说明](16-0.9.6接口增补.md)。
- `mediaOptions` 是通用媒体参数；`encryptionMethod` 描述加密方式，`decryptionKeyHex` 是原始密钥，`keyIdHex` 是 CENC KID，`ivHex` 是可选固定 IV。兼容字段 `defaultIvHex` 与 `ivHex` 同义，同时出现时以 `ivHex` 为准。它们会随顶层请求和每个选集传递到播放页，由具备对应能力的播放器消费；不支持密钥注入的播放器不得把它们静默忽略。
- 未启用 `episodeRequestEvent` 时，选择新集会复用当前界面设置并重新建立系统播放器实例；播完自动进入下一集。
- 修改片首片尾后，宿主向网页派发 `skipChangeEvent` 指定的 `CustomEvent`。`detail` 包含
  `seasonId`、`episodeId`、`introMs`、`outroMs`、`introMode`、`outroMode`。
- 播放器不保存片首片尾；网页收到事件后自行保存，并在下次 `play` 时重新提供。
- 鸿蒙网页可选传 `progressEvent` 和 `progressKey`。切集、自动连播和退出播放器后，宿主在返回网页时派发指定的 `CustomEvent`；`detail` 包含 `sessionId`、原样返回的 `progressKey`、`seasonId`、`episodeId`、`episodeNumber`、`positionMs`、`durationMs`、`completed`。网页自行验证记录标识并持久化；宿主不会为网页保存最近记录。未传 `progressEvent` 的旧页面不受影响。一次播放器会话只回传每类事件的最新状态，不保证逐秒历史。
- 使用 `episodeRequestEvent` 时，播放器先切换当前集的界面和加载状态，再异步请求该集地址；网页可在收到目标集请求时立即记录该集，不必等待取链或媒体实际起播。宿主在返回导航前同步排队当前集进度，覆盖切集前的旧集快照。每部剧是否只保留一条记录由网页自行决定。
- 鸿蒙网页可选传 `refreshEvent`。播放器的“刷新播放地址”会返回网页并派发该名称的 `CustomEvent`；`detail` 包含 `version`、`sessionId`、`progressKey`、`seasonId`、`episodeId`、`episodeNumber`。网页负责验证作品和集数、丢弃该集旧地址、重新解析并再次调用 `play`；宿主不会重写 URL，也不会自动判断新地址是否可播放。未传时旧页面不显示刷新入口，不改变原有重试行为。
- 协议不包含雪碧图预览字段，也不会自动推断字幕、弹幕、账号或真实季集关系。

## 可选预取与断点续播（鸿蒙）

- `prefetchNextSeconds`：正整数，表示距离有效播放终点多少秒时预取下一集；不传或无效时关闭。需要同时提供 `episodeRequestEvent`。有片尾设置时，有效终点为 `durationMs - outroMs`（提示和跳过模式均适用）；否则为视频结束。例如片尾 60 秒、预取 30 秒，在距离视频结束 90 秒时触发。时长未知或没有下一集时不预取。
- 预取沿用按集解析事件，并增加 `purpose: 'prefetch'`；真正切集为 `purpose: 'switch'`，旧应用未提供 `purpose` 时按真正切集处理。网页只负责返回解析结果，预取不能更新播放记录或打开播放器。应用缓存同会话内目标季/集的完整地址、请求头、媒体参数；切集命中直接使用，在途请求复用，失败回退到正常解析。不设置固定两分钟有效期，不预取整季视频。
- 预取失败不会打断当前播放；跳选其他集不需要等待无关预取。手动刷新仍重新解析，退出清理本次会话预取。通用宿主不包含来源专属接口或选轨规则。
- `progressIntervalSeconds`：正整数，选择播放期间实时回传的间隔，建议 `10`。必须同时提供 `progressEvent`；未提供时保持原有返回网页时补送的行为。起播、切集、暂停和退出也回传。网页应容忍事件合并或延迟，不能把它作为精准计时器。
- 进度事件额外提供 `updatedAt`（毫秒时间戳）和 `sequence`（会话内递增序号），配合 `sessionId` 丢弃重复或乱序事件。退出仍保留最新事件以便返回网页补送。每部剧只保留一条记录，由网页按 `progressKey` 更新集数、`positionMs`、`durationMs` 和 `completed`，不要把预取请求作为观看行为。
- `startPositionMs`：非负毫秒数，仅用于本次初始选中的集；网页再次调用 `play` 时传入该集保存的位置，媒体准备好后恢复播放。真正切换其他集从零开始，不复用上一集位置。已看完的集是否重新从头播放由网页决定；不能仅凭旧记录的进度百分比推断精确位置。

### 预取与切集诊断

预取仅包含播放地址、请求头及媒体参数，不提前下载或解密下一集视频。命中预取不等于立即出画面：加密 MP4 仍在切集后下载、解密和写入临时文件，再交给系统播放器。

- `[WebVideoPrefetch]`：`trigger` 为到达预取节点，`request-start/ready/failed` 为网页解析请求及结果；切集的 `hit` 表示直接使用已完成缓存，`join` 表示等待同一在途预取。若预取失败，后续 `purpose=switch` 的请求为正常回退。
- `[WebVideoTiming]`：`episode-resolved` 为取链耗时；`old-player-released` 为释放旧播放器耗时；`media-downloaded/decrypted/written` 分别为下载、解密和写盘耗时；`player-prepared/playing` 为媒体交给 AVPlayer 后到准备完成/首次播放状态的耗时。`player-playing` 不是首帧已经显示的证明。
- 同一目标集仍在切换期间重复选择会记录 `duplicate-selection-ignored`，保留原切集及预取结果；不同目标仍能切换，失败后同集仍能重试。

这些新增诊断只记录本地请求序号、切集 revision、集数/索引、字节数和耗时，不输出播放 URL、请求头或密钥。各阶段可能并行，不应直接将全部耗时相加；其中 `media-written` 的 `totalMs` 是整个加密媒体准备过程的时间。

## 0.7.9 内嵌播放与弹幕

独立 HTML 网页可在探测 `capabilities()` 后调用 `playInline(requestJson, rectJson)`；`rectJson` 为 JSON 字符串，包含网页视口坐标 `{ x, y, width, height }`。页面布局或滚动时调用 `updateInlineRect(rectJson)`，遮挡播放器时调用 `setInlineOccluded(true)`，离开播放区域时调用 `closeInline()`。播放器可通过请求中的 `inlineProgressEvent`、`inlineEndedEvent`、`inlineBackEvent`、`inlineRefreshEvent` 和 `inlineReturnEvent` 向网页派发事件。调用方应在原页面保留稳定的选集与进度状态，并在真机上验证返回和全屏转换。

网页可为播放请求提供 `autoPlayNext`（默认启用）、`danmaku` 和 `danmakuComposer`；每集可带正整数 `danmakuEpisodeId`。`danmaku` 结构为 `{ provider?, externalSubjectType?, externalSubjectId?, searchTitle?, sourceUrl? }`。自有弹幕发送界面使用 `danmakuComposer: { enabled: true, submitEvent, placeholder? }`；播放器把本次弹幕的 `requestId`、`sessionId`、集标识、`positionMs` 和 `text` 发给网页，网页处理后调用 `respondDanmaku(JSON.stringify({ requestId, sessionId, success, errorMessage? }))`。不应在网页未经用户操作时自动发送。

`pendingProgress()` 与 `acknowledgeProgress(payloadJson)` 用于接收并确认网页重开后的待交付播放进度。网页应以会话 ID 和序号去重。这些方法仅属于独立 HTML 的视频桥接。`fishreader-html` 插件包当前提供 `play(string)`、`respondEpisode(string)`、`respondQuality(string)`，不提供本段的内嵌播放与待交付进度方法。字段和可选方法总表见[0.7.9 接口增补](12-0.7.9接口增补.md)及[0.9.5 接口增补](15-0.9.5接口增补.md)。

## 0.9.1 本地中继

当 `JSON.parse(fishreaderwebviewvideo.capabilities()).generic.localRelay === true` 时，网页播放请求可传 `localRelay: true`。季集条目和 `respondEpisode` 返回值也可传 `localRelay`，按集覆盖请求默认值。宿主把媒体交给应用内的回环 Range/HLS 中继；网页仍须提供真实可访问的 URL 和必要的请求头。本字段仅适用于独立网页视频桥接，不属于内容插件 `content()` 的返回字段。中继播放、投屏和 HLS 行为应在目标设备验证，详见[0.9.1 接口增补](14-0.9.1接口增补.md)。

## 0.9.5 画质、字幕与直播

独立 HTML 可检测 `capabilities().generic.qualitySwitch` 和 `respondQuality`，通过 `qualityRequestEvent` 接收含 `qualityId`、`positionMs`、`requestId`、`sessionId` 的画质请求，再返回当前画质的媒体 URL。播放请求及切集应答可提供 `qualityOptions`、外部字幕和初始轨道索引；直播列表使用 `liveChannelMode`、`liveLines`、`livePrograms`，选择线路时按集请求额外传 `lineIndex`。字段上限、返回内容和两类 HTML 页面的方法范围见[0.9.5 接口增补](15-0.9.5接口增补.md)。

## 0.9.6 网页脚本地址与默认请求头

独立 HTML 的私有脚本可返回当前本机 HTTP 媒体地址，由同一网页的播放器使用；地址只在脚本进程存活期间有效。`localRelay` 是既有字段。默认 Referer 仅从真实 HTTP(S) 页面地址推导，导入的本地 HTML 地址不能直接填入媒体 `headers.Referer`。见[0.9.6 接口增补](16-0.9.6接口增补.md)。
