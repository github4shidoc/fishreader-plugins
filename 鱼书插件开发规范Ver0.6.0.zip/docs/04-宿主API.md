# 宿主 API

本章按鱼书鸿蒙版 0.6.0 主规范核对。可选接口应做能力检测；完整接口表见 [`plugins/development-guide.md`](plugins/development-guide.md) 第 5 节。

内容插件、字典和 TTS 主模块中，宿主提供只读全局对象 `reader`。管理页面使用另一套 `FishReader` 桥接，见下一篇。

所有参数和返回值都必须是 JSON 可序列化普通值。建议始终 `await` 宿主调用，并捕获错误后补充业务上下文。

## 1. 网络 `reader.http`

### `fetch(request)`

```js
const response = await reader.http.fetch({
  url: 'https://api.example.com/items',
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ page: 1 }),
  charset: 'utf-8',
  responseType: 'text',
  followRedirects: true,
  timeoutMs: 30000
});
```

请求字段：

| 字段 | 说明 |
| --- | --- |
| `url` | 必需，已授权的 HTTP(S) 绝对地址 |
| `method` | `GET`、`POST`、`PUT`、`PATCH`、`DELETE`、`HEAD` |
| `headers` | 字符串映射，最多 64 项，不得含 CR/LF |
| `body` | 文本请求体 |
| `bodyBase64` | 二进制请求体；与 `body` 二选一 |
| `charset` | 文本响应解码字符集，例如 `utf-8`、`gbk` |
| `responseType` | `text` 或 `bytes`；后者在结果 `data` 返回字节数组 |
| `followRedirects` | 默认跟随；关闭时保留首个响应及 `Location` |
| `timeoutMs` | 1,000 到 120,000；默认 30,000 |
| `dnsIp` | 高级项；仅在平台支持且权限校验通过时使用，不要作为通用 DNS 绕过手段 |

请求体最大 1 MiB；响应最大 16 MiB；自动重定向最多 5 次。每个重定向域名都要被授权。

返回：

```js
{
  status: 200,
  url: 'https://api.example.com/items',
  headers: { 'content-type': 'application/json' },
  body: '{"items":[]}',
  data: undefined
}
```

HTTP 4xx/5xx 是正常响应，不一定抛异常；插件必须检查 `status`。连接、超时、权限和超限会抛错。

### `fetchBatch({ requests, concurrency })`

```js
const items = await reader.http.fetchBatch({
  requests: urls.map(url => ({ url, method: 'GET' })),
  concurrency: 8
});
```

公开插件模块单次最多提交 32 个请求，并发值最多 32；结果按输入顺序返回：

```js
{
  index: 0,
  ok: true,
  result: { status: 200, url: '...', headers: {}, body: '...' },
  noData: false,
  error: '',
  timedOut: false
}
```

某个请求完成后宿主会及时补入下一项，不按固定小批次等待。需要处理数百或数千个目标时，应使用内容插件的拆分批量入口交给宿主调度，而不是一次调用 `reader.http.fetchBatch`。

## 2. HTML `reader.html`

```js
const values = await reader.html.parse({
  html,
  selector: '.item > a',
  value: 'attribute',
  attribute: 'href',
  all: true,
  limit: 500
});
```

`value` 可选：

- `text`：元素文本。
- `textNodes`：直接文本节点。
- `ownText`：元素自身文本。
- `html`、`all`、`innerHTML`、`outerHTML`：HTML 表示。
- `attribute`：指定属性，必须同时提供 `attribute`。

`all: false` 返回单个字符串或 `null`；`all: true` 返回字符串数组。单份 HTML 最大 16 MiB，选择器最长 32,768 字符，属性名最长 256，结果最多 50,000 项。

批量解析：

```js
const results = await reader.html.parseBatch({
  requests: [
    { html, selector: '.title', value: 'text', all: true, limit: 100 },
    { html, selector: '.item a', value: 'attribute', attribute: 'href', all: true, limit: 100 }
  ]
});
```

最多 5,000 个请求，共享 16 MiB HTML 输入预算。相同 HTML 的多个选择器适合放在同一批中。

## 3. Cookie `reader.cookie`

需要 `cookieScope: true`：

```js
const cookie = await reader.cookie.get(url);
const cookies = await reader.cookie.getBatch([url1, url2]);
await reader.cookie.set(url, 'session=abc; Path=/; Secure');
await reader.cookie.clear(url); // 只清指定作用域
await reader.cookie.clear();    // 清本插件全部 Cookie
```

Cookie 仍受 `networkDomains` 限制。宿主会在允许时把 Cookie 自动附加到请求并接收 `Set-Cookie`；如果插件显式设置 `Cookie` 请求头，以显式值为准。

## 4. 私有键值存储 `reader.storage`

需要 `pluginStorage: true`：

```js
await reader.storage.set('settings', { endpoint: 'https://api.example.com' });
const settings = await reader.storage.get('settings');
const values = await reader.storage.getBatch(['settings', 'dataVersion']);
await reader.storage.removeBatch(['oldKey']);
await reader.storage.removeByPrefix('cache:v1:');
```

`getBatch` 返回以原始键名为属性的对象；`removeBatch` 返回布尔值；`removeByPrefix` 返回删除数量，前缀长度至少为 8。每个值最大 1 MiB。只保存 JSON 值，不保存密钥明文、整本目录或大量正文。高频/大量数据使用数据库或专用目录缓存。

升级、备份恢复或跨平台迁移后，已有键可能是对象、数组、字符串、数字、布尔值或 `null`。从 0.5.0 起宿主兼容读取旧的原生标量值；插件也必须在使用前判断类型，不能无条件对返回值调用 `JSON.parse`：

```js
function objectValue(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value !== 'string') return {};
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

const settings = objectValue(await reader.storage.get('settings'));
```

如果某个键按设计就是布尔值或数字，应直接按 `typeof` 验证并提供默认值；不要先字符串化再解析。写入新值时优先直接传 JSON 值，让宿主负责持久化编码。

`reader.source.getVariable()` / `setVariable(value)` 提供一个兼容型实例变量槽，最大 64 KiB。新插件优先使用命名存储键。

## 5. 私有数据库 `reader.database`

需要 `pluginDatabase: true`：

```js
await reader.database.execute({
  sql: 'CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)',
  bindArgs: []
});

await reader.database.batch({
  statements: [
    { sql: 'REPLACE INTO settings(key, value) VALUES(?, ?)', bindArgs: ['display_mode', 'dark'] },
    { sql: 'DELETE FROM settings WHERE key = ?', bindArgs: ['obsolete'] }
  ]
});

const result = await reader.database.query({
  sql: 'SELECT key, value FROM settings ORDER BY key LIMIT ?',
  bindArgs: [100],
  maximumRows: 100
});
```

查询结果为 `{ columns, rows, truncated }`。限制：SQL 最大 16 KiB；绑定值最多 2,048；批量语句最多 1,000；普通查询最多 500 行；每个插件最多 32 张表。

`maximumRows` 省略时为 200；显式传入时必须是 `1..500` 的整数。超过 500 条不能把 `maximumRows` 写成更大的数，而应稳定排序后分页：

```js
async function readAllRows() {
  const rows = [];
  const pageSize = 500;
  for (let offset = 0; ; offset += pageSize) {
    const page = await reader.database.query({
      sql: 'SELECT key, value FROM settings ORDER BY key LIMIT ? OFFSET ?',
      bindArgs: [pageSize, offset],
      maximumRows: pageSize
    });
    rows.push(...page.rows);
    if (page.rows.length < pageSize) return rows;
  }
}
```

分页必须带稳定且唯一的排序键，否则并发写入时可能出现重复或遗漏。管理页面中的 `FishReader.database.query` 使用相同限制。

只允许受限的 `CREATE TABLE/INDEX`、`DROP TABLE/INDEX`、`ALTER TABLE`、`INSERT`、`REPLACE`、`UPDATE`、`DELETE` 和 `SELECT`。多语句、注释、PRAGMA、ATTACH、触发器、视图等会被拒绝。

`queryJson({ sql, bindArgs })` 适合让 SQLite 直接生成一个 JSON 值，避免把大结果先展开为大量 JS 对象；返回 JSON 值最大约 20 MiB。使用前应做能力检测，跨平台插件应有普通 `query` 的可控替代路径。

## 6. 私有文件 `reader.file`

需要 `pluginStorage: true`。路径只能是插件私有目录内的相对路径，绝对路径和 `..` 穿越会被拒绝。

```js
await reader.file.write({ path: 'cache/item.json', content: JSON.stringify(data), charset: 'utf-8' });
const text = await reader.file.read({ path: 'cache/item.json', charset: 'utf-8' });
const bytes = await reader.file.read({ path: 'cache/item.bin', charset: 'bytes' });
await reader.file.delete('cache/item.json');
const path = await reader.file.download({ url });
```

`write` 和 `download` 返回宿主生成或校验后的相对路径，不要假设传入路径会被原样保留。单次读写最大 16 MiB。`readTextFolder({ path, charset })` 会按文件名字典序拼接目录中文本，并在读取结束后删除该临时目录；不要把它用于需要长期保留的文件夹。

## 7. 压缩 `reader.archive`

需要 `pluginStorage: true`：

```js
const entryBytes = await reader.archive.zipEntry({ path: 'data/book.zip', entry: 'toc.json' });
const folder = await reader.archive.extract({ path: 'data/book.zip' });
const gz = await reader.archive.gzipEncode({ data: bytes });
const raw = await reader.archive.gzipDecode({ data: gz });
const inflated = await reader.archive.inflateDecode({ data: deflated });
```

`zipEntry` 可从私有 `path`、已授权 `url` 或 `data` 读取一个 ZIP 条目；`extract` 只接受插件私有目录中的 `path`；三种 gzip/deflate 方法都使用字节数组。压缩包路径和条目名会做穿越校验；完整解压结果位于插件临时私有目录。解压后及时读取并清理。单次结果最大 16 MiB。

## 8. 编码转换 `reader.text`

需要 `pluginStorage: true`：

```js
const bytes = await reader.text.encode({ text: '中文', charset: 'gbk' });
const text = await reader.text.decode({ data: bytes, charset: 'gbk' });
const simplified = await reader.text.convert({ text: traditional, direction: 't2s' });
const traditional = await reader.text.convert({ text: simplified, direction: 's2t' });
```

不要用不受控的 `String.fromCharCode(...hugeArray)` 处理大数据。单次输入/输出受 16 MiB 限制。

## 9. 加密 `reader.crypto`

需要 `standardCrypto: true`。这组 API 用于标准互操作，不应用来隐藏恶意行为或存放长期密钥。

```js
const digest = await reader.crypto.digest({ algorithm: 'SHA-256', text: 'hello' });
const hmac = await reader.crypto.hmac({ algorithm: 'SHA-256', key: 'secret', text: 'hello' });
```

结果包含规范化算法名、`hex` 和 `base64`。二进制输入使用 `data`，HMAC 二进制密钥使用 `keyData`。

对称加密：

```js
const encrypted = await reader.crypto.cipher({
  transformation: 'AES/CBC/PKCS5Padding',
  operation: 'encrypt',
  key: keyBytes,
  iv: ivBytes,
  data: plainBytes
});
```

支持宿主公开的 AES、DES、DESede 组合及 ECB/CBC、NoPadding/PKCS5Padding/PKCS7Padding；密钥和 IV 长度必须与算法匹配。返回 `{ transformation, data }`。

非对称加密和签名使用 RSA PEM 或 Base64 密钥：

```js
await reader.crypto.asymmetric({
  transformation: 'RSA/ECB/PKCS1Padding',
  operation: 'encrypt',
  publicKey,
  usePublicKey: true,
  data
});

const signed = await reader.crypto.sign({ algorithm: 'SHA256withRSA', privateKey, data });
const ok = await reader.crypto.verify({ algorithm: 'SHA256withRSA', publicKey, data, signature: signed.data });
```

密钥最大 64 KiB，数据和结果受 16 MiB 限制。不同平台支持的算法别名可能不同，发布前必须在目标平台实测。

## 10. 受控 WebView `reader.webview`

需要 `webViewAutomation: true`：

```js
const result = await reader.webview.execute({
  url: 'https://example.com/page',
  headers: {},
  javaScript: 'document.documentElement.outerHTML',
  delayMs: 500
});
const html = result.body; // { url, body, status: 200, headers: {} }
```

`url` 必需，即使传入 `html` 也要提供已授权的 HTTP(S) 基准地址。`html` 非空时加载该文档；否则请求 `url`。脚本执行结果在 `body`，不是顶层 `value`；这里的 `status: 200` 是执行包装值，不证明站点登录或业务请求成功。

- `sourceRegex` 为空：页面加载后等待 `delayMs`，执行 `javaScript`。返回纯字符串；需要对象时在页面脚本里 `JSON.stringify`，插件再解析 `body`。
- `sourceRegex` 非空：匹配页面请求的 URL，结果 `body` 是命中的 URL；此模式不执行上面的页面结束脚本，不能同时当作两阶段执行。
- `delayMs` 为 `0..30000` 的整数；脚本最多 256 KiB，表达式最多 4,096 字符，HTML 最多 16 MiB。
- 页面脚本异步启动网络操作后立刻返回，会早于数据就绪；不要把返回 Promise 当成宿主一定会等待。宿主执行和入口总期限仍有效，不能无限轮询。
- 自动化页面不是常驻登录页面；生命周期和 Cookie 隔离由宿主控制，登录交互应使用登录浏览器。

仅在普通 HTTP + HTML 解析无法完成合法业务时使用。它不是任意浏览器控制接口，URL、Cookie、延迟、脚本和结果都受宿主限制。不能用它规避验证码、登录、反自动化或访问控制。

## 11. 增量结果 `reader.result`

```js
await reader.result.emit({ bookKey: '...', title: '...' });
```

只在宿主为当前执行连接了结果观察器时有效，并返回是否接受。每次传入**单个**符合摘要契约的对象，不是数组。鸿蒙当前可同步返回、Android 可异步返回，因此跨平台代码必须使用 `await`。它适合搜索过程的增量更新；最终入口返回值仍需包含完整结果。控制投递频率和单次大小，不要每解析一个字符就投递。

## 12. 大型目录缓存 `reader.catalogCache`

这属于 `catalogStorage: "host-file-v1"` 的高级协议，普通插件不要使用。基本事务为：

```text
begin → writeChunk（多次）→ commit
                         ↘ abort（失败）
```

还提供 `readManifest`、`readChunk` 和 `deleteBook`。所有 `bookId`、事务 ID 和延迟激活标志必须来自宿主输入，不得自行替换。目录写入失败必须 `abort`，不能留下半成品；提交候选也不表示书架数据库事务已经成功。

参数、返回值、块大小和代次约束详见 `11-目录上下文与批量任务.md`，编辑器类型见 `FishReaderCatalogBegin`、`FishReaderCatalogManifest`。

## 13. 插件环境信息 `reader.environment.info`（可选）

插件声明 `pluginStorage: true` 且宿主提供该方法时，可调用 `await reader.environment.info()`，获取 `version`、`buildNumber`、`device`、`id`、`userAgent` 与 `qysgBrowserVersion`。`id` 是当前插件范围内持久化的随机标识，并非硬件 ID 或跨设备账号。旧宿主没有此方法时应回退：

```js
const info = reader.environment && typeof reader.environment.info === 'function'
  ? await reader.environment.info()
  : null;
```

## 14. 隔离运行环境

主模块不是网页，也不是 Node.js。不要假设存在 `window`、`document`、`fetch`、`XMLHttpRequest`、`TextEncoder`、`TextDecoder`、`Buffer` 或任意 npm 模块。Node 测试通过不等于目标环境一定有相同全局对象。

```js
const bytes = await reader.text.encode({ text: '示例', charset: 'UTF-8' });
const text = await reader.text.decode({ data: bytes, charset: 'UTF-8' });
```

编码、网络、HTML 解析统一调用已声明权限的宿主 API。对管理页与主模块分别测试，不能把 WebView 的浏览器 API 直接搬进主模块。
