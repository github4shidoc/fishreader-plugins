# FishReader plugin package v1 (HarmonyOS 0.6.0)

Documentation release: **0.6.0** (HarmonyOS, 2026-09-27). The package protocol
remains `schemaVersion: 1` and the recommended SDK remains `1.0`. This is a
package-format reference; the [main HarmonyOS guide](development-guide.md) and
this package's schemas define the current public interface. The Android and
Docker notes below are historical compatibility background, not a new 0.6.0
release claim for those platforms.

FishReader does not bundle or distribute book sources. A user may import a UTF-8
JSON file named `*.fishplugin.json` on Android, HarmonyOS, or Docker Web.

```json
{
  "schemaVersion": 1,
  "manifest": {
    "schemaVersion": 1,
    "pluginId": "plugin:example:reader",
    "name": "Example user plugin",
    "version": "1.0.0",
    "sdkVersion": "1.0",
    "entryModule": "main.js",
    "loginUrl": "https://books.example.invalid/login",
    "entrypoints": ["search", "explore", "detail", "catalog", "content"],
    "exploreCategories": [
      { "key": "hot", "title": "热门" },
      { "key": "finished", "title": "完结" }
    ],
    "permissions": {
      "networkDomains": ["books.example.invalid"],
      "redirectDomains": ["cdn.example.invalid"],
      "cookieScope": true,
      "pluginStorage": true,
      "htmlParse": true,
      "standardCrypto": false,
      "webViewAutomation": false,
      "loginBrowser": true
    }
  },
  "source": "module.exports.search = async input => [];"
}
```

The package is limited to 5 MiB and the UTF-8 entry module to 4 MiB. Importers
validate identifiers, versions, entrypoints, module path, permissions, domain
grants, and an optional `manifest.contentHash`. They calculate and persist the
canonical `sha256:<hex>` hash. A newly installed interactive plugin starts disabled;
an in-place upgrade keeps the previous enabled state.

## In-place upgrades

`manifest.pluginId` is the stable plugin identity. Importing a package whose ID is
already installed, or choosing **Upgrade** on that plugin's management card, replaces
only its validated manifest and module source. The host keeps the plugin's imported
sources, private table, key/value storage, Cookie jar, source variable, enabled state,
installation time, and existing domain grants. Selecting another plugin ID from the
dedicated upgrade action is rejected before any write.

Before replacement, the app displays the old and new versions and any newly requested
domains or capabilities. Cancellation leaves both code and data untouched. Plugin
deletion remains intentionally destructive and removes the plugin-private data; users
must not delete a plugin merely to update it. Persistent data-schema migration between
plugin versions remains the plugin author's responsibility.

## Large catalog storage

FishReader supports the optional `host-file-v1` catalog storage contract for
host-supported compatibility plugins that need the complete original catalog data.
It is not required for ordinary `fishreader-js` source plugins. A compatible manifest
declares both:

```json
{
  "sourceFormat": "legado-compat",
  "catalogStorage": "host-file-v1",
  "permissions": {
    "pluginStorage": true
  }
}
```

For these plugins, `catalog` may receive `cacheBookId`, `cacheTransactionId`, and
`cacheDeferActivation`; `content` may receive the same stable `cacheBookId`.
`cacheBookId` is the FishReader bookshelf identity and must be passed unchanged to
`reader.catalogCache`. A plugin must not derive the file identity from plugin ID,
source ID, `sourceKey`, `bookKey`, or a mutable URL.

The file transaction consists of `catalogCache.begin`, ordered `writeChunk` calls,
and `catalogCache.commit`; failures call `catalogCache.abort`. `readManifest` and
`readChunk` require the stable book ID and expected generation. Each JSON chunk is
limited to 1 MiB, one book to 20,000 chunks and 128 MiB, and a catalog to 20,000
chapters. The active file is owned by the writing plugin and cannot be read by a
different plugin.

When `cacheDeferActivation` is true, commit creates a candidate. FishReader first
commits the bookshelf/database change and only then atomically activates that
candidate. A failed database operation keeps the previous active file. Source
switching therefore does not rename the per-book file. The host removes a book's
file when the book is deleted and may remove old Preferences catalog generations
only after confirming that no persisted chapter still references them.

A `legado-compat` plugin without the declaration is treated as an older plugin and
FishReader asks the user to update it before a catalog refresh or source switch.
Declaring `host-file-v1` without producing the matching candidate also fails before
the database source is changed. Standard source plugins remain valid without this
declaration or API.

## Runtime engines

The plugin contract is shared, but the JavaScript engine is platform-specific:

- HarmonyOS API 23+ runs the module in an isolated native child process through
  the system `libjsvm.so` / `OH_JSVM` API. It does not embed QuickJS;
- Android prefers AndroidX JavaScriptSandbox and uses QuickJS only as the
  Android 9 compatibility fallback inside an `android:isolatedProcess` service;
- Docker/Web runs QuickJS compiled to WebAssembly inside a disposable Node child
  process. Node globals are not exposed to plugin code.

All engines reach network, storage, Cookie, parsing, crypto, and WebView features
only through the same manifest-checked FishReader Host API. Engine-specific APIs
are not part of the plugin SDK.

The runtime stores one CommonJS-compatible entry module. The public package may declare
one or more `pluginKinds`: `source`, `dictionary`, and `tts`. Theme plugins are not yet
part of the public 0.6.0 guide. Omitting the field
means `["source"]` for compatibility. Required entrypoints are type-specific:

- `source` requires `search`, `detail`, `catalog`, and `content`;
- `dictionary` requires `dictionary`;
- `tts` requires both `ttsVoices` and `ttsSynthesize`;

`explore` and `loginCheck` remain optional for a `source` plugin. A plugin that
manages many independent search targets may additionally expose `searchTargets`.
For efficient concurrent search, the host prefers `searchPrepareBatch` plus
`searchParseBatch`, falls back to `searchBatch`, and finally calls `search` once
per target. The split form keeps HTTP slots independent from JavaScript parsing:
failed or empty HTTP work releases its slot immediately, while completed responses
enter a separate parse queue.

Search execution may outlive the search page. Plugin code must
not retain page, DOM, route, or native mutable state. Cancellation may terminate the
worker and discard late results. Stable `bookKey` values and bounded incremental
`reader.result.emit` calls are therefore required for correct background merging.
A JavaScript source plugin may additionally declare the `ui` entrypoint and a
`managementModule` ending in `.html` or `.htm`. Its package then contains exactly
one matching `modules` entry:

```json
{
  "manifest": {
    "entryModule": "main.js",
    "managementModule": "manage.html",
    "entrypoints": ["search", "detail", "catalog", "content", "ui"]
  },
  "source": "module.exports.search = async input => [];",
  "modules": {
    "manage.html": "<!doctype html><title>Plugin settings</title>"
  }
}
```

The management page uses the same sandboxed `FishReader` capability bridge and
private storage/Cookie jar as the source module. It can therefore offer its own
file import, login, and settings UI without teaching the FishReader application
the plugin's configuration format. It may also call
`FishReader.plugin.requestNetworkDomains(domains)` after parsing a user-supplied
configuration. FishReader then shows an app-owned confirmation and persists only
the domains approved for that plugin. General module resolution, signatures, and
binary values through the JavaScript result channel remain unsupported. TTS
plugins instead return a bounded network request descriptor from `ttsSynthesize`;
the host downloads and validates the audio through the same domain broker.

On HarmonyOS 0.6.0, a management-page plugin can optionally declare
`urlSchemes` and `webPageActions` to associate supported webpages with its UI.
`webPageActions` requires `managementModule` and both `manage` and `ui` entrypoints.
Feature-detect `FishReader.ui.takeLaunchUrl()` and
`FishReader.ui.takeLaunchAction()` before using them. Association does not
grant network access; ordinary domain permissions still apply. See
[management pages and login](../05-管理页面与登录.md) for the declaration shape.

## Dictionary and TTS plugins

A dictionary plugin receives `{ "word": "...", "context": "..." }` and returns
an object with an optional `title` plus at least one of `text` or `html`. It cannot
return a remote page for the host to open. The host sanitizes HTML before display
and removes active content, forms, external navigation, and remote resources.

A TTS plugin exposes `ttsVoices({})` and `ttsSynthesize({ text, voiceKey, speed })`.
The first returns at most 256 stable voice records. The second returns `{ url,
method, headers?, body?, contentType?, cacheKey? }`. It never returns audio bytes.
The host owns segmentation, next-segment prefetch, retry, request execution, the
20 MiB audio limit, playback, interruption, focus, bounded caching, and temporary-file cleanup. Supported methods
are `GET`, `POST`, and `PUT`, and every redirect is checked against the plugin's
approved domains.

TTS is text-to-speech for the text reader. It is distinct from source-provided
audiobook chapters. An audiobook `content` result uses `contentType: "audio"`, an
empty `content`, one `mediaUrl` or ordered `mediaUrls`, optional `mediaHeaders`, and
optional `toneOptions`. A non-empty `toneOptions` array lets the host show a bounded
voice/tone picker; the selected option's `value` is passed back to `content` as
`customVariable`. If there is no real choice, omit the field or return an empty array.

## Sandboxed HTML UI plugins

Package v1 also accepts `sourceFormat: "fishreader-html"`. In that form,
`entryModule` must end in `.html` or `.htm`, `entrypoints` must be `["ui"]`, and
the package `source` is the complete UTF-8 HTML document. It is a user-facing
source UI, not a JavaScript entrypoint used by the normalized global search.

The Docker product renders it in an iframe with `sandbox="allow-scripts"`, an
opaque origin, no forms/popups/top navigation, no direct network connection,
and a response CSP whose `default-src` and `connect-src` are `none`. A generated
`window.FishReader` bridge sends capability calls to the parent using a
per-opening random channel token. The parent accepts messages only from the
active iframe and the server repeats plugin identity, enabled-state, operation,
permission, domain, redirect, size, timeout, and Cookie checks.

HTML plugins therefore use `FishReader.http.fetch`, `FishReader.storage`,
`FishReader.cookie`, `FishReader.crypto.digest`, and `FishReader.html.parse`;
they cannot call account/library REST endpoints directly. A login form inside
the HTML plugin uses the brokered HTTP API, so response `Set-Cookie` values enter
the plugin-private Cookie jar automatically. A third-party interactive OAuth or
CAPTCHA page still uses the explicit native login browser, or Docker's external
browser/manual-import compatibility path.

When `explore` is declared, a plugin may also publish one to 64
`exploreCategories`. Each item has a plugin-private `key` (1–256 characters) and
a user-facing `title` (1–128 characters); keys must be unique. All products render
these declarations as discovery actions and call only the owning plugin with
`{ "category": "<user-selected-key>", "page": <positive-integer> }` and expect
the same normalized `BookSummary[]` shape as `search`. An empty category means
the plugin's default discovery feed. The manual category-key field remains as a
compatibility fallback for plugins that do not declare categories.

On HarmonyOS 0.6.0, optional discover filters pass initial state through
`exploreStateJson` and changed values through `filtersJson`. Supported filter
types are `select`, `toggle`, and `text`; older callers can omit these fields.
See [content plugins](../03-内容插件.md) for the exact request and result shapes.

Plugins whose categories depend on account state, source variables, or a remote
menu may additionally declare `exploreMenu`. The host calls `exploreMenu({ page: 1 })`
when entering or refreshing discovery and accepts at most 128 `{ key, title }`
items. Selecting one calls `explore` with that dynamic key. Dynamic items replace
the manifest's static categories for that refresh; a failed dynamic request falls
back to the static declarations.

Plugins granted `pluginStorage` also receive a private source-variable slot through
`reader.source.getVariable()` and `reader.source.setVariable(value)`. Users can edit
the same value from the plugin manager on every product. It is bounded to 64 KiB,
is never bundled with the app, and is intentionally excluded from Docker account
sync because it may contain installation-specific configuration.

FishReader may expose batch helpers (`storage.getBatch`, `storage.removeBatch`,
`storage.removeByPrefix`, `cookie.getBatch`, `html.parseBatch`, and
`database.queryJson`) plus text encoding conversion. Some
platforms also expose extended crypto, private file, and archive operations. Authors
must feature-detect every extended method, retain a portable baseline fallback, and
state the platforms actually tested. Private file operations never grant access to
arbitrary user paths.

`reader.http.fetchBatch` accepts 1–2,048 queued requests and uses at most 32 active
HTTP slots. A completed slot is filled immediately instead of waiting for a fixed
wave, while the method itself resolves only after all requests finish. The combined
response-body budget is 16 MiB. `reader.html.parse` accepts at most 16 MiB of HTML,
a 32,768-character selector, and 50,000 results; `html.parseBatch` accepts up to
5,000 requests sharing the same 16 MiB input budget. These are compatibility ceilings,
not recommended working sizes, and the normal execution-result limit still applies.

`webViewAutomation` is a separate high-risk capability. On HarmonyOS API 23+ it
uses one hidden incognito ArkWeb executor, serializes tasks, clears transient
browser cookies before and after each task, seeds only the owning plugin's Jar,
and returns either evaluated JavaScript output or a resource URL matched by a
bounded regular expression. The broker revalidates the initial and final URL
against the plugin's domain grants. Docker rejects this operation until a
separately sandboxed browser worker is configured; ordinary server-side HTTP is
not presented as WebView execution.

## Cookie scope

`cookieScope` defaults to `false`. When granted, the host keeps one persistent
Cookie jar per installed plugin and automatically consumes `Set-Cookie` from
`reader.http.fetch` responses. A later request receives matching Cookies unless
the plugin supplied an explicit `Cookie` request header.

The same isolated JavaScript receives:

```js
const current = await reader.cookie.get('https://books.example.invalid/private');
await reader.cookie.set('https://books.example.invalid/private',
  'session=local-value; Path=/private; Secure');
await reader.cookie.clear('https://books.example.invalid/private');
await reader.cookie.clear(); // clear this plugin's complete jar
```

Android API 28's synchronous QuickJS compatibility worker exposes the same calls
synchronously; plugin code must already follow the platform's existing synchronous
entry-point restriction there.

Each Cookie line is limited to 4 KiB and each plugin to 128 active entries. The
host enforces `Domain`, `Path`, `Secure`, `Max-Age`, and `Expires`; a `Domain`
attribute cannot broaden the Cookie beyond the manifest's `networkDomains`
boundary. Cookie operations also re-check the URL against that permission.
Expired entries are discarded, plugin deletion removes the jar, and Cookie data
is excluded from backup, Docker account sync, exports, and normal diagnostic logs.
On HarmonyOS API 23+ and Android 9+, a plugin may additionally declare `loginUrl`
and set both `loginBrowser` and `cookieScope` to `true`. The plugin manager then
exposes an explicit, user-visible login page. It runs in an incognito ArkWeb or a
non-exported separate-process WebView, exposes no native JavaScript or file bridge,
blocks navigation/resources outside declared `networkDomains` / `redirectDomains`,
and imports only Cookie headers accepted by the same per-plugin/domain checks.
The transient browser store is cleared before and after every session. Reopening
the page seeds it from the private jar, preserving retained Path, Domain, Secure,
and HttpOnly attributes; persistent state remains only in that jar. The host saves
Cookies only from authorized origins actually visited during that login session.
Closing the page or returning to the plugin does not itself prove authentication;
plugins must use `loginCheck` or a real authenticated request to determine success.

Docker/Web cannot read another origin's HttpOnly Cookie. Its equivalent flow opens
the login site in a normal browser tab and asks the user to paste a Cookie request
header. The server repeats the account, plugin, permission, and manifest-domain
checks before importing it into that account's plugin-private jar.

Storage keys beginning with `__host.` are reserved for broker metadata and are
rejected by `reader.storage`; plugin code cannot read or overwrite the jar record.
