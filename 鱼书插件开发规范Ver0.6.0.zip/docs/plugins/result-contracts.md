# Plugin entrypoint result contracts

Documentation release: **0.5.0** (FishReader 0.5.0, 2026-09-17). The canonical package and
result schemas remain version 1.

All JavaScript plugins expose CommonJS functions. Inputs and outputs are JSON values;
the host rejects oversized worker requests/results before product code consumes
them.

- `search({ keyword, page })` returns at most 500 book summaries. `bookKey` and
  `title` are required and stable within the plugin.
- `exploreMenu({ page })` optionally returns at most 128 dynamic discovery items
  with unique `key`, user-facing `title`, and an optional `group` heading. Hosts
  load these items before requesting discovery content and render equal non-empty
  groups as a heading followed by their selectable child items.
- `explore({ category, page })` returns the same summary shape. A manifest may
  declare user-facing `exploreCategories`; a category action invokes only its
  owning enabled plugin, while the manual key fallback may invoke all enabled
  plugins that declare `explore`.
- Search, explore, and detail book records may return `types` (multiple book
  classifications), `wordCount`, and `publicationStatus` (for example `连载`
  or `完结`). `kind` remains a backward-compatible single classification
  string; new plugins should prefer `types`. They may also return `sourceName`,
  `lastUpdated`, and `mediaType` (`text`, `comic`, `audiobook`, or `video`).
- `detail({ bookKey, bookUrl, sourceKey?, forceRefresh?, title?, author?, coverUrl?, latestChapter? })` returns normalized book metadata and may add
  `tocUrl`, `canReName`, optional audiobook `chapterCount`, and up to 64 `downloadUrls`.
- `catalog({ bookKey, bookUrl, tocUrl, sourceKey?, forceRefresh? })` returns ordered chapter records with a
  stable `chapterKey`, title, zero-based ordinal, and optional URL/volume/lock
  flags. A chapter may override the summary classification with `mediaType`.
- `content({ bookKey, chapterKey, chapterUrl, customVariable?, mediaType? })` returns an object containing
  `content`, an optional `baseUrl`, and `contentType` (`text`, `audio`, `video`,
  or `structured`). Non-text results keep `content` empty and may provide a bounded
  `mediaUrl`, up to 256 `mediaUrls`, bounded `mediaHeaders`, a user-facing
  `message`, `title`, and `imageStyle`; hosts must not render raw API JSON as text.
  Audio results may also return up to 64 stable `{ value, label }` `toneOptions`.
  The selected `value` is supplied in the next `content.customVariable` call.

`forceRefresh: true` asks the plugin to bypass its own stale detail/catalog cache and
fetch current metadata. It does not relax validation or permit synthetic chapters.
All added input fields are optional; plugins must ignore unknown input fields.

For plugins with multiple independent targets, `searchPrepareBatch` maps
`{ keyword, page, sources, concurrency }` to prepared request records. The host
executes those HTTP requests without waiting for JavaScript parsing and later calls
`searchParseBatch({ keyword, page, items })`. Each parsed item is
`{ sourceKey, sourceName, books, errorMessage?, timedOut? }`. `searchBatch` accepts
the same initial input and returns the same parsed items when request preparation
cannot be separated. The split pair is preferred.

Search may continue after the search page is closed. Plugins must not depend on UI
lifetime or shared native instances, and cancellation may cause the host to discard
in-flight and late results. `reader.result.emit` remains incremental; the final return
value must still contain the complete result list.

The canonical JSON Schemas are under `schemas/plugin/`. Plugins cannot return UI
code or native objects. HTML parsing and HTTP remain explicit Host API calls under
manifest permissions. The synthetic package in `tests/fixtures/plugins/` contains
no real source and is the cross-platform acceptance fixture.

## Dictionary

`dictionary({ word, context? })` returns an object with an optional `title` and at
least one of `text` or `html`. Remote URLs are not a result contract. The host
sanitizes HTML, combines results from enabled dictionary plugins, and shows the
combined document under a restrictive content security policy.

Canonical schema: `schemas/plugin/dictionary-result.schema.json`.

## TTS

`ttsVoices({})` returns at most 256 voices. Every record has stable `voiceKey` and
user-facing `name`; `locale`, `gender`, and `description` are optional. A plugin
that exposes several voice packages may also return stable `packageId` and
user-facing `packageName`. The reader groups those records into the shared voice
selector; plugins that omit both fields remain in one plugin-named group.

`ttsSynthesize({ text, voiceKey, speed })` returns a network request descriptor,
not audio bytes. `url` and `method` are required; `headers`, `body`, `contentType`,
and `cacheKey` are optional. The host validates the URL and redirects against the
approved domain set, downloads at most 20 MiB, and owns playback and cleanup.

TTS request descriptors are not audiobook chapter results. Source-provided audio uses
the `contentType: "audio"` contract and is played by the audiobook player; text TTS
uses `ttsVoices` / `ttsSynthesize` and is played by the text reader.

Canonical schemas: `schemas/plugin/tts-voices-result.schema.json` and
`schemas/plugin/tts-synthesis-result.schema.json`.

## Image transforms and controlled actions

`image({ url, sourceKey?, bookKey?, ... })` returns `{ dataBase64, contentType? }`.
`dataBase64` contains raw Base64 without a data-URL prefix and must decode to a
non-empty payload. `contentType` must describe the actual media type. Canonical
schema: `schemas/plugin/image-result.schema.json`.

`payAction(input)` and `callback(input)` return controlled action descriptions.
The public fields are `handled`, `value`, `openUrl`, `messages`, `uiEffects`, and
`browser`. Plugins cannot directly start platform UI or bypass user confirmation;
the host may ignore effects unsupported on the current platform. Canonical schema:
`schemas/plugin/action-result.schema.json`.

## Source switching

Source switching is a host transaction, not a plugin capability. The selected
plugin supplies a normalized `detail` and `catalog`; the host keeps the existing
bookshelf `book_id`, groups, tags, bookmarks, and reading-progress record while
replacing `source_id`, `source_book_key`, `plugin_books`, and the chapter set.

Progress and bookmarks map to the new catalog by chapter key, then by a
whitespace-normalized exact title, then by the clamped prior ordinal. Character
offset and page hint reset because text pagination is source-specific. Old source
chapter content and integrity metadata are never reused. A switch is rejected when
the replacement plugin is disabled, its catalog is empty, or the target
`(plugin_id, book_key)` already belongs to another bookshelf record.
