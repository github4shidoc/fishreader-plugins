# 发现筛选（可选扩展）

支持筛选的宿主在 `exploreMenu` 与 `explore` 输入中传递 `exploreStateJson`。
初次进入、切换发现源或主动刷新时值为 `"{}"`；分类切换与分页保留当前值。
该字符串由插件解释，宿主仅保存在发现页面内存状态，不持久化或同步。

`exploreMenu` 仍返回数组。普通分类继续使用 `key/title/group`。
筛选项使用 `key/title/filterType/options/value`，`filterType` 支持
`select`、`toggle`、`text`；前两者的 `options` 是可选字符串数组，`text` 使用输入框。
首个筛选项可附带 `stateJson`，作为后续调用的 `exploreStateJson`。
宿主把筛选项与分类分开，仅在存在受支持筛选项时显示筛选入口。

确定面板时，再次调用 `exploreMenu`，附加 `filtersJson`：
`[{"key":"筛选项标识","value":"所选值"}]` 的 JSON 字符串，仅包含改变项。
插件校验这些标识与选项，返回更新后的分类、筛选项与会话状态。
首个筛选项可附带 `resultCategoryKey` 指向本次筛选的结果分类。宿主确认该键
属于当前源的普通分类后，优先进入该分类；没有提示时保留当前分类。
阅读兼容插件比较筛选前后各分类的分组、标题及原始 URL，忽略菜单索引位移：
当前分类受筛选影响时优先保留，否则使用源菜单顺序中的第一个变化入口。
不使用源名称或特定分类名称识别结果入口。
取消或返回关闭面板不调用插件。成功后宿主用新状态重新加载当前分类第一页。

阅读兼容插件从源的发现菜单提取 `select/toggle/text` 定义，沿用源的
`chars/default/viewName/action` 与 `infoMap` 语义。临时会话中对 `infoMap`
及该源 `source.getVariable/setVariable/putVariable` 的更改只进入会话快照；
初始源变量仍从既有配置读取，以保留原有登录配置。
未传递 `exploreStateJson` 的旧宿主仍只收到普通分类，保持旧接口兼容。

此扩展不改变同步格式、数据库、同步设置注册表或插件权限。
