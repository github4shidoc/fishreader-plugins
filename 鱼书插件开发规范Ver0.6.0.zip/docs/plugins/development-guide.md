# 鱼书插件开发规范及指南（鸿蒙版）

文档版本：0.6.0
对应应用版本：鱼书鸿蒙版 0.6.0
适用协议：插件包 `schemaVersion: 1`
建议 SDK：`1.0`
最后更新：2026-09-27

## 1. 文档目标

本文仅适用于鱼书鸿蒙版，面向希望扩展在线内容检索、分类浏览、详情、目录、正文、字典、TTS 或管理界面的开发者，说明插件包的结构、接口、权限、安全边界、性能要求和发布检查方法。独立 HTML 网页导入是另一种入口，见第 8 节，不应与插件包混用。主题插件能力尚未完成，本版暂不纳入公开开发规范。

本文只描述公开且可复用的宿主能力。运行引擎的内部对象、平台私有 API、调试入口和兼容实现细节不属于公开协议，不应被插件依赖。

开发者应确保插件访问的服务、数据和账号均已获得合法授权，并遵守目标服务条款、版权规则及所在地法律。插件不得提供绕过登录、付费、访问控制、反自动化措施或其他安全限制的功能。

### 1.1 0.6.0 更新摘要

- 将文档基线更新到鱼书鸿蒙版 0.6.0；插件包协议仍为 `schemaVersion: 1`，建议 SDK 仍为 `1.0`。
- 保留发现页筛选状态扩展、可选 `reader.environment.info()` 以及 Ver0.5.8 的完整插件契约。
- 用户导入的独立 HTML 网页新增按网页条目和 Origin 隔离的持久化 `localStorage`。
- 网页播放器新增能力探测、播放器内按集取链回应、下一集预取、播放中进度回传、断点续播和刷新取链事件。
- 同步更新网页视频请求类型、通用媒体参数、Schema、示例与兼容要求。
以下原 0.5.0 约束继续适用：

- `sourceFormat` 只允许宿主公开支持的枚举值；自定义字符串会在导入阶段被拒绝。
- 管理页面必须同时声明 `managementModule`、`ui` 入口和唯一同名 `modules` 项，三者不得缺失或分离。
- 私有数据库查询的 `maximumRows` 必须为 `1..500`；超过 500 条的数据应使用稳定排序的 `LIMIT/OFFSET` 或稳定游标分页读取。
- 多目标检索继续使用滑动槽位：任一请求完成即补入下一项，并允许结果增量投递，不等待固定整批完成。
- 补充图片变换、受控动作回调、目标主页与图标、延迟元数据、媒体类型路由以及网页桥接的公开结果约束。
- 保留大型目录 `host-file-v1`、强制刷新、媒体分段、音色选择、文字 TTS 与有声内容边界、批量存储、编码转换和私有数据库规范。

本次更新未改变插件包协议主版本。普通 `fishreader-js` 插件无需仅为文档版本号重新打包；只有在使用新增可选能力、调整权限或修正不符合当前声明约束的包时，才需要发布新插件版本。`legado-compat` 的大型目录实现仍必须声明 `host-file-v1`。

## 2. 基本模型

FishReader 插件包分为两种公开形式，并可通过 `pluginKinds` 声明一种或多种能力：

- `fishreader-js`：以 CommonJS 模块实现数据入口，适合检索、浏览和内容获取。
- `fishreader-html`：以受限 HTML 页面提供交互界面，适合纯界面型扩展。

本指南当前纳入的能力值为 `source`、`dictionary` 和 `tts`。未填写 `pluginKinds` 时按 `source` 处理，以兼容已有插件。不同能力的必需入口不同；同一插件声明多种能力时，必须同时实现各能力的全部必需入口：

| 能力 | 必需入口 |
| --- | --- |
| `source` | `search`、`detail`、`catalog`、`content` |
| `dictionary` | `dictionary` |
| `tts` | `ttsVoices`、`ttsSynthesize` |

这里的 `fishreader-html` 是带 `.fishplugin.json` 声明信息的插件包；用户从“网页与订阅 → 网页”导入的独立 `.html` 不属于这两种插件包形式。

`fishreader-js` 还可以携带一个可选的管理页面。管理页面和主模块共享同一插件的私有存储、Cookie 与授权域名，但不能直接访问系统网络、文件系统或原生对象。

所有插件均运行在受限环境中：

- 不能直接访问文件系统、进程、环境变量、套接字或系统 API。
- 网络、存储、Cookie、数据库、摘要计算和 HTML 解析必须经宿主桥接。
- 网络请求只能访问声明信息中声明且由用户授权的域名。
- 宿主可以中止超时、超限、越权或返回结构不合法的执行。
- 不同插件的数据、Cookie 和数据库彼此隔离。

## 3. 插件包

### 3.1 文件与编码

插件包是 UTF-8 编码的 JSON 文件，建议使用扩展名：

```text
*.fishplugin.json
```

包的顶层结构如下：

```json
{
  "schemaVersion": 1,
  "manifest": {},
  "source": "module source code",
  "modules": {
    "manage.html": "optional management page"
  }
}
```

字段说明：

| 字段 | 必需 | 说明 |
| --- | --- | --- |
| `schemaVersion` | 是 | 当前固定为 `1`。 |
| `manifest` | 是 | 插件身份、入口和权限声明。 |
| `source` | 是 | 主模块源码；HTML 类型时为主页面源码。 |
| `modules` | 否 | 附加模块映射。目前主要用于管理页面。 |

当前大小上限：

- 完整插件包：5 MiB。
- 主模块源码：4 MiB。
- 单个管理页面：4 MiB。

宿主可能在后续版本中采用更低的运行时限额。插件不应把上限当作推荐值。

### 3.2 最小声明信息

下面是一个最小的 `fishreader-js` 声明信息：

```json
{
  "schemaVersion": 1,
  "pluginId": "org.example.catalog",
  "name": "示例内容插件",
  "version": "0.1.0",
  "sdkVersion": "1.0",
  "sourceFormat": "fishreader-js",
  "pluginKinds": ["source"],
  "entryModule": "index.js",
  "entrypoints": ["search", "detail", "catalog", "content"],
  "permissions": {
    "networkDomains": ["api.example.com"],
    "redirectDomains": [],
    "cookieScope": false,
    "pluginStorage": true,
    "pluginDatabase": false,
    "standardCrypto": false,
    "htmlParse": true,
    "webViewAutomation": false,
    "loginBrowser": false
  }
}
```

声明信息字段：

| 字段 | 规则 |
| --- | --- |
| `schemaVersion` | 当前固定为 `1`。 |
| `pluginId` | 插件的稳定且全局唯一标识。发布后不得因改名而变更。建议使用反向域名格式。 |
| `name` | 面向用户的插件名称。 |
| `version` | 插件版本，必须使用 SemVer，例如 `0.1.0`。 |
| `sdkVersion` | 所依赖的公开 SDK 主次版本，例如 `1.0`。 |
| `sourceFormat` | 只能使用宿主公开支持的 `fishreader-js`、`fishreader-html` 或 `legado-compat`；不得自定义格式名称。 |
| `catalogStorage` | 可选。仅使用宿主大型目录文件协议的兼容插件声明 `host-file-v1`；普通书源插件不要声明。 |
| `pluginKinds` | 可选能力数组：`source`、`dictionary`、`tts`；省略时等同于 `["source"]`。 |
| `entryModule` | 主模块文件名。JS 使用 `.js` 或 `.mjs`；HTML 使用 `.html` 或 `.htm`。 |
| `entrypoints` | 插件实际实现的入口列表。声明与实现必须一致。 |
| `permissions` | 最小权限声明。未声明的能力不得调用。 |
| `description` | 可选，说明用途、数据范围和账号要求。 |
| `managementModule` | 可选，JS 类型的管理页面文件名；使用时必须同时声明 `ui` 入口，并在 `modules` 中仅提供一个同名页面。 |
| `urlSchemes` | 可选，自定义链接协议数组，例如 `["legado"]`；必须有 `ui` 入口，规则见 7.2.1。 |
| `webPageActions` | 可选布尔值；声明为 `true` 时必须有 `manage` 和 `ui` 入口，规则见 7.2.2。 |
| `loginUrl` | 可选，使用登录浏览器时的 HTTPS 地址。 |
| `exploreCategories` | 可选，静态分类列表，最多 64 项。 |
| `contentHash` | 可选，主模块 SHA-256，用于完整性检查。 |

声明信息的机器可读定义见 [插件声明信息 Schema](../../schemas/plugin/source-plugin-manifest.schema.json)。Schema 与本文冲突时，以与目标应用版本一起发布的 Schema 为准。

### 3.3 安装与升级语义

- 新安装的交互型插件默认禁用，用户确认后才能启用。
- 同一 `pluginId` 的新包视为原位升级。
- 升级前，宿主应展示版本变化、新增域名和新增能力。
- 升级成功后保留原有启用状态、私有键值、数据库、Cookie、实例变量和已授予域名。
- 插件负责自己的持久化结构迁移。建议保存独立的 `dataVersion`，并使迁移可重复执行。
- 取消升级或校验失败不得留下部分写入。

### 3.4 五分钟完成第一个可运行插件

仓库提供了一个不访问网络、无第三方依赖的[入门示例](../../examples/plugin-development/basic/)。目录包含：

- `manifest.json`：插件声明信息。
- `index.js`：四个必需入口的源码。
- `build.mjs`：把前两个文件打包为可导入文件。
- `smoke-test.mjs`：在导入前检查打包结果和四个必需入口。

准备 Node.js 18 或更高版本，然后执行：

```bash
cd examples/plugin-development/basic
node build.mjs
node smoke-test.mjs
```

成功后会生成：

```text
fishreader-quickstart.fishplugin.json
```

在 FishReader 中完成运行验证：

1. 打开“设置 → 插件管理”。
2. 选择导入按钮并选择刚生成的文件。
3. 启用“FishReader 入门示例”。
4. 进入检索页面，输入任意关键词。
5. 打开“示例内容”，确认详情、第一章和正文均能显示。

这个示例先验证打包和四个必需入口。确认闭环可用后，再逐步加入网络、HTML 解析、Cookie 或管理页面；每增加一项能力，同时更新 `permissions` 并重新验证。

## 4. JS 入口规范

主模块使用 CommonJS 导出函数。入口可以直接返回 JSON 值，也可以返回 `Promise`。为保持跨平台一致性，示例和正式插件都应使用 `async`/`await`。

```js
module.exports.search = async function (input) {
  return [];
};
```

不得返回原生对象、函数、循环引用、DOM 节点或自定义类实例。所有输入和输出都必须可安全序列化为 JSON。

### 4.1 入口一览

| 入口 | 必需 | 输入 | 输出 |
| --- | --- | --- | --- |
| `search` | 内容插件必需 | `{ keyword, page, sourceKey? }` | 内容摘要数组，最多 500 项。 |
| `detail` | 内容插件必需 | `{ bookKey, bookUrl?, sourceKey?, forceRefresh?, title?, author?, coverUrl?, latestChapter? }` | 单个详情对象。 |
| `catalog` | 内容插件必需 | `{ bookKey, bookUrl?, tocUrl?, sourceKey?, forceRefresh?, cacheBookId?, cacheTransactionId?, cacheDeferActivation? }` | 有序章节数组。后三个缓存字段仅提供给声明 `host-file-v1` 的兼容插件。 |
| `content` | 内容插件必需 | `{ bookKey, chapterKey, chapterUrl?, customVariable?, mediaType?, cacheBookId? }` | 单章内容对象。`cacheBookId` 仅供宿主目录文件协议使用。 |
| `exploreMenu` | 否 | `{ exploreStateJson?, filtersJson? }` | 动态分类和可选筛选项数组，最多 128 项。 |
| `explore` | 否 | `{ category, page, exploreStateJson? }` | 内容摘要数组，最多 500 项。 |
| `loginCheck` | 否 | `{}` | `{ loggedIn, message? }`。 |
| `searchTargets` | 否 | `{}` | 插件管理的可检索目标列表。属于进阶能力。 |
| `searchPrepareBatch` | 否 | `{ keyword, page, sources, concurrency }` | 为多个目标准备 HTTP 请求。属于高性能进阶能力。 |
| `searchParseBatch` | 否 | `{ keyword, page, items }` | 批量解析宿主已完成的 HTTP 响应。属于高性能进阶能力。 |
| `searchBatch` | 否 | `{ keyword, page, sources, concurrency }` | 多目标批量检索结果。用于不支持拆分准备与解析的实现。 |
| `manageSearchTarget` | 否 | `{ sourceKey, action }` | `{ changed }`。属于进阶能力。 |
| `permissionGroups` | 否 | `{}` | 按功能分组的授权域名列表。属于进阶能力。 |
| `dictionary` | 字典插件必需 | `{ word, context? }` | `{ title?, text?, html? }`。 |
| `ttsVoices` | TTS 插件必需 | `{}` | 可用声音数组，最多 256 项。 |
| `ttsSynthesize` | TTS 插件必需 | `{ text, voiceKey, speed }` | 由宿主执行的音频请求描述。 |
| `image` | 否 | `{ url, sourceKey?, bookKey?, ... }` | `{ dataBase64, contentType? }`。仅在确需图片变换时声明。 |
| `payAction` | 否 | 宿主传入的内容与章节定位信息 | 受控交互动作结果。 |
| `callback` | 否 | 宿主传入的回调定位信息 | 受控交互动作结果。 |
| `manage` | 否 | 管理页面自定义 JSON | 管理页面专用 JSON 结果。 |

未实现的可选入口不要写入 `entrypoints`。`exploreMenu` 和 `exploreCategories` 可以二选一；需要根据登录状态动态变化时使用前者。

以下兼容输入均为可选字段：

- `forceRefresh: true` 表示用户或宿主要求重新获取详情或目录。插件应跳过自己可控的过期缓存并重新请求；字段缺失或为 `false` 时可沿用正常缓存策略。
- `cacheBookId` 是宿主书架记录的稳定 ID；使用 `host-file-v1` 时必须原样传回 `reader.catalogCache`，不得用插件 ID、书源 ID 或可变 URL 自行替换。
- `cacheTransactionId` 标识本次目录写入；`cacheDeferActivation: true` 表示先生成候选文件，由宿主在书籍数据库提交成功后激活。插件不得假定候选提交等于换源或刷新已经成功。
- `title`、`author`、`coverUrl` 和 `latestChapter` 是宿主已有的摘要提示，用于远端详情字段缺失时辅助定位。插件不得直接把这些提示当作已验证详情返回。
- `mediaType` 可帮助 `content` 在文字、漫画、有声内容或视频规则间选择正确路径。
- `customVariable` 是当前内容请求的受限运行变量；有声内容存在音色选择时，宿主会传入用户选择的 `toneOptions[].value`。插件不应擅自持久化该值，也不得把它当作账号密钥。
- `exploreStateJson` 是发现页会话状态 JSON 字符串；`filtersJson` 仅在确认筛选变更时传入 `exploreMenu`。旧宿主不传这些字段时仍应返回普通分类。详见[发现筛选契约](discover-filters.md)。

宿主可能忽略旧插件不认识的可选输出，也可能向新插件传入旧插件不认识的可选输入。插件应读取自己需要的字段并忽略其余字段，不得用输入对象字段数量判断宿主版本。

`image`、`payAction` 和 `callback` 是可选公开入口。没有相应业务时不要声明；使用时必须严格遵守本指南和目标应用随附的结果 Schema，不得把它们用于绕过权限、用户确认或平台安全限制。

普通插件不需要实现三个进阶入口。只有一个插件内部管理多个独立检索目标时才使用：

```js
module.exports.searchTargets = async function () {
  return [{
    sourceKey: "target-1",
    name: "示例目标",
    groups: ["默认分组"],
    homeUrl: "https://example.com/",
    iconUrl: "https://example.com/favicon.ico",
    metadataDeferred: false
  }];
};

module.exports.permissionGroups = async function () {
  return [{
    key: "target-1",
    title: "示例目标",
    domains: ["api.example.com", "cdn.example.com"]
  }];
};

module.exports.manageSearchTarget = async function ({ sourceKey, action }) {
  // 当前宿主可能传入 disable 或 delete。
  return { changed: false };
};
```

实现 `searchTargets` 后，`search`、`exploreMenu`、`explore`、`detail` 和 `catalog` 的输入中可能额外包含 `sourceKey`，插件应据此选择目标。每个目标最多 64 个分组；`sourceKey` 必须稳定且唯一。`homeUrl` 和 `iconUrl` 是可选 HTTP(S) 地址；没有可靠值时应省略。`metadataDeferred: true` 表示先展示基本目标，图标或主页信息稍后再补，首次列表不应为了逐项联网而阻塞。

`mediaType` 是可选的源类型字符串（最多 64 字符），通常为 `text`、`comic`、`audiobook`、`video` 或 `file`，用于源选择页面的类型分类。省略时保留宿主原有分类方式；此字段不替代具体书籍或目录返回的类型。阅读书源 243 开始返回该字段，需要配套支持该字段校验的宿主版本；旧宿主的严格字段校验会拒绝它。

#### 多目标高性能检索

一个插件内部管理大量独立目标时，推荐同时实现 `searchPrepareBatch` 与 `searchParseBatch`。宿主优先使用这组拆分入口，其次使用 `searchBatch`，最后回退到逐目标调用 `search`。

`searchPrepareBatch` 只负责计算请求，不应等待网络完成：

```js
module.exports.searchPrepareBatch = async function ({ keyword, page, sources, concurrency }) {
  return sources.map(target => ({
    sourceKey: target.sourceKey,
    sourceName: target.sourceName,
    request: {
      url: "https://api.example.com/search?q=" + encodeURIComponent(keyword),
      method: "GET"
    },
    parseContext: { page }
  }));
};
```

每个准备结果必须包含 `sourceKey` 和 `sourceName`，并返回以下四种状态之一：

- `request` 与可选 `parseContext`：交给宿主执行 HTTP，随后进入解析队列。
- `books`：无需 HTTP，直接返回该目标的摘要数组。
- `fallback: true`：该目标退回普通 `search`。
- `errorMessage` 与可选 `timedOut`：该目标立即失败，不占用 HTTP 槽位。

`searchParseBatch` 接收一小批已完成响应并逐目标返回结果：

```js
const mapSummary = value => ({
  bookKey: String(value.id),
  title: String(value.title || ""),
  author: String(value.author || "")
});

module.exports.searchParseBatch = async function ({ keyword, page, items }) {
  return items.map(item => {
    if (item.errorMessage) {
      return {
        sourceKey: item.sourceKey,
        sourceName: item.sourceName,
        books: [],
        errorMessage: item.errorMessage,
        timedOut: item.timedOut === true
      };
    }
    const data = JSON.parse(item.response.body);
    return {
      sourceKey: item.sourceKey,
      sourceName: item.sourceName,
      books: data.items.map(mapSummary)
    };
  });
};
```

批量结果项为 `{ sourceKey, sourceName, books, errorMessage?, timedOut? }`。宿主在 HTTP 无数据、连接失败或返回错误时会立即释放并补充槽位；有响应的任务进入 JS 解析队列后也不再占用 HTTP 槽位。HTTP 调度不会等待上一批 JS 解析结束。插件不得自行把全部目标切成固定批次后串行等待。

如果无法把“构造请求”和“解析响应”拆开，可以实现 `searchBatch`。它接收与 `searchPrepareBatch` 相同的输入并返回同样的批量结果项。需要在插件内部并发 HTTP 时，可使用 `reader.http.fetchBatch`；宿主仍会按用户设置和平台上限控制实际并发。

#### 后台检索生命周期

0.5.0 宿主可以在用户离开检索页面后继续执行任务，并在其他页面显示进度。插件代码因此必须是与页面无关的纯任务：

- 不保存或访问页面组件、DOM、路由对象和临时界面状态。
- 使用稳定的 `bookKey`；宿主会据此增量合并、局部更新和恢复检索结果。
- `reader.result.emit` 只提交真正新增或变化的摘要，并控制频率；最终返回值仍应包含完整结果。
- 用户停止任务后，宿主可以中断执行并丢弃在途结果。插件不得依赖取消后的回调完成持久化。
- 同一入口可能在不同工作线程或隔离进程执行，不得依赖跨调用共享的可变原生实例。

### 4.2 字典入口

字典插件只需要声明 `pluginKinds: ["dictionary"]` 和 `entrypoints: ["dictionary"]`。宿主在用户选择文字后调用：

```js
module.exports.dictionary = async function ({ word, context }) {
  const response = await reader.http.fetch({
    url: "https://dict.example.com/api?q=" + encodeURIComponent(word),
    method: "GET"
  });
  const data = JSON.parse(response.body);
  return {
    title: word,
    text: String(data.explanation || "暂无释义")
  };
};
```

返回对象至少包含 `text` 或 `html` 之一：

| 字段 | 说明 |
| --- | --- |
| `title` | 可选标题，最长 256 字符。 |
| `text` | 可选纯文本释义，最长 256 KiB。 |
| `html` | 可选 HTML 片段，最长 2 MiB。宿主会移除脚本、表单、外链和事件属性。 |

插件不得返回任意网页地址要求宿主直接打开。需要远端数据时，由插件经已授权域名获取并解析，再返回纯文本或有限 HTML。多个已启用字典插件可能同时参与查询，插件不应假设自己是唯一结果来源。

可直接构建和导入的实现见 [`plugins/dictionary-example`](../../plugins/dictionary-example/)。

### 4.3 TTS 入口

TTS 插件声明 `pluginKinds: ["tts"]`，并同时实现 `ttsVoices` 与 `ttsSynthesize`。`ttsVoices` 返回声音清单：

```js
module.exports.ttsVoices = async function () {
  return [{
    voiceKey: "default",
    name: "默认声音",
    locale: "zh-CN",
    gender: "neutral",
    description: "示例声音",
    packageId: "mandarin",
    packageName: "普通话语音包"
  }];
};
```

`voiceKey` 必须在插件版本内稳定且唯一。`name` 必需，`locale`、`gender` 和 `description` 可选。
多音色插件还可以为每条音色提供稳定的 `packageId` 和展示用 `packageName`；阅读器会按语音包生成
统一音色选择面板的 TAB。省略这两个字段时，所有音色归入以插件名命名的单一分组。

`ttsSynthesize` 不返回音频二进制，而是返回由宿主执行的受控网络请求：

```js
module.exports.ttsSynthesize = async function ({ text, voiceKey, speed }) {
  return {
    url: "https://tts.example.com/v1/speech",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": "audio/mpeg"
    },
    body: JSON.stringify({ text, voice: voiceKey, speed }),
    contentType: "audio/mpeg",
    cacheKey: voiceKey + ":" + speed + ":" + text
  };
};
```

约束：

- `url` 必须属于用户授权域名，只支持 HTTP(S)。
- `method` 只允许 `GET`、`POST` 或 `PUT`。
- 请求体最大 1 MiB，请求头最多 64 项。
- `contentType` 应为实际音频类型，例如 `audio/mpeg`、`audio/mp4`、`audio/wav` 或 `audio/ogg`。
- `cacheKey` 可选；宿主据此复用同一插件版本产生的音频并限制缓存数量。它只应包含影响音频内容的稳定参数，不得包含令牌或个人信息。
- 插件不得把音频编码为 Base64 塞入执行结果，也不得直接控制播放器。

宿主负责文本分段、下一段预取、失败重试、音频下载、大小限制、缓存、播放队列、中断、音频焦点和临时文件清理。插件只负责把文本和声音参数转换为一个可审计的请求描述。

TTS 只用于把文字内容合成为语音。`contentType: "audio"` 表示有声内容，由有声播放器按章节播放；它不属于 TTS，也不能通过 `ttsSynthesize` 返回。一个插件可以同时声明 `pluginKinds: ["source", "tts"]`，但必须分别实现两套必需入口并返回各自的结果结构。兼容插件可以把第三方 HttpTTS 规则转换成公开的 `ttsVoices` / `ttsSynthesize`，普通插件不应依赖兼容层的私有规则对象。

可配置服务地址、请求头和请求体模板的实现见 [`plugins/tts-template`](../../plugins/tts-template/)。导入后先在插件管理页填写合法服务信息并确认授权域名，再到阅读设置中选择该声音。

### 4.4 图片变换与受控交互

这三个入口不是普通内容插件的必需项。没有对应业务时不要声明。

`image` 用于宿主已经取得图片地址后，交给插件完成必要的字节变换：

```js
module.exports.image = async function (input) {
  const response = await reader.http.fetch({
    url: input.url,
    method: "GET",
    responseType: "base64"
  });
  return {
    dataBase64: response.body,
    contentType: response.contentType || "image/jpeg"
  };
};
```

`dataBase64` 必须是不含 data URL 前缀的 Base64，解码后不得为空；`contentType` 必须与实际媒体类型一致。`payAction` 与 `callback` 只能返回普通 JSON 的受控动作描述，允许字段为 `handled`、`value`、`openUrl`、`messages`、`uiEffects` 和 `browser`。插件不能自行启动系统页面、直接修改宿主界面或绕过用户确认；宿主可以忽略当前平台不支持的动作。

完整结构见[图片变换结果 Schema](../../schemas/plugin/image-result.schema.json)和[受控动作结果 Schema](../../schemas/plugin/action-result.schema.json)。

### 4.5 内容摘要

```json
{
  "bookKey": "example:item:1001",
  "title": "示例标题",
  "sourceName": "示例站点",
  "author": "示例作者",
  "intro": "简短介绍",
  "coverUrl": "https://cdn.example.com/covers/1001.jpg",
  "bookUrl": "https://api.example.com/items/1001",
  "latestChapter": "第 36 章",
  "wordCount": "12 万字",
  "types": ["东方玄幻", "系统流"],
  "publicationStatus": "连载",
  "lastUpdated": "2026-08-15T10:30:00+08:00",
  "mediaType": "text"
}
```

规则：

- `bookKey` 和 `title` 必需。
- `bookKey` 必须稳定，同一内容在分页、分类和多次检索中应返回相同值。
- URL 应为绝对 HTTP(S) 地址；相对地址应在插件内解析。
- 缺失信息应省略字段或返回空字符串，不得用伪造内容填充。
- 列表阶段不得为了补齐章节数量逐项调用详情或目录接口。已有摘要信息可写入 `latestChapter`，没有则留空。
- `types` 表示一个或多个内容分类；`kind` 仅供旧实现兼容，新插件优先返回 `types`。
- `mediaType` 可取 `text`、`comic`、`audiobook` 或 `video`，缺省时按 `text` 处理。不要把题材分类写入 `mediaType`。
- `sourceName` 只在一个插件管理多个独立目标时使用；普通插件可省略，由宿主显示插件名称。

### 4.6 详情

```json
{
  "bookKey": "example:item:1001",
  "title": "示例标题",
  "author": "示例作者",
  "intro": "完整介绍",
  "coverUrl": "https://cdn.example.com/covers/1001.jpg",
  "bookUrl": "https://api.example.com/items/1001",
  "tocUrl": "https://api.example.com/items/1001/chapters",
  "types": ["幻想", "冒险"],
  "publicationStatus": "完结",
  "lastUpdated": "2026-08-15T10:30:00+08:00",
  "mediaType": "text",
  "canReName": false,
  "downloadUrls": [],
  "chapterCount": 120
}
```

`bookKey` 和 `title` 必需。`tocUrl` 应指向可供 `catalog` 使用的稳定地址。日期建议使用 ISO 8601；无法可靠转换时保留服务端原始短文本。`downloadUrls` 最多 64 项；它只描述合法可访问的候选地址，不代表宿主会自动下载。`canReName` 仅表示远端能力提示，不能绕过宿主确认。有声书建议返回 `chapterCount`；宿主会把 `catalog` 结果保存到应用目录缓存文件，不会把全部分集写入章节数据库，播放某一集时才调用 `content` 解析实际媒体链接。

### 4.7 目录

```json
[
  {
    "chapterKey": "example:item:1001:chapter:1",
    "title": "第一章",
    "ordinal": 0,
    "chapterUrl": "https://api.example.com/chapters/1",
    "isVolume": false,
    "isLocked": false,
    "mediaType": "text"
  }
]
```

规则：

- `chapterKey`、`title`、`ordinal` 必需。
- `chapterKey` 在同一内容项内必须唯一且稳定。
- `ordinal` 从 `0` 开始，必须与数组位置严格一致。
- 数组应保持阅读顺序，最多 20,000 项。
- 卷标题可设置 `isVolume: true`；不可读取项可设置 `isLocked: true`。
- `mediaType` 可覆盖摘要中的媒体类型，适用于同一目录混合文字、图片或音频章节。
- 不要在目录入口中预取每章正文。

### 4.8 正文与媒体内容

文本内容：

```json
{
  "contentType": "text",
  "content": "第一段\n\n第二段",
  "baseUrl": "https://api.example.com/chapters/1"
}
```

媒体内容：

```json
{
  "contentType": "audio",
  "content": "",
  "mediaUrl": "https://media.example.com/audio/1.m4a",
  "mediaUrls": [
    "https://media.example.com/audio/1-part-1.m4a",
    "https://media.example.com/audio/1-part-2.m4a"
  ],
  "mediaHeaders": { "Referer": "https://media.example.com/" },
  "toneOptions": [
    { "value": "narrator-a", "label": "播音 A" },
    { "value": "narrator-b", "label": "播音 B" }
  ],
  "title": "第一章",
  "message": "音频内容"
}
```

`contentType` 可取 `text`、`audio`、`video` 或 `structured`。非文本类型的 `content` 应为空字符串，并通过 `mediaUrl`、`mediaUrls` 或结构化数据提供实际内容。`mediaHeaders` 最多 64 项，只能包含获取当前媒体所需的请求头；不得返回换行符、Cookie 明文或无关标识。`mediaUrls` 最多 256 项，按数组顺序组成当前章节的一段或多段媒体；只有一段时可只使用 `mediaUrl`。`toneOptions` 最多 64 项，每项的 `value` 在当前内容内必须稳定且唯一，`label` 面向用户显示。没有真实可选音色时应省略或返回空数组，宿主不会显示音色按钮。用户选择后，宿主会以 `content({ customVariable })` 重新请求当前章节。`title` 和 `imageStyle` 是可选显示提示，不能包含可执行代码。单次返回的序列化结果不得超过 8 MiB。

## 5. 宿主 API

JS 模块通过全局 `reader` 对象访问宿主。下面列出公开能力；具体方法是否可用还取决于声明信息权限和当前平台。

JS 主模块的公开方法签名如下。除 `reader.result.emit` 外，调用前必须声明相应权限：

```text
reader.http.fetch(request)
reader.http.fetchBatch({ requests, concurrency })
reader.storage.get(key)
reader.storage.getBatch(keys)
reader.storage.set(key, value)
reader.storage.removeBatch(keys)
reader.storage.removeByPrefix(prefix)
reader.catalogCache.begin(request)
reader.catalogCache.writeChunk(request)
reader.catalogCache.commit(request)
reader.catalogCache.abort(request)
reader.catalogCache.readManifest(request)
reader.catalogCache.readChunk(request)
reader.catalogCache.deleteBook(bookId)
reader.source.getVariable()
reader.source.setVariable(value)
reader.cookie.get(url)
reader.cookie.getBatch(urls)
reader.cookie.set(url, cookie)
reader.cookie.clear(url?)
reader.database.execute(request)
reader.database.batch(request)
reader.database.query(request)
reader.database.queryJson(request)
reader.html.parse(request)
reader.html.parseBatch(request)
reader.crypto.digest(request)
reader.crypto.hmac(request)
reader.text.convert(request)
reader.text.decode(request)
reader.text.encode(request)
reader.webview.execute(request)
reader.environment.info()
reader.result.emit(summary)
```

所有示例都使用 `await`，这样既能处理同步返回，也能处理异步实现。不要把管理页面的低层 `FishReader.call(operation, args)` 参数形式直接套用到 JS 主模块。

跨平台插件应以 `http.fetch` / `http.fetchBatch`、`storage.get` / `storage.set`、`source.getVariable` / `source.setVariable`、`cookie.get` / `cookie.set` / `cookie.clear`、数据库基础方法、`html.parse`、`crypto.digest` 和 `result.emit` 为可移植基线。宿主还可以提供 `storage.getBatch`、`storage.removeBatch`、`storage.removeByPrefix`、`cookie.getBatch`、`database.queryJson`、`html.parseBatch`、`text.*` 和 `environment.info` 等可选能力。`catalogCache.*` 只属于显式声明 `host-file-v1` 的大型目录协议。调用扩展方法前必须检查方法是否存在，并提供基础方法回退或清晰提示。插件不得根据运行引擎名称调用未公开对象。

部分平台还提供 `reader.crypto.cipher/asymmetric/sign/verify`、`reader.file.read/write/delete/download/readTextFolder` 与 `reader.archive.zipEntry/extract/gzipEncode/gzipDecode/inflateDecode`。这些属于 0.5.0 的平台扩展，不是当前跨平台最低基线；插件必须在发布说明中列出已验证平台，并通过能力检测降级。文件路径始终位于插件私有目录，不能用于访问用户任意路径。

### 5.1 网络请求

```js
const response = await reader.http.fetch({
  url: "https://api.example.com/search?q=test",
  method: "GET",
  headers: {
    "Accept": "application/json"
  },
  charset: "utf-8"
});

if (response.status !== 200) {
  throw new Error("request failed: " + response.status);
}

const data = JSON.parse(response.body);
```

同一入口需要执行多个互不依赖的请求时，可以使用批量方法：

```js
const results = await reader.http.fetchBatch({
  requests: [requestA, requestB],
  concurrency: 2
});

for (const item of results) {
  if (!item.ok) continue;
  const response = item.result;
  // 解析 response.status、response.url、response.headers 和 response.body。
}
```

单次可以排队 1 至 2,048 个请求，实际并发最多 32 个。返回项与输入顺序一致，并包含 `ok`、可选 `result`、`error` 和 `timedOut`。`concurrency` 只是请求上限，宿主可以根据用户设置、平台资源和全局网络策略降低实际并发。任一槽位释放后宿主会立即补入下一项，但 `fetchBatch` 本身仍在所有请求结束后统一返回；需要边搜索边显示时应使用 `searchPrepareBatch`、`searchParseBatch` 和 `reader.result.emit`，不要把一个超大 `fetchBatch` 当作进度通道，也不要在插件中再创建无界 Promise 队列。批量请求的响应正文合计仍不得超过 16 MiB。

约束：

- 仅支持 HTTP(S)。
- 当前支持 `GET`、`POST`、`PUT`、`PATCH`、`DELETE` 和 `HEAD`。
- 单次请求体最多 1 MiB，响应最多 16 MiB。
- 默认执行窗口为 30 秒，宿主硬上限为 120 秒。
- 跳转最多 5 次，每次跳转都会重新检查域名授权。
- 支持常见 UTF-8、GBK、GB18030、Big5、Shift-JIS、EUC-KR、ISO-8859-1 和 Windows-1252 编码别名。

禁止通过开放跳转、代理地址、IP 替换、DNS 技巧或脚本拼接规避域名检查。

### 5.2 HTML 解析

```js
const titles = await reader.html.parse({
  html: response.body,
  selector: ".result .title",
  value: "text",
  all: true,
  limit: 100
});
```

`value` 可取 `text`、`textNodes`、`ownText`、`html`、`all`、`innerHTML`、`outerHTML` 或 `attribute`。单份 HTML 最大 16 MiB，选择器最长 32,768 字符，单次最多返回 50,000 项。读取属性时同时传入最长 256 字符的 `attribute`。这些是兼容上限而非推荐规模，最终结果仍受 8 MiB 执行结果上限约束。

`reader.html.parseBatch({ requests })` 一次最多接收 5,000 个解析请求，所有请求的 HTML 输入合计不得超过 16 MiB。多个请求使用同一 HTML 时，宿主可以复用解析树；插件仍应只请求实际需要的字段和数量。

传给 `selector` 的值必须是真实 CSS 选择器。JavaScript 表达式、浏览器指令或混合规则不能作为选择器使用。

### 5.3 私有键值存储

```js
await reader.storage.set("settings", { pageSize: 20 });
const saved = await reader.storage.get("settings");
```

- 每个值最多 1 MiB。
- 键只在当前插件内可见。
- `__host.` 前缀由宿主保留，插件不得使用。
- 不要存储不必要的个人信息、明文令牌或大块缓存。

迁移旧数据时可以使用 `removeBatch(keys)`；只有键空间设计明确且前缀足够具体时才使用 `removeByPrefix(prefix)`。删除不可恢复，插件应先提交新结构和引用关系，再清理旧键。大型目录不得继续按章节或代际写入这里。

### 5.4 大型目录文件缓存

`host-file-v1` 用于必须保留完整规则目录数据的兼容插件。普通 `fishreader-js` 书源直接返回规范化目录，由宿主写入书籍数据库，不需要声明或调用这一组 API。

使用该协议的插件需要同时满足：

- `sourceFormat` 是宿主明确支持的兼容格式，例如 `legado-compat`。
- 声明 `catalogStorage: "host-file-v1"` 及 `permissions.pluginStorage: true`。
- 使用宿主传入的 `cacheBookId`，并在 `content` 中使用同一个值读取目录分块。
- 每次刷新创建新 `generation`；不得重新使用旧代际或把完整目录复制回 Preferences。

推荐写入流程：

```js
const bookId = input.cacheBookId;
const transactionId = input.cacheTransactionId ||
  `catalog:${bookId}:${Date.now()}`;
const generation = `${Date.now()}`;

await reader.catalogCache.begin({
  bookId,
  transactionId,
  generation,
  sourceBinding: input.sourceKey || "",
  fingerprint: "rule-and-source-fingerprint",
  chapterCount: chapters.length
});

try {
  for (let index = 0; index < chunks.length; index += 1) {
    await reader.catalogCache.writeChunk({
      bookId,
      transactionId,
      index,
      value: chunks[index]
    });
  }
  await reader.catalogCache.commit({
    bookId,
    transactionId,
    deferActivation: input.cacheDeferActivation === true
  });
} catch (error) {
  await reader.catalogCache.abort({ bookId, transactionId });
  throw error;
}
```

读取时先验证代际，再读取所需分块：

```js
const manifest = await reader.catalogCache.readManifest({
  bookId: input.cacheBookId,
  generation
});
const chunk = manifest ? await reader.catalogCache.readChunk({
  bookId: input.cacheBookId,
  generation,
  index: chunkIndex
}) : null;
```

每个书架 `bookId` 只有一个活动 `.frcat` 文件。文件名不包含插件 ID、书源 ID、`sourceKey` 或 `bookKey`，因此换源不会改变文件名；文件清单记录所属插件，其他插件不能读取。单块最大 1 MiB、每书最多 20,000 块且总文件最大 128 MiB，目录章节数最多 20,000。宿主在普通刷新时可直接激活，在换源或需要与数据库一致提交时会先保存候选文件，数据库成功后才激活。失败时原活动文件保持不变。

兼容插件声明了 `host-file-v1` 却没有在目录调用中提交对应候选文件时，宿主会在书籍数据库切换前终止操作并提示更新插件。旧版 Preferences 目录代际只能在确认数据库不再引用后清理；删除书籍时由宿主清理对应 `.frcat`。插件不得自行猜测书架 ID 或跨书删除文件。

### 5.5 实例变量

```js
await reader.source.setVariable("custom value");
const current = await reader.source.getVariable();
```

实例变量适合保存一个由用户配置的短文本，最大 64 KiB。复杂配置应使用私有键值存储或数据库。

### 5.6 Cookie

```js
await reader.cookie.set(
  "https://api.example.com/",
  "session=example-value; Path=/; Secure; HttpOnly"
);

const cookieHeader = await reader.cookie.get("https://api.example.com/");
await reader.cookie.clear("https://api.example.com/");
```

`reader.cookie.get(url)` 返回可直接用于请求头的 Cookie 字符串。`reader.cookie.set(url, cookie)` 的第二个参数使用标准 `Set-Cookie` 文本；`reader.cookie.clear(url)` 清理指定地址相关项，不传地址时清理当前插件的全部 Cookie。

Cookie 能力要求 `cookieScope: true`。Cookie 由宿主按插件隔离，不得写入日志、导出包或同步数据。当前单项最大 4 KiB，每个插件最多 128 项。

### 5.7 摘要与 HMAC

```js
const digest = await reader.crypto.digest({
  algorithm: "SHA-256",
  text: "text"
});
```

HMAC 示例：

```js
const signature = await reader.crypto.hmac({
  algorithm: "SHA-256",
  key: "example-key",
  text: "text"
});
```

支持 `MD5`、`SHA-1`、`SHA-256`、`SHA-384` 和 `SHA-512`，返回 `{ algorithm, hex, base64 }`。摘要和 HMAC 都需要 `standardCrypto: true`；HMAC 还需要目标平台实现该方法。不得把弱摘要算法用于新的安全设计；保留它们仅用于协议兼容。

### 5.8 私有数据库

数据库属于扩展能力，需要 `pluginDatabase: true`，且当前平台实现可用。

```js
await reader.database.execute({
  sql: "CREATE TABLE IF NOT EXISTS cache (id TEXT PRIMARY KEY, value TEXT)",
  bindArgs: []
});

const result = await reader.database.query({
  sql: "SELECT id, value FROM cache WHERE id = ?",
  bindArgs: ["item-1"],
  maximumRows: 100
});
```

限制摘要：

- 单条 SQL 最长 16 KiB，绑定参数最多 2,048 个。
- 批处理最多 1,000 条语句。
- `maximumRows` 必须是 `1..500` 的整数，查询最多返回 500 行；需要读取更多记录时必须使用稳定排序的 `LIMIT/OFFSET` 或稳定游标分页，直到最后一页不足页长。
- 每个插件最多创建 32 张表。
- 只允许常规表、索引和增删改查；禁止附加外部数据库、扩展加载、触发器、视图、虚拟表、多语句和 SQL 注释。

0.5.0 的 `database.queryJson` 用于查询首列就是完整 JSON 值的结果，避免把大 JSON 拆成大量桥接行。它仍受 SQL、绑定参数、权限和结果大小限制；没有该方法时应回退到 `query` 或显示明确的不支持提示。

### 5.9 浏览器自动化

`reader.webview.execute` 是高风险、平台相关的扩展能力，需要 `webViewAutomation: true`。只有在普通 HTTP 与 HTML 解析无法完成合法业务时才应使用。

插件必须同时提供无该能力时的清晰错误或降级路径，不能假设所有平台都支持，也不能依赖特定内核对象或调试接口。

### 5.10 增量结果

支持该能力的平台可在 `search` 或 `explore` 中通过 `reader.result.emit(summary)` 提交单个内容摘要。提交值必须符合 4.5 节结构，不能传数组。增量输出用于降低首屏等待，也支持后台检索进度，不用于绕过单次结果数量和大小限制。

插件应控制提交频率，仅在拿到新结果时提交。入口最终返回的数组仍应包含完整结果；宿主会使用稳定键去重和局部更新。

### 5.11 插件环境信息（可选）

声明 `pluginStorage: true` 且宿主实现此方法时，可调用 `await reader.environment.info()`。返回字段包括 `version`、`buildNumber`、`device`、`id`、`userAgent`、`qysgBrowserVersion`。`id` 是宿主为**当前插件**保存的随机标识，不是系统硬件 ID，也不得当作跨设备用户身份。旧宿主可能没有该方法，调用前应检测 `reader.environment && typeof reader.environment.info === 'function'`；不应为取得环境信息而申请无关权限。

## 6. 权限声明

权限必须按最小化原则配置：

| 权限 | 用途 | 建议 |
| --- | --- | --- |
| `networkDomains` | 初始请求允许访问的域名。 | 只列实际使用项。 |
| `redirectDomains` | 跳转后允许访问的额外域名。 | 未使用跳转时保持空数组。 |
| `cookieScope` | 私有 Cookie 读写。 | 无登录态时关闭。 |
| `pluginStorage` | 私有键值存储。 | 需要保存设置时开启。 |
| `pluginDatabase` | 私有结构化数据库。 | 仅复杂数据使用。 |
| `standardCrypto` | 摘要与 HMAC。 | 仅协议确有需要时开启。 |
| `htmlParse` | 宿主 HTML 解析。 | 解析网页时开启。 |
| `webViewAutomation` | 受控浏览器执行。 | 默认关闭。 |
| `loginBrowser` | 受控登录页面。 | 需要用户登录时开启。 |

域名规则：

- 精确域名只匹配自身，例如 `api.example.com`。
- 通配符只能写为 `*.example.com`，它匹配子域名但不匹配根域名 `example.com`。
- 不要声明协议、路径、端口、查询参数或裸 `*`。
- 登录浏览器要求启用 `cookieScope`，并提供固定 `loginUrl` 或由管理页面通过受控桥接传入登录地址。
- 使用 HTTPS，避免在非加密链路上传输账号、令牌或内容。

## 7. 管理页面

### 7.1 声明

JS 插件可以声明管理页面：

```json
{
  "sourceFormat": "fishreader-js",
  "entryModule": "index.js",
  "managementModule": "manage.html",
  "entrypoints": ["search", "detail", "catalog", "content", "ui"]
}
```

包中必须有且只能有一个同名模块：

```json
{
  "modules": {
    "manage.html": "<!doctype html>..."
  }
}
```

声明 `managementModule` 时，`entrypoints` 必须包含 `ui`，`modules` 也必须只提供一个与 `managementModule` 完全同名的页面。JS 插件缺少其中任一项都应在打包或导入校验阶段报错；独立 HTML 插件不得再声明 `managementModule` 或附加 `modules`。

### 7.2 `FishReader` 桥接

管理页面不能直接发起网络请求。页面加载后等待桥接就绪，再调用宿主。优先使用类型化方法：

```html
<script>
  async function loadProfile() {
    await FishReader.ready;
    return FishReader.storage.get('profile');
  }
</script>
```

通用的 `FishReader.call(operation, args)` 属于低层入口，只有未提供对应类型化方法时才使用。它的参数总是一个对象，例如 `FishReader.call('storage.get', { key: 'profile' })`。注意：管理页面的 `FishReader` 与 JS 主模块的 `reader` 名称和调用位置不同，但类型化方法的参数形式保持一致。

常用方法：

- `http.fetch`
- `storage.get` / `storage.set`
- `database.execute` / `database.batch` / `database.query`
- `source.getVariable` / `source.setVariable`
- `cookie.get` / `cookie.set` / `cookie.clear`
- `crypto.digest`
- `html.parse`
- `plugin.execute`
- `plugin.validateSourcesAsync` / `plugin.executionStatus`（可选）
- `plugin.requestNetworkDomains`
- `ui.openLoginBrowser`
- `ui.pickTextFile`、`ui.pickDataFile`、`ui.readDataFile`、`ui.closeDataFile`
- `ui.createExportFile`、`ui.writeExportFile`、`ui.finishExportFile`、`ui.cancelExportFile`
- `ui.close`

0.5.0 管理页面可以在宿主提供时使用批量读取、`database.queryJson` 和 `html.parseBatch`。文件导入应先通过 `ui.pickTextFile` 或 `ui.pickDataFile` 取得宿主句柄，再按块读取，完成或放弃后调用 `closeDataFile`；导出应按 `createExportFile → writeExportFile（可重复）→ finishExportFile` 顺序完成，放弃时调用 `cancelExportFile`。单个导入或导出数据文件最大 100 MiB，单块最大 256 KiB，文件会话空闲 15 分钟后失效。不得假设页面能直接持有系统文件对象，也不得一次性把大文件复制进 JavaScript 字符串。

管理大量独立书源的插件可以在宿主提供时调用 `plugin.validateSourcesAsync({ sourceKeys, keyword?, concurrency? })`，并使用返回的 `executionId` 轮询 `plugin.executionStatus(executionId)`。状态中的 `progress` 包含 `completed`、`total`、`failed` 和 `done`；完成后再读取 `ok`、`result` 或 `error`。该能力目前不是所有平台的最低基线，页面必须先检测方法是否存在，且不能通过高频轮询阻塞 WebView 或重绘整个列表。

部分方法依赖平台能力。调用失败时应显示可理解的提示，并允许用户重试或返回。

#### 7.2.1 网页链接交给插件处理

插件可在 manifest 中声明 `"urlSchemes": ["legado"]`。协议名不带 `:` 或 `://`，使用小写，
匹配规则为 `[a-z][a-z0-9+.-]{0,31}`，最多 16 个且不得重复。仅有管理页面或独立 HTML 页面的插件可声明。
HTTP、HTTPS、file、content、data、javascript、about、blob、resource、chrome、devtools、intent、
mailto、tel、sms、market、magnet、fishreader 属于保留协议，不可注册。

宿主在内置网页的主框架导航遇到该协议时，查找已安装且启用的插件。多个插件匹配时先选择插件，
然后弹出“是否使用 XX 插件处理”的取消/确认弹窗。取消不改变原网页；确认使用页面栈新开插件 UI，
不得替换、重载或销毁原网页，关闭插件页回到原网页。声明不等于授予额外网络或存储权限。
没有处理插件时提示安装或更新插件；应用不能硬编码 `legado` 到某个插件 ID。

管理页初始化完成后读取此次打开的链接：

```javascript
await FishReader.ready;
await initializeDatabase();
if (typeof FishReader.ui.takeLaunchUrl === 'function') {
  const url = await FishReader.ui.takeLaunchUrl();
  if (url) await importFromProtocolUrl(url);
}
```

`ui.takeLaunchUrl()` 返回 Promise<string>：首次调用返回用户已确认的原始链接，之后返回空字符串；
普通打开也返回空字符串。链接按数据传递，不拼接成脚本执行。网页返回、页面重新获焦不重复触发导入。
插件自行解析、校验参数并处理；宿主保留已有权限代理。当前鸿蒙宿主支持此可选扩展，旧宿主或其他
未实现的宿主需要按上述示例检测方法，不能影响正常手动导入。

#### 7.2.2 插件关联网页的操作入口

插件可声明 `"webPageActions": true`。宿主仅对已启用、声明此能力的插件调用
`manage({ mode: "webPage", targetKey })`；`targetKey` 是该插件提供的项目标识，不能按页面标题匹配。
此查询仅返回元数据，不应请求网络、执行登录脚本或修改设置。返回格式：

```javascript
{ direct: true, url: "https://example.com/page", actions: [
  { id: "configure", title: "登录/设置" }
] }
```

`direct` 为 `true` 且 `url` 为 HTTP(S) 地址时，项目可直接打开网页；否则沿用列表流程，
`url` 可为空。`actions` 最多 8 项，ID 唯一且匹配 `[a-zA-Z0-9._-]{1,64}`，标题 1–32 字符。
没有可用操作时返回空数组；宿主不创建占位按钮。普通网页可用 `manage({ mode: "webPage", url })` 查询关联，宿主仅传 HTTP(S) 的 origin 和 pathname，不传查询参数、片段或 URL 账号。插件自行精确匹配已管理项目，匹配时额外返回 `targetKey`；未匹配返回空数组。同一网址出现多个匹配时不自动选择。

用户点击操作后，宿主在当前网页所属导航栈中打开插件管理页，携带 `{ id, targetKey }`。
管理页等待 `FishReader.ready` 后调用 `FishReader.ui.takeLaunchAction()` 获取参数，随后复用插件已有操作。
首次返回对象，之后及普通打开时返回 `null`；旧宿主需先检测此方法是否存在。
此接口沿用管理页已认证的桥接通道，不能由普通网页调用。插件应重新检查项目是否存在、是否启用。
返回时保留原网页，不自动刷新或重建；网页与项目的关联仅保存在当前窗口内存中，不写入同步数据。

当前鸿蒙宿主支持此可选扩展。它不隐含执行网页请求头、注入脚本、登录或跳转拦截规则，
这些仍由各插件已有能力处理；未声明能力的插件继续使用原有打开流程。

阅读插件支持 `legado://import/bookSource?src=<URL>`，同时支持已有导入能力对应的 `rssSource` 和
`httpTTS`；`src` 推荐用 `encodeURIComponent` 编码，只接受 HTTP/HTTPS 下载地址。其他类型提示不支持。
导入复用原来的流式下载、规则校验及入库流程，失败保留插件页面和导入地址，供用户重试。

### 7.3 界面与性能要求

- 页面应适配安全区、字体缩放、深浅色和窄屏。
- 长列表使用分页或虚拟化，每页建议不超过 100 项。
- 检索、解析、导入和导出必须异步执行，不要阻塞界面线程。
- 高频进度应合并更新；不要每 100 毫秒复制并重绘完整列表。
- 新增结果应追加或按稳定键局部更新，避免整表重载和封面重复请求。
- 大文件使用分块读取和写入，不要一次性装入页面内存。
- 删除、覆盖、清空等不可逆操作必须二次确认，并明确影响数量。
- 可复制文本应允许长按选择；敏感字段默认遮蔽。

### 7.4 独立 HTML 插件

本节的“独立 HTML 插件”仍是通过“设置 → 插件管理”导入的**插件包**，不是第 8 节通过“网页与订阅 → 网页”导入的独立 `.html`。纯界面扩展可使用 `sourceFormat: "fishreader-html"`。此时：

- `entryModule` 必须以 `.html` 或 `.htm` 结尾。
- `entrypoints` 必须且只能为 `["ui"]`。
- 顶层 `source` 是完整 UTF-8 HTML 文档。
- 不得再声明 `managementModule` 或附加 `modules`。

页面运行在沙箱中，不能使用直接网络连接、弹窗、顶层导航、原生文件 API 或平台私有对象。需要网络、存储、Cookie、摘要或解析时使用注入的 `FishReader` 桥接。纯界面插件不会参与统一检索、详情、目录或内容流程。

### 7.5 登录与状态检查

需要用户在网页中完成登录时，同时设置：

```json
{
  "loginUrl": "https://account.example.com/login",
  "entrypoints": ["search", "detail", "catalog", "content", "loginCheck"],
  "permissions": {
    "networkDomains": ["account.example.com", "api.example.com"],
    "cookieScope": true,
    "loginBrowser": true
  }
}
```

`loginUrl` 必须属于已声明域名。登录页只能由用户操作显式打开，插件不能静默启动浏览器。宿主只保存本次登录会话实际访问且已授权来源中的合规 Cookie，并继续检查 Domain、Path、Secure、期限和数量；未访问的授权域名不会仅因出现在清单中而被遍历或写入。

关闭登录页、点击完成或从浏览器返回只表示本次交互结束，不等于登录成功。可选的 `loginCheck({})` 返回 `{ loggedIn, message? }`，用于展示状态，不得在检查过程中执行购买、修改账号或其他有副作用的操作。插件仍应处理 Cookie 过期和服务端会话失效；“已保存 Cookie”也不等于“当前已登录”。验证码和外部身份验证必须保持用户可见并由用户操作。

## 8. 网页类插件开发（需在网页中导入）

本节描述鱼书鸿蒙版 0.6.0 的**普通 WebView 网页入口**。开发者交付独立 UTF-8 `.html` 文件，由用户在“网页与订阅 → 网页 → 添加网页 → 导入本地 HTML”中导入并打开；它不是 `.fishplugin.json`，不通过“设置 → 插件管理”安装，也不执行第 4、5 节的 `module.exports` 入口或 `reader` 主模块 API。前述 `fishreader-html` 则是另一种受限插件包，不能把两者的 `FishReader` 与网页桥接对象混用。

### 8.1 页面文件与图标

- 本地导入时宿主复制 HTML 到应用私有目录，当前文件大小上限为 8 MiB。修改原文件后须重新导入，不要假定已有网页快捷入口自动同步源文件。
- 需在“网页与订阅”中显示图标时，在原始 HTML 的 `<head>` 中静态写入带 `data:image/...` URL 的 `<link rel="icon">`。宿主导入时读取文件内容提取图标；运行后用 JS 动态创建的图标不会成为导入图标。嵌入图标当前上限为 5 MiB。
- 页面可自行请求网站图片、数据并渲染；访问受目标站点、WebView 与宿主网络能力约束，不能把插件包的 `networkDomains` 权限清单当作网页网络授权。适配窄屏、深浅色与返回导航，避免把授权信息写入 HTML。

### 8.2 HTTP 与存储桥接

在普通网页中检测 `window.FishPlayerWebVideo` 后使用其异步方法。请求头参数是 **JSON 字符串**，POST 正文也是字符串，不是直接传 JS 对象：

```js
const bridge = window.FishPlayerWebVideo;
if (!bridge?.httpGetTextAsync) {
  throw new Error('请从鱼书“网页与订阅 → 网页”入口打开此 HTML');
}
const headers = JSON.stringify({ Accept: 'application/json' });
const pageText = await bridge.httpGetTextAsync('https://example.com/list', headers);
const resultText = await bridge.httpPostAsync(
  'https://example.com/detail', JSON.stringify({ id: '123' }), headers
);
const value = await bridge.getStorageAsync('example.key');
bridge.setStorage('example.key', value || 'ready');
```

用户从“网页与订阅 → 网页”导入并保存的页面还可直接使用标准 DOM `localStorage`：

```js
const state = JSON.parse(localStorage.getItem('viewing-state') || '{}');
localStorage.setItem('viewing-state', JSON.stringify({
  episodeId: 'episode-12',
  positionMs: 135000,
  updatedAt: Date.now()
}));
```

此存储由宿主在页面脚本执行前挂载，仅作用于顶层已保存网页。数据同时按“网页条目 ID + 当前页面 Origin”隔离；HTTP(S) 页面使用 `scheme://host[:port]`，本地导入文件使用 `file://`。单个网页条目的全部 Origin 合计上限为 8 MiB，只接受字符串键值，行为与标准 `Storage` 的 `getItem`、`setItem`、`removeItem`、`clear`、`key` 和 `length` 一致。删除网页会撤销已打开页面的存储能力并清除该条目数据，不会清理共享 WebStorage、Cookie 或其他网页数据。读取或保存失败时会抛出 DOM 异常；页面必须捕获并提示用户重新打开，不能改用其他网页的命名空间。

普通浏览器、浏览器入口、旧版宿主以及 `fishreader-html` 管理页不保证提供上述隔离层。需要在外部浏览器运行时应做 `localStorage` 可用性检测；不要直接调用内部的 `loadWebsiteStorage` / `saveWebsiteStorage` 桥接方法。

常用方法：

| 方法 | 返回与用途 |
| --- | --- |
| `httpGetAsync(url, headersJson)` | 异步 GET 文本；可能将二进制响应变为空字符串，文本请求优先使用 `httpGetTextAsync`。 |
| `httpGetTextAsync(url, headersJson, responseMode?)` | 异步 GET 文本。 |
| `httpPostAsync(url, bodyString, headersJson, responseMode?)` | 异步 POST 文本。 |
| `httpGetBinaryAsync(url, headersJson, maxBytes?)` | 异步 GET 二进制，返回 Base64 字符串。 |
| `getStorageAsync(key)` / `setStorage(key, stringValue)` | 网页私有字符串存储；存入对象时自行 `JSON.stringify`。 |

`responseMode` 和 `maxBytes` 是鸿蒙网页桥接的可选参数。`httpPostAsync(..., 'text')` 可将响应字节按 UTF-8 文本读取；`'stream'` 使用流式接收，当前有 4 MiB 上限。零长度响应或解析失败应显示明确错误，不要把 HTTP 200 或空字符串当作成功数据。桥接不承诺返回服务器原始状态码与全部响应头；需要这些字段时不能从兼容层的默认值推断。所有调用应捕获异常并提供重试状态，避免在 UI 中暴露 Cookie、密钥或完整私有响应。

### 8.3 网页视频播放桥接

播放请使用 `window.fishreaderwebviewvideo.play(payloadString)`；`window.fishplayerwebviewvideo.play` 仅为兼容别名。`FishPlayerWebVideo` 主要承载网页 HTTP/存储能力，不应把它与推荐的视频命名空间混淆。`payloadString` 可以是一个实际可播放的 HTTP(S) 媒体 URL，也可以是 `JSON.stringify(request)`；不能直接传对象或尚未解析的剧集 ID：

```js
const player = window.fishreaderwebviewvideo;
if (!player?.play) throw new Error('当前页面没有鱼书视频桥接');
const capabilities = typeof player.capabilities === 'function'
  ? JSON.parse(player.capabilities()) : {};
const inline = capabilities.inlineEpisodeRequest === true &&
  typeof player.respondEpisode === 'function';

window.addEventListener('fishreaderwebviewvideo:episode-request', async event => {
  if (!inline) return;
  const detail = event.detail;
  try {
    // purpose === 'prefetch' 时只返回地址，不更新观看记录或页面导航。
    const media = await resolveEpisode(detail.episodeId);
    player.respondEpisode(JSON.stringify({
      sessionId: detail.sessionId,
      requestId: detail.requestId,
      url: media.url,
      headers: media.headers || {},
      mediaOptions: media.mediaOptions || {}
    }));
  } catch (error) {
    player.respondEpisode(JSON.stringify({
      sessionId: detail.sessionId,
      requestId: detail.requestId,
      error: String(error?.message || error)
    }));
  }
});

player.play(JSON.stringify({
  version: 1,
  url: 'https://media.example.com/1.mp4',
  title: '第1集',
  seriesTitle: '示例短剧',
  currentSeasonId: 'season-1',
  currentEpisodeId: 'episode-1',
  seasons: [{
    id: 'season-1',
    episodes: [
      { id: 'episode-1', title: '第1集', url: 'https://media.example.com/1.mp4' },
      { id: 'episode-2', title: '第2集', url: inline ? '' : 'https://media.example.com/2.mp4' }
    ]
  }],
  episodeRequestEvent: inline ? 'fishreaderwebviewvideo:episode-request' : '',
  prefetchNextSeconds: inline ? 30 : 0,
  progressEvent: 'fishreaderwebviewvideo:progress',
  progressKey: 'series-1',
  progressIntervalSeconds: 10,
  startPositionMs: 120000,
  refreshEvent: 'fishreaderwebviewvideo:refresh'
}));
```

选集数组应包含用户实际可以选择的集。默认模式下每集的 `url` 都必须是已解析的可播放 HTTP(S) 地址；只有 ID、网页详情链接或仅前三集的预览地址，不能充当完整播放列表。鸿蒙网页若检测到 `JSON.parse(player.capabilities()).inlineEpisodeRequest === true` 且存在 `respondEpisode`，可选传 `episodeRequestEvent`：起播仍要为当前集提供顶层 URL，其余集保留 ID/标题且 URL 留空；切集时播放器保持打开并派发目标集事件，由网页解析该集地址、选轨后通过 `respondEpisode` 回传本次请求的 URL、请求头和媒体参数。应答必须原样带回本次 `sessionId` 与 `requestId`，30 秒未应答视为超时。不支持该能力的旧宿主必须继续使用全量 URL 模式。

`prefetchNextSeconds` 只在启用 `episodeRequestEvent` 后有效；预取事件带 `purpose: 'prefetch'`，实际切集带 `purpose: 'switch'`。预取不得更新观看记录、改变页面导航或再次调用 `play`。`progressEvent`/`progressKey` 用于回传进度，`progressIntervalSeconds` 可选择播放期间的回传间隔，事件包含 `updatedAt` 与会话内递增的 `sequence`，页面应据此丢弃重复或乱序结果。`startPositionMs` 仅用于本次初始集断点，切换其他集不会继承。`refreshEvent` 让播放器请求网页重新解析当前集地址，网页收到后自行再次调用 `play`。媒体请求头可通过全局或单集 `headers` 传递；`mediaOptions` 支持 `encryptionMethod`、`decryptionKeyHex`、`keyIdHex`、`ivHex` / `defaultIvHex`，只传宿主明确支持且业务确需的字段。

完整字段、事件载荷、预取行为和诊断说明见[网页视频播放器桥接协议](../web-video-bridge.md)。能打开播放器不代表媒体格式、编码、密钥与所有选集都已在设备上验证通过。

### 8.4 兼容与验证

网页应对每个桥接方法做能力检测；普通外部浏览器、旧版鱼书、插件包管理页不一定注入同一对象。网页请求的 Cookie、UA、Referer 和平台网络行为可能与 PC 浏览器不同，应分别验证。发布前从“网页与订阅 → 网页”重新导入最终 HTML，在真实设备检查首页、图片、详情、选集数量、首集与后续集播放、返回导航和失败重试。仅静态检查、PC 播放成功或打开黑色播放页，不能代替设备实际播放验收。

## 9. 性能与可靠性

### 9.1 避免 N+1 请求

列表入口只返回展示所需摘要。除非用户打开详情，否则不要逐项请求详情、目录或正文。章节数量等信息只应使用列表响应已有字段；没有信息就留空，由宿主显示缺省状态。

### 9.2 分页与稳定排序

- `page` 从 `1` 开始。
- 同一页内使用确定性顺序。
- 后续页不要重复前页条目；确需去重时以稳定键为准。
- 网络内容变化时，尽量避免同一会话中顺序剧烈跳动。
- 增量检索需要重新排序时，应按稳定的相关度规则排序，并保留唯一键以便宿主局部更新。

### 9.3 错误处理

插件应抛出简短、可操作且不含敏感数据的错误：

```js
throw new Error("服务暂时不可用，请稍后重试");
```

不要在错误、日志或返回值中包含 Cookie、授权头、令牌、账号、设备标识或完整私有响应。对于可恢复的网络错误，可以在合理次数内退避重试；不要无限循环。

宿主可能返回以下错误类别：请求不合法、插件不存在、入口不存在、权限拒绝、编译失败、运行失败、超时、输出超限、工作线程异常和宿主错误。插件界面不应依赖错误文案的精确文本。

### 9.4 资源限制

| 项目 | 当前上限 |
| --- | --- |
| 单次执行请求 JSON | 1 MiB |
| 单次执行结果 JSON | 8 MiB |
| 单次 HTTP 响应 | 16 MiB |
| 执行硬超时 | 120 秒 |
| 单次摘要列表 | 500 项 |
| 单次批量 HTTP | 2,048 项排队、最多 32 并发，响应正文合计 16 MiB |
| 单次 HTML 解析 | 16 MiB 输入、50,000 个结果、32,768 字符选择器 |
| 批量 HTML 解析 | 5,000 个请求，输入合计 16 MiB |
| 批量解析结果 | 500 个目标结果项 |
| 动态分类 | 128 项 |
| 静态分类 | 64 项 |
| 单次目录 | 20,000 项 |
| TTS 声音 | 256 项 |
| 单次 TTS 音频 | 20 MiB |

插件应远低于这些上限运行。达到上限通常意味着需要分页、分块或缩减返回字段。

## 10. 安全与隐私

- 只申请完成主要功能所需的权限和域名。
- 不采集与功能无关的账号、设备、位置或行为数据。
- 不在插件包、日志或错误中硬编码密钥、令牌和真实账号。
- 不将私有 Cookie、配置或数据库内容上传给未声明的第三方。
- 不动态下载并执行新的 JavaScript、HTML 或原生代码。
- 不使用混淆隐藏网络目标、权限用途或数据流向。
- 不绕过宿主的域名、跳转、大小、超时和隔离检查。
- 对用户导入的数据进行类型、数量、长度和编码校验。
- 显示外部内容时进行转义，避免把不可信文本拼入 HTML。
- 发现安全问题时，应先停止分发受影响版本并发布修复说明。

## 11. 完整最小示例

下面的示例使用静态数据展示接口形状，可直接保存为 `example.fishplugin.json` 后用于结构验证：

```json
{
  "schemaVersion": 1,
  "manifest": {
    "schemaVersion": 1,
    "pluginId": "org.example.static-catalog",
    "name": "静态示例插件",
    "version": "0.1.0",
    "sdkVersion": "1.0",
    "sourceFormat": "fishreader-js",
    "entryModule": "index.js",
    "entrypoints": ["search", "detail", "catalog", "content"],
    "permissions": {
      "networkDomains": [],
      "redirectDomains": [],
      "cookieScope": false,
      "pluginStorage": true,
      "pluginDatabase": false,
      "standardCrypto": false,
      "htmlParse": false,
      "webViewAutomation": false,
      "loginBrowser": false
    }
  },
  "source": "const item = { bookKey: 'demo:item:1', title: '示例内容', author: 'Example', intro: '用于验证公开接口', bookUrl: 'https://example.invalid/items/1' };\nmodule.exports.search = async ({ keyword, page }) => page === 1 && item.title.includes(String(keyword || '')) ? [item] : [];\nmodule.exports.detail = async ({ bookKey }) => ({ ...item, bookKey, tocUrl: 'https://example.invalid/items/1/chapters' });\nmodule.exports.catalog = async () => [{ chapterKey: 'demo:item:1:chapter:1', title: '第一章', ordinal: 0, chapterUrl: 'https://example.invalid/chapters/1' }];\nmodule.exports.content = async () => ({ contentType: 'text', content: '这是示例正文。', baseUrl: 'https://example.invalid/chapters/1' });"
}
```

注意：示例使用 `.invalid` 保留域名，不会产生真实网络请求。

## 12. 测试建议

发布前至少完成以下验证：

1. 插件包可以被 JSON 解析，编码为 UTF-8，且未超过大小限制。
2. 声明信息通过 [插件声明信息 Schema](../../schemas/plugin/source-plugin-manifest.schema.json) 校验。
3. 当前 `pluginKinds` 对应的必需入口在全新安装状态下均能完成一次正常调用。
4. 无结果、缺少可选字段、空目录、锁定章节和非文本内容能正确处理。
5. 分页无明显重复，稳定键在多次调用中保持一致。
6. 未授权域名、越权桥接、跨域跳转和超限响应会被拒绝。
7. Cookie、键值、数据库和实例变量不会跨插件泄漏。
8. 网络超时、非 2xx 状态、乱码、空响应和结构变化有清晰提示。
9. 管理页面在窄屏、字体放大、长列表和大文件下仍可操作。
10. 日志与错误中不含账号、Cookie、令牌、授权头和私有正文。
11. 升级前后的数据迁移可重复执行，失败时不会破坏旧数据。
12. 在每个声明支持的平台上进行真实安装和交互测试；仅构建成功不能视为运行验证通过。
13. 多目标插件验证拆分检索的准备、HTTP、解析三段可以交错运行，停止后不会继续大量回调。
14. 字典 HTML 已通过宿主净化；TTS 的跳转、大小、缓存与失败重试均由宿主验证。
15. 后台检索离开页面后仍可完成；停止任务后在途结果不会再次写入界面或持久化。
16. 有声内容验证单段、多段、请求头和音色选择；文字 TTS 单独验证，二者不互相代替。
17. `forceRefresh` 能重新获取详情和目录，并在服务端新增章节时返回新的稳定目录。
18. `host-file-v1` 验证普通刷新、换源候选提交、数据库失败回退、按需读取和删除书籍清理；旧 Preferences 只删除数据库未引用的代际。
19. 管理页面的大文件句柄能在成功、取消和异常路径正确关闭；异步校验按单项进度更新，离页后不再刷新已销毁页面。
20. 登录流程分别验证成功、取消、跨已授权子域跳转、Cookie 过期和 `loginCheck` 失败，不以关闭页面作为成功条件。
21. 私有数据库超过 500 条时按稳定顺序分页读取，并验证最后一页、空页及总数恰为 500 的边界。
22. 独立 HTML 验证隔离 `localStorage` 的重启持久化、Origin 隔离、配额错误与删除撤销；敏感值不进入普通存储。
23. 网页播放器验证能力探测、旧宿主全量 URL 回退、按集取链成功/失败/超时、预取不修改记录、实时进度乱序过滤、断点和刷新取链。

仓库中的契约测试和 JSON Schema 可作为自动化校验基础。公开接口测试应覆盖正常值、边界值、非法字段、超长字段和权限拒绝。

## 13. 发布检查表

- [ ] `pluginId` 唯一、稳定，且不含临时版本信息。
- [ ] 插件版本使用 SemVer，更新说明与实际变化一致。
- [ ] 只声明已实现的入口。
- [ ] 只申请实际需要的域名和能力。
- [ ] 名称、描述和权限用途清晰，不误导用户。
- [ ] 不包含真实账号、令牌、私钥、Cookie、调试地址或本机路径。
- [ ] 不动态执行未随包审核的代码。
- [ ] 列表、目录和正文返回符合 Schema 与数量限制。
- [ ] 多目标检索没有固定整批等待、无界并发或在界面线程执行解析的假设。
- [ ] 字典、TTS、图片变换或受控动作能力已分别通过对应结果 Schema。
- [ ] 有声内容与文字 TTS 使用独立入口和结果结构；可选音色来自 `toneOptions`。
- [ ] 后台检索不依赖页面对象，停止后能安全丢弃在途结果。
- [ ] 使用可选或平台相关的宿主能力时已做方法检测、基础回退或明确的不支持提示，并写明平台范围。
- [ ] 使用发现筛选扩展时，已验证旧宿主兼容和真实页面交互。
- [ ] 独立 HTML 已从“网页与订阅 → 网页”入口重新导入，并验证图标、网络、选集和实际播放；未把网页与插件包桥接混用。
- [ ] 独立 HTML 只使用标准 `localStorage`，没有依赖内部存储桥接；删除网页后的旧页面不能继续写入。
- [ ] 播放器新增能力经 `capabilities()` 检测后再使用；旧宿主仍提供每集真实 URL。
- [ ] 按集取链应答核对 `sessionId` / `requestId`，预取不改变观看记录，进度事件按 `sequence` 去重。
- [ ] 声明 `host-file-v1` 时使用宿主 `cacheBookId`，候选目录先于数据库提交，且未把完整目录重复写入 Preferences。
- [ ] 错误信息可理解且不泄露敏感数据。
- [ ] 管理页面具备加载、空状态、失败、重试和确认状态。
- [ ] 升级迁移和回退策略已经验证。
- [ ] 已记录支持的平台、必要账号条件和已知限制。
- [ ] 已确认内容授权、服务条款和隐私要求。

## 14. 兼容性与版本策略

- 文档版本 `0.6.0` 对应鱼书鸿蒙版应用版本，不等于插件自身版本。
- 插件包结构由 `schemaVersion` 控制；当前为 `1`。
- 公共 API 兼容范围由 `sdkVersion` 控制。
- 插件自身发布版本由 `manifest.version` 控制，并遵循 SemVer。
- 同一 SDK 主版本内，宿主可增加可选字段和能力；插件必须忽略自己不需要的新增输入字段。
- 宿主仍会拒绝插件输出中的未知字段，因此输出必须严格遵守目标应用随附的 Schema。
- 依赖平台相关能力时，必须在说明中列出支持范围，并提供降级或明确提示。
- HarmonyOS API 23+ 使用系统 JSVM 隔离执行；Android 优先使用 JavaScriptSandbox，并在旧系统使用受限兼容运行时；Docker/Web 使用隔离子进程。引擎差异不是公开 API，插件不能据此访问 Node、ArkTS、Java 或原生全局对象。

本指南 `0.6.0` 的 2026-09-27 更新补充独立网页持久化存储、播放器内按集取链、预取、播放中进度、断点和刷新取链；Ver0.5.8 的发现筛选、环境信息和独立网页导入说明继续适用。原 0.5.0 的格式、分页、网络槽位及结果约束继续适用。插件包协议主版本未变化。

## 15. 规范引用

- [插件包格式](package-format.md)
- [结果契约](result-contracts.md)
- [插件声明信息 Schema](../../schemas/plugin/source-plugin-manifest.schema.json)
- [检索结果 Schema](../../schemas/plugin/search-result.schema.json)
- [详情结果 Schema](../../schemas/plugin/detail-result.schema.json)
- [目录结果 Schema](../../schemas/plugin/catalog-result.schema.json)
- [内容结果 Schema](../../schemas/plugin/content-result.schema.json)
- [执行请求 Schema](../../schemas/plugin/execution-request.schema.json)
- [执行结果 Schema](../../schemas/plugin/execution-result.schema.json)
- [字典结果 Schema](../../schemas/plugin/dictionary-result.schema.json)
- [TTS 声音清单 Schema](../../schemas/plugin/tts-voices-result.schema.json)
- [TTS 合成请求 Schema](../../schemas/plugin/tts-synthesis-result.schema.json)
- [图片变换结果 Schema](../../schemas/plugin/image-result.schema.json)
- [受控动作结果 Schema](../../schemas/plugin/action-result.schema.json)
- [发现筛选契约](discover-filters.md)
- [网页视频桥接](../web-video-bridge.md)
