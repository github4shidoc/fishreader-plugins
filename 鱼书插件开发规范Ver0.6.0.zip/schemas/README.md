# Schema 使用说明

这里的 Schema 覆盖本开发包公开的内容、字典、TTS 与网页播放契约，不包含尚未完成的主题插件。主规范版本为 0.6.0；部分 Schema 沿用已验证的 0.5.1 公开契约。

- `plugin/plugin-package.schema.json`：插件包顶层结构。
- `common.schema.json`：各 Schema 共用的基础定义。
- `plugin/source-plugin-manifest.schema.json`：Manifest。
- `plugin/*-result.schema.json`：各入口返回值。
- `plugin/image-result.schema.json`：图片变换返回值。
- `plugin/action-result.schema.json`：受控交互动作返回值。
- `plugin/execution-request.schema.json`：宿主执行入口时的请求。
- `plugin/execution-result.schema.json`：统一执行结果外壳。
- `plugin/host-call.schema.json`：宿主桥接调用结构。
- `plugin/web-video-playback-request.schema.json`：网页调用系统视频播放器的结构化请求。

Schema 用于编辑器提示、CI 和静态校验；业务上还要遵守 `docs/` 中的跨入口约束，例如 `bookKey`、`chapterKey` 稳定性和媒体类型一致性。

0.5.1 增加章节 `locator` 对象及执行入口 `image`、`payAction`、`callback`。JSON Schema 不能直接表达序列化后的 UTF-8 字节上限，`locator` 的 256 KiB 限制仍须运行时检查。示例回归会验证顶层字段和此边界。

0.6.0 保留 `webPageActions`、`urlSchemes` 和登录声明约束；网页视频请求增加按集取链、预取、实时进度、断点、刷新事件，以及 `mediaOptions.ivHex/defaultIvHex`。未启用按集取链时，每集仍必须有真实 HTTP(S) URL；Schema 允许省略或留空 URL 仅用于能力探测成功后的动态模式，不能替代运行时检查。主题入口仍不公开。章节 `locator` 字段已按鸿蒙运行时校验逻辑保留在本包的 `source-result.schema.json` 中。

`tools/validate-package.mjs` 是零依赖包结构校验，不是完整 JSON Schema 引擎。需要通用 Schema 校验时使用支持 Draft 2020-12 的工具，并加载本目录的引用文件。

若本包 Schema、应用内 Schema 与实际公开运行时校验出现差异，应记录具体版本与字段并核对宿主实现；不要根据单条错误信息擅自放宽权限、长度或身份约束。
