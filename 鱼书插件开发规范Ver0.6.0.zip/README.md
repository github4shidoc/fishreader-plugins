# 鱼书插件开发规范 Ver0.6.0（鸿蒙版）

对应应用版本：鱼书鸿蒙版 0.6.0  
插件协议：`schemaVersion: 1`  
建议 SDK：`1.0`  
发布日期：2026-09-27

**主规范是 [`docs/plugins/development-guide.md`](docs/plugins/development-guide.md)。** 本包在 Ver0.5.8 完整开发包基础上，按鱼书鸿蒙版 0.6.0 当前公开实现补齐 HTML 网页存储与视频桥接，并同步更新类型声明、Schema、示例和验证工具。未发生契约变化的教程和模板保持原实现；与主规范不一致时以主规范及本包 Schema 为准。主题插件尚未完成，不纳入本包。

这是一套可以脱离鱼书代码使用的插件开发包。当前公开并建议第三方开发的能力为：

- 内容插件：搜索、发现、详情、目录、正文，以及文字、漫画、有声书和视频内容。
- 字典插件：在阅读页查询选中文字。
- TTS 插件：把阅读页的文字合成为音频。
- `fishreader-html` 插件包：通过插件管理导入，提供使用 `FishReader` 桥接的受限交互页面。
- 网页类插件：通过“网页与订阅 → 网页”导入独立 HTML，使用 `FishPlayerWebVideo` 与 `fishreaderwebviewvideo` 桥接。

主题插件功能尚未完成，本开发包不包含主题规范、模板或主题结果 Schema。声明信息里出现的未公开入口属于宿主保留值，不代表可供第三方稳定使用。

## 0.6.0 更新重点

- 用户导入的网页获得按网页条目和页面 Origin 隔离的持久化 `localStorage`；删除网页时只清除该条目数据，不清理共享 Cookie 或其他网页数据。
- 网页播放器新增 `capabilities()` 能力探测与 `respondEpisode()` 按集取链回应，可在播放器不退出的情况下完成切集。
- 新增选集预取、播放中进度事件、初始断点、播放地址刷新事件；调用方仍负责取链、记录和片首尾持久化。
- 更新 `mediaOptions`、网页播放 Schema、TypeScript 声明和独立 HTML 示例；插件协议仍为 `schemaVersion: 1`，建议 SDK 仍为 `1.0`。
- 保留 Ver0.5.8 的发现筛选、环境信息、网页导入和完整开发包内容；主题能力暂不公开。

## 0.5.1 起保留的契约重点

- 新增目录 `locator` 契约：跨调用上下文通过 `content.input.chapter` 恢复，不能依赖同一个 JS 实例。
- 补齐目录文件事务参数、提交与失败清理，明确每块字节限制和普通插件的选择。
- 区分数据库 500 行分页、校验单次 2,048 项与搜索目标总量，提供 2,232 项离线批次测试。
- 明确 JS 隔离运行环境不保证浏览器全局对象；编码使用 `reader.text`，网页执行读取响应的 `body`。
- 增加独立回归配方、冷启动示例与执行请求 Schema 的图片/动作入口检查。

- 插件协议仍是 `schemaVersion: 1`，公开 SDK 仍是 `1.0`；不要因为开发规范版本变化而修改这两个值。
- `sourceFormat` 只能使用宿主公开枚举；JS 插件通常使用 `fishreader-js`。自定义字符串会在导入阶段被拒绝。
- JS 插件只要声明 `managementModule`，就必须同时声明 `ui`，并在 `modules` 中提供同名 HTML；三者缺一不可。
- 包内 `entryModule`、`managementModule` 和 `modules` 键统一使用 `/` 分隔的相对路径，不允许绝对路径、反斜杠或 `..`。
- 私有存储可能包含旧版本、备份或跨平台迁移留下的字符串、数字、布尔值、数组或对象；读取后先判断类型，不能无条件 `JSON.parse`。
- 多目标内容插件必须把稳定的 `sourceKey` 贯穿搜索、发现、详情、目录和正文；`bookKey`、`chapterKey` 也必须能在冷启动后重新定位数据。
- 拆分批量搜索由宿主维护 HTTP 槽位；请求完成一个就补入一个。插件不要自行切固定批次等待，也不要在列表阶段提前去重。
- 数据库单次查询 `maximumRows` 必须是 `1..500` 的整数；更多记录必须稳定排序后分页读取。
- 多目标清单可返回 `homeUrl`、`iconUrl` 和 `metadataDeferred`；不要为了补图标或主页信息阻塞首次列表显示。
- 漫画、有声书和视频必须使用 `mediaType` 与对应媒体结果；不要依赖标题或分类文字猜测阅读器。
- 网页调用优先使用 Promise 方法；视频桥接支持标题、季集、请求头和片首尾回传，调用前必须做能力检测。
- 校验工具检查公开枚举、管理页绑定规则和数据库行数边界；不替代手机实际导入与播放验证。

## 第一次开发

1. 安装 Node.js 18 或更高版本。
2. 复制 `examples/source-basic`，修改 `manifest.json` 和 `index.js`。
3. 在示例目录执行：

   ```bash
   node build.mjs
   node smoke-test.mjs
   ```

4. 在鱼书中打开“设置 → 插件管理”，导入生成的 `*.fishplugin.json`，启用后测试。
5. 发布前在开发包根目录执行：

   ```bash
   node tools/validate-package.mjs 路径/你的插件.fishplugin.json
   ```

开发包自身可用以下命令完整自检：

```bash
node tools/verify-guide.mjs
```

完整流程见 `docs/01-从零开始.md`。

## 目录

```text
README.md                         本文件
CHANGELOG.md                      本版规范变化
docs/
  01-从零开始.md                 创建、构建、导入第一个插件
  02-插件包与声明信息.md          包格式、Manifest、升级语义
  03-内容插件.md                  搜索到正文的完整数据链路
  04-宿主API.md                   reader.* 能力参考
  05-管理页面与登录.md            FishReader 桥接、文件导入导出、登录
  06-字典与TTS插件.md             两类独立能力
  07-安全性能与兼容.md            权限、限额、后台任务和跨平台要求
  08-测试打包与发布.md            本地检查和发布清单
  09-常见错误.md                 错误定位方法
  10-网页接口.md                 网页入口、桥接与播放说明
  11-目录上下文与批量任务.md       冷启动、目录事务、分页与批次边界
  plugins/development-guide.md     0.6.0 主规范，包含网页类插件导入章节
  plugins/discover-filters.md      发现筛选可选扩展
  plugins/package-format.md        插件包格式
  plugins/result-contracts.md      结果契约
  web-video-bridge.md             网页视频桥接完整字段
examples/
  source-basic/                   无网络、可直接导入的最小内容插件
  source-network/                 网络与 HTML 解析模板
  dictionary-basic/               字典模板
  tts-basic/                      TTS 模板
  web-basic/                      插件管理中导入的 HTML 插件包模板
  web-import-basic/               在“网页与订阅”导入的独立 HTML 模板
  contract-recipes/               可执行的分页、批次和冷启动回归配方
  plugin-development/basic/         主规范引用的最小内容插件
plugins/
  dictionary-example/              主规范引用的字典示例
  tts-template/                     主规范引用的 TTS 示例
schemas/                          当前公开契约的 JSON Schema
types/fishreader-plugin.d.ts      编辑器类型提示
tools/build-plugin.mjs            通用打包工具
tools/validate-package.mjs        零依赖静态校验工具
tools/verify-guide.mjs            开发包示例与契约自检
dist/                             已构建的示例插件
```

## 重要边界

- 插件运行在隔离环境中，不能直接访问系统文件、进程、套接字、原生对象或页面组件。
- 网络、Cookie、存储、数据库、HTML 解析、加密和私有文件必须通过宿主 API。
- 仅能访问 Manifest 声明并由用户授权的域名；重定向目标也会重新校验。
- 插件输入输出必须是可 JSON 序列化的普通值，不能返回 DOM、函数、自定义类实例或循环引用。
- 插件不得绕过登录、付费、访问控制、反自动化措施或目标服务条款。
- `pluginId` 是升级身份。发布后改显示名可以，改 `pluginId` 会被视为另一个插件。
- 包内模块路径和插件私有文件路径都必须相对化；二者不是系统文件路径。
- TTS 和有声书是两套能力：TTS 合成文字；有声书由内容插件 `content` 返回音频地址。

文档、Schema 和目标鱼书版本有冲突时，以随目标应用发布的 Schema 和该版本实际公开接口为准。
