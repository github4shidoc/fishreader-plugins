# 独立 HTML 网页导入示例

本示例面向鱼书鸿蒙版 0.6.0 的“网页与订阅 → 网页 → 添加网页 → 导入本地 HTML”。导入 `index.html`，**不要**从插件管理页导入，也不要把它包装成 `.fishplugin.json`。示例使用按网页条目及 Origin 隔离的 `localStorage` 保存播放地址与位置，并在调用可选进度/断点能力前读取 `capabilities()`。

示例展示静态内嵌图标、`FishPlayerWebVideo.httpGetTextAsync` 文本请求、网页私有字符串存储及 `fishreaderwebviewvideo.play`。所有请求和播放都由用户输入地址并点击按钮触发；不提供内置第三方接口或媒体链接。文本接口、媒体格式和授权由使用者自行确认。修改 HTML 后需重新导入。

本地可运行 `node smoke-test.mjs` 检查结构和 JavaScript 语法；这不是鱼书设备上的播放验证。接口细节见 `../../docs/plugins/development-guide.md` 第 8 节。
