import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/i)?.[1];
if (!script) throw new Error('缺少内联脚本');
new vm.Script(script);
for (const required of [
  '<link rel="icon" href="data:image/',
  'FishPlayerWebVideo',
  'httpGetTextAsync',
  'fishreaderwebviewvideo',
  'player.play(JSON.stringify(',
  'localStorage.setItem(',
  'player.capabilities?.()',
  'progressIntervalSeconds',
  'startPositionMs'
]) {
  if (!html.includes(required)) throw new Error(`缺少 ${required}`);
}
if (html.length > 8 * 1024 * 1024) throw new Error('HTML 超过导入上限');
console.log('web-import-basic smoke test: OK');
