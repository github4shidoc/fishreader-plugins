# 最小内容插件示例

这是一个不访问网络的完整内容插件闭环，适合先验证包结构和四个必需入口。

0.1.1 示例最初面向鱼书 0.5.1；其 `locator` 目录上下文契约已按鸿蒙版 0.6.0 运行时复核。示例包含两章，正文从 `input.chapter.id` 恢复上下文；冒烟测试在新的 JS 实例中读取第一章和第二章，验证冷启动不依赖模块内可变缓存。

```bash
node build.mjs
node smoke-test.mjs
```

生成 `fishreader-quickstart.fishplugin.json`，可直接导入鱼书。开发自己的插件时先修改 `pluginId`、名称和版本，再替换固定数据。
