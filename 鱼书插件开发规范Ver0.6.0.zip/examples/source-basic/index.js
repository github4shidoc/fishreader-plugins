'use strict';

const ITEM_KEY = 'org.example.fishreader.quickstart:item:1';
const TEXTS = {
  first: '如果你能看到这段文字，说明插件的检索、详情、目录和正文入口已经连通。',
  second: '这是第二章。它通过目录保留的定位对象读取，不依赖上一次执行的变量。'
};

module.exports.search = async function ({ page }) {
  if (page !== 1) return [];
  return [{
    bookKey: ITEM_KEY,
    title: '示例内容',
    author: '示例作者',
    intro: '用于验证插件安装和四个必需入口。',
    latestChapter: '第二章',
    mediaType: 'text'
  }];
};

module.exports.detail = async function ({ bookKey }) {
  return {
    bookKey: bookKey || ITEM_KEY,
    title: '示例内容',
    author: '示例作者',
    intro: '这是一个不访问网络的最小可运行示例。',
    mediaType: 'text',
    chapterCount: 2
  };
};

module.exports.catalog = async function () {
  return ['first', 'second'].map((id, ordinal) => ({
    chapterKey: ITEM_KEY + ':chapter:' + id,
    title: ordinal === 0 ? '第一章' : '第二章',
    ordinal,
    locator: { id },
    isVolume: false,
    isLocked: false,
    mediaType: 'text'
  }));
};

module.exports.content = async function (input) {
  const id = input.chapter && input.chapter.id;
  if (id !== 'first' && id !== 'second') throw new Error('章节上下文缺失，请更新目录');
  return {
    contentType: 'text',
    content: TEXTS[id]
  };
};
