import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const packageUrl = new URL('fishreader-quickstart.fishplugin.json', import.meta.url);
const bytes = fs.readFileSync(packageUrl);
const pluginPackage = JSON.parse(bytes.toString('utf8'));
assert.equal(pluginPackage.source, fs.readFileSync(new URL('index.js', import.meta.url), 'utf8'));
assert.equal(pluginPackage.manifest.version,
  JSON.parse(fs.readFileSync(new URL('manifest.json', import.meta.url), 'utf8')).version);

assert.ok(bytes.length > 0 && bytes.length <= 5 * 1024 * 1024);
assert.equal(pluginPackage.schemaVersion, 1);
assert.equal(pluginPackage.manifest.schemaVersion, 1);

function freshApi() {
  const moduleObject = { exports: {} };
  vm.runInNewContext(pluginPackage.source, {
    module: moduleObject, exports: moduleObject.exports
  }, { timeout: 5_000 });
  return moduleObject.exports;
}
const api = freshApi();
for (const name of ['search', 'detail', 'catalog', 'content']) {
  assert.equal(typeof api[name], 'function', `${name} must be a function`);
}

const summaries = await api.search({ keyword: '示例', page: 1 });
assert.ok(Array.isArray(summaries) && summaries.length === 1);
assert.equal(typeof summaries[0].bookKey, 'string');
assert.equal(typeof summaries[0].title, 'string');

const detail = await api.detail({ bookKey: summaries[0].bookKey, bookUrl: '' });
assert.equal(detail.bookKey, summaries[0].bookKey);
assert.equal(typeof detail.title, 'string');

const chapters = await api.catalog({
  bookKey: detail.bookKey,
  bookUrl: detail.bookUrl || '',
  tocUrl: detail.tocUrl || ''
});
assert.ok(Array.isArray(chapters) && chapters.length === 2);
assert.equal(chapters[0].ordinal, 0);

const content = await freshApi().content({
  bookKey: detail.bookKey,
  chapterKey: chapters[0].chapterKey,
  chapterUrl: chapters[0].chapterUrl || '',
  chapter: JSON.parse(JSON.stringify(chapters[0].locator))
});
assert.equal(content.contentType, 'text');
assert.ok(typeof content.content === 'string' && content.content.length > 0);
const second = await freshApi().content({
  bookKey: detail.bookKey,
  chapterKey: chapters[1].chapterKey,
  chapter: JSON.parse(JSON.stringify(chapters[1].locator))
});
assert.match(second.content, /第二章/);
assert.notEqual(second.content, content.content);
await assert.rejects(freshApi().content({ chapterKey: chapters[1].chapterKey }), /上下文/);

console.log('Quickstart plugin smoke test: OK');
