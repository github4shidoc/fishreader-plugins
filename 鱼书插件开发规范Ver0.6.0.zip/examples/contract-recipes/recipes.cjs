'use strict';

// 示例 schema: items(id INTEGER PRIMARY KEY, item_key TEXT NOT NULL).
// 在任务期间保持集合不变。每次只持有一页，不收集全部正文或大对象。
async function readItemPages(database, consume) {
  let afterId = 0;
  while (true) {
    const result = await database.query({
      sql: 'SELECT id, item_key FROM items WHERE id > ? ORDER BY id LIMIT 500',
      bindArgs: [afterId], maximumRows: 500
    });
    if (!result || !Array.isArray(result.rows)) throw new Error('无效查询响应');
    const rows = result.rows;
    if (rows.length === 0) return;
    for (const row of rows) {
      if (!Number.isSafeInteger(row.id) || row.id <= afterId) {
        throw new Error('分页游标未前进');
      }
      afterId = row.id;
    }
    await consume(rows);
    // 不把 truncated:false 当作没有下一页：SQL 的 LIMIT 本身也限制行数。
    if (rows.length < 500) return;
  }
}

// 仅管理页调用。退出检查不会取消已提交的宿主任务。
async function validateInBatches(api, keys, options) {
  const { isActive, onProgress, onRows, sleep } = options;
  const batchSize = options.batchSize === undefined ? 256 : options.batchSize;
  if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > 2048) {
    throw new Error('无效校验批次大小');
  }
  let completed = 0;
  const total = keys.length;
  for (let offset = 0; offset < total; offset += batchSize) {
    if (!isActive()) return { completed, total, stopped: true };
    const sourceKeys = keys.slice(offset, offset + batchSize);
    const ticket = await api.validateSourcesAsync({ sourceKeys, keyword: '我的', concurrency: 32 });
    if (!ticket || typeof ticket.executionId !== 'string') throw new Error('无效任务票据');
    while (true) {
      if (!isActive()) return { completed, total, stopped: true };
      const status = await api.executionStatus(ticket.executionId);
      if (!isActive()) return { completed, total, stopped: true };
      if (!status || typeof status !== 'object') throw new Error('无效校验状态');
      if (status.done) {
        if (!status.ok) throw new Error(status.error || '校验失败');
        if (!status.result || !Array.isArray(status.result.rows)) throw new Error('无效校验结果');
        await onRows(status.result.rows);
        completed += sourceKeys.length;
        onProgress({ completed, total });
        break;
      }
      const partial = Number(status.progress && status.progress.completed) || 0;
      onProgress({ completed: completed + Math.max(0, Math.min(sourceKeys.length, partial)), total });
      await sleep(500);
    }
  }
  return { completed, total, stopped: false };
}

module.exports = { readItemPages, validateInBatches };
