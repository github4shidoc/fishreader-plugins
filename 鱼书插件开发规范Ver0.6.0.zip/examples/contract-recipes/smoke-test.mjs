import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { readItemPages, validateInBatches } = require('./recipes.cjs');

const rows = Array.from({ length: 2232 }, (_, i) => ({ id: i + 1, item_key: 'item-' + i }));
const fetched = [], delivered = [], requests = [];
await readItemPages({ query: async request => {
  assert.equal(request.maximumRows, 500);
  assert.match(request.sql, /ORDER BY id LIMIT 500$/);
  fetched.push(request.bindArgs[0]);
  return { rows: rows.filter(row => row.id > request.bindArgs[0]).slice(0, 500), truncated: false };
}}, async page => delivered.push(...page));
assert.equal(delivered.length, 2232);
assert.deepEqual(delivered, rows);
assert.deepEqual(fetched, [0, 500, 1000, 1500, 2000]);
let emptyCalls = 0;
await readItemPages({ query: async () => { emptyCalls++; return { rows: [] }; } }, () => assert.fail());
assert.equal(emptyCalls, 1);
await assert.rejects(readItemPages({ query: async () => { throw new Error('db-error'); } }, () => {}), /db-error/);
await assert.rejects(readItemPages({ query: async () => ({ rows: [{ id: 0 }] }) }, () => {}), /游标/);
let fullPageCalls = 0;
await readItemPages({ query: async () => ({ rows: fullPageCalls++ === 0 ? rows.slice(0, 500) : [] }) }, () => {});
assert.equal(fullPageCalls, 2);

const accepted = [], progress = [];
let polls = 0;
const api = {
  validateSourcesAsync: async request => {
    assert.ok(request.sourceKeys.length > 0 && request.sourceKeys.length <= 2048);
    requests.push(request.sourceKeys);
    return { executionId: String(requests.length - 1) };
  },
  executionStatus: async id => {
    if (++polls % 2) return { done: false, progress: { completed: 1 } };
    return { done: true, ok: true, result: { rows: requests[Number(id)].map(sourceKey => ({ sourceKey, valid: true, count: 0 })) } };
  }
};
const options = {
  isActive: () => true, onProgress: value => progress.push(value),
  onRows: values => accepted.push(...values), sleep: async () => {}
};
const keys = rows.map(row => row.item_key);
const done = await validateInBatches(api, keys, options);
assert.deepEqual(done, { completed: 2232, total: 2232, stopped: false });
assert.deepEqual(requests.map(batch => batch.length), [256, 256, 256, 256, 256, 256, 256, 256, 184]);
assert.deepEqual(accepted.map(row => row.sourceKey), keys);
assert.equal(accepted.every(row => row.valid && row.count === 0), true);
assert.deepEqual(progress.at(-1), { completed: 2232, total: 2232 });
const before = requests.length;
assert.deepEqual(await validateInBatches(api, [], options), { completed: 0, total: 0, stopped: false });
assert.equal(requests.length, before);
await assert.rejects(validateInBatches(api, keys, { ...options, batchSize: 2049 }), /批次/);
let active = true, handled = false;
const stopped = await validateInBatches({
  validateSourcesAsync: async () => ({ executionId: 'late' }),
  executionStatus: async () => { active = false; return { done: true, ok: true, result: { rows: [] } }; }
}, ['a'], { ...options, isActive: () => active, onRows: () => { handled = true; } });
assert.equal(stopped.stopped, true);
assert.equal(handled, false);
await assert.rejects(validateInBatches({
  validateSourcesAsync: async () => ({ executionId: 'failure' }),
  executionStatus: async () => ({ done: true, ok: false, error: 'runtime-error' })
}, ['a'], options), /runtime-error/);

const schema = JSON.parse(fs.readFileSync(new URL('../../schemas/plugin/source-result.schema.json', import.meta.url), 'utf8'));
const chapterSchema = schema.$defs.chapter;
assert.equal(chapterSchema.properties.locator.type, 'object');
assert.equal(chapterSchema.additionalProperties, false);
function checkChapter(chapter) {
  for (const key of Object.keys(chapter)) assert.ok(key in chapterSchema.properties, 'invalid chapter field: ' + key);
  if ('locator' in chapter) {
    assert.ok(chapter.locator !== null && typeof chapter.locator === 'object' && !Array.isArray(chapter.locator));
    assert.ok(Buffer.byteLength(JSON.stringify(chapter.locator), 'utf8') <= 262144);
  }
}
const chapter = { chapterKey: 'c1', title: '第一章', ordinal: 0, locator: { chapterUrl: 'https://example.com/c1', tag: '正文' } };
checkChapter(chapter);
assert.throws(() => checkChapter({ ...chapter, tag: '正文' }), /invalid chapter field/);
assert.throws(() => checkChapter({ ...chapter, locator: [] }));
assert.throws(() => checkChapter({ ...chapter, locator: { text: '中'.repeat(90000) } }));
const request = JSON.parse(fs.readFileSync(new URL('../../schemas/plugin/execution-request.schema.json', import.meta.url), 'utf8'));
for (const entry of ['image', 'payAction', 'callback']) assert.ok(request.properties.entrypoint.enum.includes(entry));
console.log('Contract recipes: PASS (2232 items, paging, batches, lifecycle, locator, entrypoints)');
