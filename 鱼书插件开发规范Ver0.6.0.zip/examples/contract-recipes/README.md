# 离线契约回归配方

运行 `node smoke-test.mjs`，无需依赖或网络。

`recipes.cjs` 不是可导入插件，不需单独安装。根据需要把对应函数打包进主模块或管理页，不要在设备端依赖 Node 的 require。它不创建表、不删除记录、不调用站点；模拟宿主只用于验证调用形状与任务边界。

- `readItemPages(database, consume)`：需自行创建 `items(id INTEGER PRIMARY KEY, item_key TEXT NOT NULL)` 表。通过递增主键读全部记录，每页最多 500 行，逐页消费；本例假定 ID 为正整数。
- `validateInBatches(FishReader.plugin, keys, options)`：仅用于管理页；需提供 `isActive`、`onProgress`、`onRows` 和 `sleep`。默认批次 256，不截断输入数组。`sleep` 可传 `ms => new Promise(resolve => setTimeout(resolve, ms))`。
- 面板关闭时令 `isActive()` 返回 false。`onRows` 不应自动删除；若需操作用户数据，先明确确认范围，并在执行前再次检查页面与任务是否仍有效。
- 示例只统计已提交完整批次；等待中的进度由 `onProgress` 单独报告。没有公共取消 API，退出检查不等于终止宿主执行。

配套测试验证 2,232 项完整覆盖、500 行满页边界、空集合、查询异常、不前进游标、校验异常和退出后的迟到结果。章节字段测试依据本包 Schema，并补充其不能表达的 UTF-8 字节约束。
