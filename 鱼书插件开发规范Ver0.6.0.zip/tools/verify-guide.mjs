import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function run(script, args = []) {
  const result = spawnSync(process.execPath, [path.join(root, script), ...args], {
    cwd: root,
    encoding: 'utf8'
  });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${script} 失败`);
}

const files = walk(root);

for (const requiredFile of [
  'schemas/plugin/image-result.schema.json',
  'schemas/plugin/action-result.schema.json',
  'schemas/plugin/web-video-playback-request.schema.json',
  'examples/web-import-basic/index.html',
  'docs/plugins/discover-filters.md'
]) {
  if (!fs.existsSync(path.join(root, requiredFile))) throw new Error(`缺少 ${requiredFile}`);
}

const requiredVersionFiles = [
  'README.md',
  'CHANGELOG.md',
  'docs/plugins/package-format.md',
  'schemas/README.md',
  'types/fishreader-plugin.d.ts',
  'tools/validate-package.mjs',
  'docs/plugins/development-guide.md'
];
for (const name of requiredVersionFiles) {
  const source = fs.readFileSync(path.join(root, name), 'utf8');
  if (!source.includes('0.6.0')) throw new Error(`${name} 未同步到规范版本 0.6.0`);
}
if (!fs.readFileSync(path.join(root, 'README.md'), 'utf8').includes('发布日期：2026-09-27')) {
  throw new Error('README 发布日期未更新');
}
if (/themes\s*\(/.test(fs.readFileSync(path.join(root, 'docs/plugins/package-format.md'), 'utf8'))) {
  throw new Error('插件包格式误将主题入口写为公开能力');
}

for (const file of files.filter(file => file.endsWith('.md'))) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [, rawTarget] of content.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
    const localTarget = rawTarget.split('#', 1)[0];
    if (!localTarget || /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(localTarget)) continue;
    const resolved = path.resolve(path.dirname(file), decodeURIComponent(localTarget));
    if (!fs.existsSync(resolved)) throw new Error(`${path.relative(root, file)} 的链接不存在：${rawTarget}`);
  }
}

for (const file of files.filter(file => file.endsWith('.json'))) {
  JSON.parse(fs.readFileSync(file, 'utf8'));
}

for (const file of files.filter(file => file.endsWith('.schema.json'))) {
  const schema = JSON.parse(fs.readFileSync(file, 'utf8'));
  const visit = value => {
    if (!value || typeof value !== 'object') return;
    if (typeof value.pattern === 'string') new RegExp(value.pattern);
    for (const child of Object.values(value)) visit(child);
  };
  visit(schema);
}

const htmlGuide = fs.readFileSync(path.join(root, 'docs/10-网页接口.md'), 'utf8');
const mainGuide = fs.readFileSync(path.join(root, 'docs/plugins/development-guide.md'), 'utf8');
const videoGuide = fs.readFileSync(path.join(root, 'docs/web-video-bridge.md'), 'utf8');
const declarations = fs.readFileSync(path.join(root, 'types/fishreader-plugin.d.ts'), 'utf8');
const videoSchema = fs.readFileSync(path.join(root, 'schemas/plugin/web-video-playback-request.schema.json'), 'utf8');
for (const [name, source, required] of [
  ['网页接口', htmlGuide, ['localStorage', '.capabilities', 'respondEpisode', 'episodeRequestEvent', 'progressIntervalSeconds']],
  ['主规范', mainGuide, ['网页条目 ID + 当前页面 Origin', 'prefetchNextSeconds', 'startPositionMs', 'refreshEvent']],
  ['视频协议', videoGuide, ['inlineEpisodeRequest', "purpose: 'prefetch'", 'updatedAt', 'sequence', 'ivHex']],
  ['类型声明', declarations, ['FishReaderWebVideoCapabilities', 'FishReaderWebVideoEpisodeResponse', 'respondEpisode?', 'defaultIvHex']],
  ['视频 Schema', videoSchema, ['episodeRequestEvent', 'prefetchNextSeconds', 'startPositionMs', 'defaultIvHex']]
]) {
  for (const token of required) if (!source.includes(token)) throw new Error(`${name} 缺少 0.6.0 内容：${token}`);
}

const relativeNames = files.map(file => path.relative(root, file).replaceAll('\\', '/'));
const forbiddenCharacter = '\u6e90';
if (relativeNames.some(name => name.includes(forbiddenCharacter))) {
  throw new Error('开发包文件名包含禁止字符');
}
for (const file of files.filter(file => /\.(?:md|json|[cm]?js|html?|d\.ts)$/i.test(file))) {
  if (fs.statSync(file).size === 0) throw new Error(`${path.relative(root, file)} 是空文件`);
}
if (relativeNames.some(name => /(^|\/)theme(?:[-./]|$)/i.test(name))) {
  throw new Error('开发包中不应包含主题插件文件');
}

for (const script of [
  'examples/source-basic/smoke-test.mjs',
  'examples/plugin-development/basic/smoke-test.mjs',
  'examples/source-network/smoke-test.mjs',
  'examples/dictionary-basic/smoke-test.mjs',
  'examples/tts-basic/smoke-test.mjs',
  'examples/web-basic/smoke-test.mjs',
  'examples/web-import-basic/smoke-test.mjs',
  'examples/contract-recipes/smoke-test.mjs'
]) run(script);

for (const file of relativeNames.filter(name => name.startsWith('dist/') && name.endsWith('.fishplugin.json'))) {
  run('tools/validate-package.mjs', [file]);
  const packed = JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
  if (packed.manifest.sourceFormat !== 'fishreader-html') new vm.Script(packed.source);
  const exampleCopy = relativeNames.find(name => name.startsWith('examples/') &&
    !name.startsWith('examples/plugin-development/') &&
    path.basename(name) === path.basename(file));
  if (exampleCopy && !fs.readFileSync(path.join(root, file)).equals(fs.readFileSync(path.join(root, exampleCopy)))) {
    throw new Error(`${file} 与示例目录中的包不一致`);
  }
}

console.log(`开发包自检通过：${relativeNames.length} 个文件`);
