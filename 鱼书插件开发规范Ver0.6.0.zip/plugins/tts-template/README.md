# TTS 插件模板

这是一个可配置的 TTS 插件模板。插件把文字、声音和速度转换为受控网络请求，宿主负责请求、音频校验、20 MiB 限制、缓存、预取、重试、播放与停止。

构建：

```bash
node scripts/build-reader-extension-plugins.mjs
```

生成文件：`dist/plugins/fishreader-tts-template.fishplugin.json`。

使用步骤：

1. 在插件管理中导入并启用模板。
2. 打开插件页面，填写你有权使用的 TTS 服务 URL、方法、请求头和正文模板。
3. 确认新增授权域名并保存。
4. 返回阅读设置，在朗读音源中选择模板声音。

模板变量：`{{text}}`、`{{speed}}`、`{{voiceKey}}`。URL 中的变量会进行 URL 编码；请求头和正文保留原始文本，插件开发者应按服务协议自行构造 JSON 或表单内容。

不要在插件包中内置真实令牌。需要保存个人令牌时，应由用户在管理页输入并保存在插件私有存储中。
