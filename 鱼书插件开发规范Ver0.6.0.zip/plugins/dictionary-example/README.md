# 字典插件示例

这是一个不访问网络的最小字典插件，用于验证 `dictionary` 入口及宿主展示链路。

构建：

```bash
node scripts/build-reader-extension-plugins.mjs
```

生成文件：`dist/plugins/fishreader-dictionary-example.fishplugin.json`。

导入并启用后，在阅读页长按选择文字，点击“查字典”。示例内置“插件”“阅读”“目录”三个词条；其它文字会返回演示提示。正式插件可经 `reader.http.fetch` 获取已授权域名的数据，但必须返回纯文本或有限 HTML，不能要求宿主直接打开任意网页。
