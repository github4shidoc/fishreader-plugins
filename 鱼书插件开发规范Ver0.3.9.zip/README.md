# 鱼书插件开发规范 Ver0.3.9

对应应用版本：鱼书 0.3.9  
插件协议：`schemaVersion: 1`  
建议 SDK：`1.0`  
发布日期：2026-09-07

这是一套可以脱离鱼书代码使用的插件开发包。当前公开并建议第三方开发的能力为：

- 内容插件：搜索、发现、详情、目录、正文，以及文字、漫画、有声书和视频内容。
- 字典插件：在阅读页查询选中文字。
- TTS 插件：把阅读页的文字合成为音频。
- 网页插件：提供独立交互页面，并可调用受控网络、存储、文件选择和系统视频播放能力。

主题插件功能尚未完成，本开发包不包含主题规范、模板或主题结果 Schema。声明信息里出现的未公开入口属于宿主保留值，不代表可供第三方稳定使用。

## 0.3.9 兼容重点

- 插件协议仍是 `schemaVersion: 1`，公开 SDK 仍是 `1.0`；不要因为开发规范版本变化而修改这两个值。
- 包内 `entryModule`、`managementModule` 和 `modules` 键统一使用 `/` 分隔的相对路径，不允许绝对路径、反斜杠或 `..`。
- 私有存储可能包含旧版本、备份或跨平台迁移留下的字符串、数字、布尔值、数组或对象；读取后先判断类型，不能无条件 `JSON.parse`。
- 多目标内容插件必须把稳定的 `sourceKey` 贯穿搜索、发现、详情、目录和正文；`bookKey`、`chapterKey` 也必须能在冷启动后重新定位数据。
- 拆分批量搜索由宿主维护 HTTP 槽位；请求完成一个就补入一个。插件不要自行切固定批次等待，也不要在列表阶段提前去重。
- 新增网页接口章节、类型声明、视频播放请求 Schema，以及可直接构建和导入的网页示例。
- 网页调用优先使用 Promise 方法；调用前做能力检测，并为平台暂不具备的可选方法显示明确提示。

## 第一次开发

1. 安装 Node.js 18 或更高版本。
2. 复制 `examples/source-basic`，修改 `manifest.json` 和 `index.js`。
3. 在示例目录执行：

   ```bash
   node build.mjs
   node smoke-test.mjs
   ```

4. 在鱼书中打开“设置 → 插件管理”，导入生成的 `*.fishplugin.json`，启用后测试。
5. 发布前在开发包根目录执行：

   ```bash
   node tools/validate-package.mjs 路径/你的插件.fishplugin.json
   ```

开发包自身可用以下命令完整自检：

```bash
node tools/verify-guide.mjs
```

完整流程见 `docs/01-从零开始.md`。

## 目录

```text
README.md                         本文件
CHANGELOG.md                      本版规范变化
docs/
  01-从零开始.md                 创建、构建、导入第一个插件
  02-插件包与声明信息.md          包格式、Manifest、升级语义
  03-内容插件.md                  搜索到正文的完整数据链路
  04-宿主API.md                   reader.* 能力参考
  05-管理页面与登录.md            FishReader 桥接、文件导入导出、登录
  06-字典与TTS插件.md             两类独立能力
  07-安全性能与兼容.md            权限、限额、后台任务和跨平台要求
  08-测试打包与发布.md            本地检查和发布清单
  09-常见错误.md                 错误定位方法
  10-网页接口.md                 网页桥接、文件、存储和视频播放
examples/
  source-basic/                   无网络、可直接导入的最小内容插件
  source-network/                 网络与 HTML 解析模板
  dictionary-basic/               字典模板
  tts-basic/                      TTS 模板
  web-basic/                      独立网页插件模板
schemas/                          当前公开契约的 JSON Schema
types/fishreader-plugin.d.ts      编辑器类型提示
tools/build-plugin.mjs            通用打包工具
tools/validate-package.mjs        零依赖静态校验工具
tools/verify-guide.mjs            开发包示例与契约自检
dist/                             已构建的示例插件
```

## 重要边界

- 插件运行在隔离环境中，不能直接访问系统文件、进程、套接字、原生对象或页面组件。
- 网络、Cookie、存储、数据库、HTML 解析、加密和私有文件必须通过宿主 API。
- 仅能访问 Manifest 声明并由用户授权的域名；重定向目标也会重新校验。
- 插件输入输出必须是可 JSON 序列化的普通值，不能返回 DOM、函数、自定义类实例或循环引用。
- 插件不得绕过登录、付费、访问控制、反自动化措施或目标服务条款。
- `pluginId` 是升级身份。发布后改显示名可以，改 `pluginId` 会被视为另一个插件。
- 包内模块路径和插件私有文件路径都必须相对化；二者不是系统文件路径。
- TTS 和有声书是两套能力：TTS 合成文字；有声书由内容插件 `content` 返回音频地址。

文档、Schema 和目标鱼书版本有冲突时，以随目标应用发布的 Schema 和该版本实际公开接口为准。
