# 字典与 TTS 插件

## 1. 字典插件

Manifest：

```json
{
  "pluginKinds": ["dictionary"],
  "entrypoints": ["dictionary"]
}
```

入口：

```js
module.exports.dictionary = async function ({ word, context }) {
  const response = await reader.http.fetch({
    url: 'https://dict.example.com?q=' + encodeURIComponent(word),
    method: 'GET'
  });
  const data = JSON.parse(response.body);
  return {
    title: word,
    text: String(data.explanation || '暂无释义')
  };
};
```

返回对象至少包含 `text` 或 `html`：

| 字段 | 说明 |
| --- | --- |
| `title` | 可选标题，最长 256 字符 |
| `text` | 可选纯文本，最长 256 KiB |
| `html` | 可选 HTML 片段，最长 2 MiB |

宿主会清理 HTML 中的脚本、表单、事件属性和不安全外链，并可能同时显示多个已启用字典的结果。插件不能返回一个任意网页 URL 让阅读页直接打开。

无网络可运行模板见 `examples/dictionary-basic`。

## 2. TTS 插件

TTS 插件把文字合成为音频请求，不控制播放器，也不直接返回音频字节。

Manifest：

```json
{
  "pluginKinds": ["tts"],
  "entrypoints": ["ttsVoices", "ttsSynthesize"]
}
```

声音列表：

```js
module.exports.ttsVoices = async function () {
  return [{
    voiceKey: 'female-1',
    name: '女声一',
    locale: 'zh-CN',
    gender: 'female',
    description: '普通话',
    packageId: 'mandarin',
    packageName: '普通话语音包'
  }];
};
```

最多 256 个声音。`voiceKey` 必须在插件版本间稳定唯一，`name` 必需。`locale`、`gender`、`description` 可选。多个语音包可使用稳定 `packageId` 和展示用 `packageName`；省略时宿主按插件名归为一组。

合成入口：

```js
module.exports.ttsSynthesize = async function ({ text, voiceKey, speed }) {
  return {
    url: 'https://tts.example.com/v1/speech',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'audio/mpeg'
    },
    body: JSON.stringify({ text, voice: voiceKey, speed }),
    contentType: 'audio/mpeg',
    cacheKey: voiceKey + ':' + speed + ':' + text
  };
};
```

返回字段：

| 字段 | 必需 | 说明 |
| --- | --- | --- |
| `url` | 是 | 已授权 HTTP(S) 音频请求地址 |
| `method` | 是 | `GET`、`POST` 或 `PUT` |
| `headers` | 否 | 最多 64 项 |
| `body` | 否 | 最大 1 MiB |
| `contentType` | 否 | 真实音频 MIME，默认 `audio/mpeg` |
| `cacheKey` | 否 | 稳定缓存键，最多 512 字符，不得含令牌或个人信息 |

宿主负责文字分片、下一片预取、失败重试、20 MiB 音频下载上限、缓存、播放队列、音频焦点和临时文件清理。

安全要求：

- 不要在 `cacheKey`、错误或日志中暴露令牌。
- 动态签名应在入口中通过标准加密和私有存储生成。
- `voiceKey` 不要使用会变化的展示名称。
- 请求返回必须是实际可播放音频；HTML 登录页、JSON 错误或跳转到未授权域名都会播放失败。

可配置模板见 `examples/tts-basic`。导入后先在插件管理页设置合法服务地址，再在阅读设置中选择声音。

## 3. TTS 与有声书的区别

| 能力 | 数据入口 | 播放页面 |
| --- | --- | --- |
| 文字 TTS | `ttsVoices` + `ttsSynthesize` | 文字阅读页朗读 |
| 有声内容插件 | 内容插件 `catalog` + `contentType: "audio"` | 有声书播放器 |

二者可以存在于同一个插件，但必须分别声明 `source` 和 `tts`，并实现两套完整入口。不要用 TTS 入口返回有声书章节，也不要让内容插件音频走文字朗读播放器。
