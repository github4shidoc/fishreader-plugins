# 网页接口示例

本目录同时给出两种页面：

- `index.html`：可构建导入的独立 HTML 插件，使用 `FishReader`。
- `host-page-example.html`：在应用网页容器中使用通用桥接和系统视频播放器的参考页面，不打入插件包。

构建与检查：

```bash
node build.mjs
node smoke-test.mjs
```

生成的 `fishreader-web-panel.fishplugin.json` 可以在插件管理中导入。普通浏览器不会注入宿主对象，示例会显示降级提示。

