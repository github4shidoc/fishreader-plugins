import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const tool = path.resolve(directory, '../../tools/build-plugin.mjs');
const output = path.join(directory, 'fishreader-web-panel.fishplugin.json');
const result = spawnSync(process.execPath, [tool, directory, output], { stdio: 'inherit' });
process.exit(result.status ?? 1);
