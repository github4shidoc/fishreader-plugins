import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(directory, 'manifest.json'), 'utf8'));
const html = fs.readFileSync(path.join(directory, 'index.html'), 'utf8');
const hostPage = fs.readFileSync(path.join(directory, 'host-page-example.html'), 'utf8');

assert.equal(manifest.sourceFormat, 'fishreader-html');
assert.deepEqual(manifest.entrypoints, ['ui']);
assert.match(html, /FishReader\.ready/);
assert.match(html, /FishReader\.storage\.set/);
assert.match(hostPage, /FishPlayerWebVideo/);
assert.match(hostPage, /globalThis\.fishreaderwebviewvideo/);
assert.match(hostPage, /bridge\.play/);
assert.doesNotMatch(hostPage, /fishplayerwebviewvideo\.play/);
console.log('web-basic smoke test passed');
