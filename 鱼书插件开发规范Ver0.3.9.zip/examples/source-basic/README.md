# 最小内容插件示例

这是一个不访问网络的完整内容插件闭环，适合先验证包结构和四个必需入口。

```bash
node build.mjs
node smoke-test.mjs
```

生成 `fishreader-quickstart.fishplugin.json`，可直接导入鱼书。开发自己的插件时先修改 `pluginId`、名称和版本，再替换固定数据。
