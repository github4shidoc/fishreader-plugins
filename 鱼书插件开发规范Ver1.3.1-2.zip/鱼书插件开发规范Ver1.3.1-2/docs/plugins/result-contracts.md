# Plugin entrypoint result contracts

Documentation release: **1.3.1-2** (FishReader HarmonyOS source 1.3.1, 2026-11-19). The canonical package and
result schemas remain version 1. See [the Vulkan bridge](../18-1.1.2-Vulkan图形接口.md), [the fishweb format](../17-1.1.2-fishweb网页包.md), and [the 0.9.6 interface additions](../16-0.9.6接口增补.md) for webpage behavior.

All JavaScript plugins expose CommonJS functions. Inputs and outputs are JSON values;
the host rejects oversized worker requests/results before product code consumes
them.

- `search({ keyword, page })` returns at most 5,000 book summaries. `bookKey` and
  `title` are required and stable within the plugin.
- `exploreMenu({ page })` optionally returns at most 128 dynamic discovery items
  with unique `key`, user-facing `title`, and an optional `group` heading. Hosts
  load these items before requesting discovery content and render equal non-empty
  groups as a heading followed by their selectable child items.
- `explore({ category, page })` returns the same summary shape, with at most 5,000 summaries per call. A manifest may
  declare user-facing `exploreCategories`; a category action invokes only its
  owning enabled plugin, while the manual key fallback may invoke all enabled
  plugins that declare `explore`.
- Search, explore, and detail book records may return `types` (multiple book
  classifications), `wordCount`, and `publicationStatus` (for example `连载`
  or `完结`). `kind` remains a backward-compatible single classification
  string; new plugins should prefer `types`. They may also return `sourceName`,
  `lastUpdated`, and `mediaType` (`text`, `comic`, `audiobook`, `video`, or `file`).
- `detail({ bookKey, bookUrl, sourceKey?, forceRefresh?, title?, author?, coverUrl?, latestChapter? })` returns normalized book metadata and may add
  `tocUrl`, `canReName`, optional audiobook `chapterCount`, and up to 64 `downloadUrls`.
- `reviews({ sourceKey, bookKey, bookUrl, page, cursor, pageSize, filterKey? })` optionally returns
  `{ items, hasMore, nextCursor?, total?, filters?, selectedFilterKey? }` for discovery detail pages. Each page
  has at most 100 reviews; each review needs a stable `id` and non-empty plain-text
  `content`. See [the review contract](../30-1.1.7-2书评接口.md) and
  [its Schema](../../schemas/plugin/reviews-result.schema.json).
- `catalog({ bookKey, bookUrl, tocUrl, sourceKey?, forceRefresh? })` returns ordered chapter records with a
  stable `chapterKey`, title, zero-based ordinal, and optional URL/volume/lock
  flags. A chapter may override the summary classification with `mediaType` and may include
  `updateTime` (provider supplied publication/update time, at most 128 characters).
- `content({ bookKey, chapterKey, chapterUrl, customVariable?, mediaType? })` returns an object containing
  `content`, an optional `baseUrl`, and `contentType` (`text`, `audio`, `video`,
  or `structured`). Non-text results keep `content` empty and may provide a bounded
  `mediaUrl`, up to 256 `mediaUrls`, bounded `mediaHeaders`, a user-facing
  `message`, `title`, and `imageStyle`; hosts must not render raw API JSON as text.
  Audio results may also return up to 64 stable `{ value, label }` `toneOptions`.
  The selected `value` is supplied in the next `content.customVariable` call.
  Audio may additionally return `mediaEncryption: { algorithm: "cenc", keyHex }`,
  where `keyHex` is a 16-byte key encoded as 32 hexadecimal characters.
  Audio may also return `audioTimeline: {version:1,cues:[{startMs,endMs,text}]}`.
  Cues must be ordered, nonoverlapping, and match the displayed chapter text; see
  [the 1.2.1 contract](../32-1.2.1书籍专属音色与音频时间轴.md).

`forceRefresh: true` asks the plugin to bypass its own stale detail/catalog cache and
fetch current metadata. It does not relax validation or permit synthetic chapters.
All added input fields are optional; plugins must ignore unknown input fields.

For plugins with multiple independent targets, `searchPrepareBatch` maps
`{ keyword, page, sources, concurrency }` to prepared request records. The host
executes those HTTP requests without waiting for JavaScript parsing and later calls
`searchParseBatch({ keyword, page, items })`. Each parsed item is
`{ sourceKey, sourceName, books, errorMessage?, timedOut? }`. `searchBatch` accepts
the same initial input and returns the same parsed items when request preparation
cannot be separated. The split pair is preferred. Batch results contain at most
500 target items and at most 5,000 books per target.

Search may continue after the search page is closed. Plugins must not depend on UI
lifetime or shared native instances, and cancellation may cause the host to discard
in-flight and late results. `reader.result.emit` remains incremental; the final return
value must still contain the complete result list.

The canonical JSON Schemas are under `schemas/plugin/`. Plugins cannot return UI
code or native objects. HTML parsing and HTTP remain explicit Host API calls under
manifest permissions. The synthetic package in `tests/fixtures/plugins/` contains
no real source and is the cross-platform acceptance fixture.

## Dictionary

`dictionary({ word, context? })` returns an object with an optional `title` and at
least one of `text` or `html`. Remote URLs are not a result contract. The host
sanitizes HTML, combines results from enabled dictionary plugins, and shows the
combined document under a restrictive content security policy.

Canonical schema: `schemas/plugin/dictionary-result.schema.json`.

## TTS

`ttsVoices({})` returns at most 256 global voices. For the current book, the host
calls `ttsVoices({scope:'book',bookContext})`. Every record has stable `voiceKey` and
user-facing `name`; `locale`, `gender`, and `description` are optional. A plugin
that exposes several voice packages may also return stable `packageId` and
user-facing `packageName`. The reader groups those records into the shared voice
selector; plugins that omit both fields remain in one plugin-named group.

Voice records may specify `scope:'book'` and `mode:'text'|'chapter'`; missing fields
default to `global` and `text`. Chapter mode requires book scope and calls the
source plugin's `content` with `customVariable=voiceKey` for whole-chapter audio.
A source-only plugin may expose `ttsVoices` for that mode without `ttsSynthesize`.
See [the book voice contract](../32-1.2.1书籍专属音色与音频时间轴.md).

`ttsSynthesize({ text, voiceKey, speed, bookContext? })` returns a network request descriptor or,
for a plugin declaring `ttsPackages`, a local `{kind:'local-model',modelId,voiceId}`
or `{kind:'tts-package',voiceId}` reference. It may also return bounded
`{kind:'audio-base64',dataBase64,contentType?,sampleRate?,tempo?,cacheKey?}`.
The inline audio decodes to at most 5 MiB; see [the inline TTS contract](../38-1.3.1-2语音包音色目录与内联音频.md).
The HTTP form requires `url`; `method` defaults to `GET`, and `headers`, `body`, `contentType`,
and `cacheKey` are optional. The host validates the URL and redirects against the
approved domain set, downloads at most 20 MiB, and owns playback and cleanup.
The local forms must reference models or packages registered to the same plugin;
see [the TTS package contract](../31-1.1.9-TTS语音包接口.md).

When `ttsPackages.runtime` routes a package engine to its owner plugin,
`ttsSynthesize({operation:'package-synthesize',engine,voice,request,outputPath?,streamId?})`
instead returns `{kind:'audio-file',path,contentType,sampleRate,tempo}` or
`{kind:'audio-stream',streamId}`. The host supplies and checks the path or stream ID.
See [the runtime contract](../36-1.3.1-TTS插件运行时与音频流.md) and
[the result Schema](../../schemas/plugin/tts-package-runtime-result.schema.json).

TTS request descriptors are not audiobook chapter results. Source-provided audio uses
the `contentType: "audio"` contract. Global text TTS uses `ttsVoices` / `ttsSynthesize`;
book-scoped chapter mode reuses `content` audio in the text reader.

Canonical schemas: `schemas/plugin/tts-voices-result.schema.json` and
`schemas/plugin/tts-synthesis-result.schema.json` and
`schemas/plugin/tts-package-runtime-result.schema.json`.

## Image transforms and controlled actions

`image({ url, sourceKey?, bookKey?, ... })` returns `{ dataBase64, contentType? }`.
`dataBase64` contains raw Base64 without a data-URL prefix and must decode to a
non-empty payload. `contentType` must describe the actual media type. Canonical
schema: `schemas/plugin/image-result.schema.json`.

`payAction(input)` and `callback(input)` return controlled action descriptions.
The public fields are `handled`, `value`, `openUrl`, `messages`, `uiEffects`, and
`browser`. Plugins cannot directly start platform UI or bypass user confirmation;
the host may ignore effects unsupported on the current platform. Canonical schema:
`schemas/plugin/action-result.schema.json`.

## Source switching

Source switching is a host transaction, not a plugin capability. The selected
plugin supplies a normalized `detail` and `catalog`; the host keeps the existing
bookshelf `book_id`, groups, tags, bookmarks, and reading-progress record while
replacing `source_id`, `source_book_key`, `plugin_books`, and the chapter set.

Progress and bookmarks map to the new catalog by chapter key, then by a
whitespace-normalized exact title, then by the clamped prior ordinal. Character
offset and page hint reset because text pagination is source-specific. Old source
chapter content and integrity metadata are never reused. A switch is rejected when
the replacement plugin is disabled, its catalog is empty, or the target
`(plugin_id, book_key)` already belongs to another bookshelf record.
