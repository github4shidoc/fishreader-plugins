import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
import { test } from 'node:test';

const html = fs.readFileSync(new URL('./lan-transfer-test.html', import.meta.url), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
function dom() {
  const elements = new Map();
  const document = {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, {textContent:'', value:'8080', disabled:false,
        append(){}, replaceChildren(){}});
      return elements.get(id);
    },
    querySelector: () => ({textContent:''}),
    createElement: () => ({append(){}})
  };
  return {document, get: id => document.getElementById(id)};
}
function server(options = {}) {
  const d = dom(), events = []; let handler;
  const window = {crypto:webcrypto,
    FishReaderTasks:{
      async registerAsync(json){assert.equal(JSON.parse(json).type,'dataTransfer');events.push('register'); if(options.denied) throw Error('denied'); return JSON.stringify({running:true});},
      async statusAsync(){return JSON.stringify({running:!options.cancelled, recovering:!!options.cancelled});},
      async stopAsync(){events.push('stop-task');}
    },
    FishHttpService:{async listen(port, fn){events.push('listen'); if(options.listenFails) throw Error('occupied'); handler=fn;
      return {port,urls:['http://192.168.1.2:8080'],async close(){events.push('close');}};}}
  };
  const source=script;
  vm.runInNewContext(source, {document:d.document, window, URL, Date, Uint8Array, AbortController, setTimeout, clearTimeout});
  return {...d, events, async request(path){return handler({method:'GET',url:'http://host'+path,target:path,headers:{}});}};
}
const settle = () => new Promise(resolve => setImmediate(resolve));
function remote(fetchImpl) {
  const d=dom(), timers=new Map(), listeners=new Map(), calls=[];let now=1000, id=0;
  const context=vm.createContext({document:d.document, window:{addEventListener:(event,fn)=>listeners.set(event,fn)},
    URL, Date, AbortController, Uint8Array, performance:{now:()=>now},
    setTimeout:(fn,ms)=>{timers.set(++id,{fn,due:now+ms});return id;}, clearTimeout:id=>timers.delete(id),
    fetch:async(path,options)=>{calls.push({path,options}); if(fetchImpl)return fetchImpl(path,options);
      return path.startsWith('/api/transfer')?{ok:true,arrayBuffer:async()=>new ArrayBuffer(128*1024)}:
        {ok:true,json:async()=>({backgroundTask:{running:true}})};}
  });
  vm.runInContext(script.slice(script.indexOf('function remoteClient()'),script.indexOf('\nconst $ ='))+'\nremoteClient();', context);
  return {...d,timers,listeners,calls,
    async advance(ms){const target=now+ms;while(true){const entry=[...timers].filter(([,t])=>t.due<=target).sort((a,b)=>a[1].due-b[1].due)[0];
      if(!entry)break;now=entry[1].due;timers.delete(entry[0]);entry[1].fn();await settle();}now=target;await settle();}
  };
}
test('server listens before task registration and returns a fixed non-cacheable 128 KiB binary payload', async()=>{
  const f=server();await f.get('start').onclick();assert.deepEqual(f.events,['listen','register']);
  const a=await f.request('/api/transfer?t=1'), b=await f.request('/api/transfer?t=2');
  assert.equal(a.status,200);assert.equal(a.body.byteLength,131072);assert.equal(a.body,b.body);
  assert.equal(a.headers['Cache-Control'],'no-store');assert.equal(a.headers['Content-Encoding'],'identity');
  assert.ok(new Set(a.body).size>200);assert.equal((await f.request('/api/status')).body.backgroundTask.running,true);
  assert.match((await f.request('/')).body,/transferToggle/);
  assert.equal((await f.request('/missing')).status,404);
  await f.get('stop').onclick();assert.deepEqual(f.events,['listen','register','stop-task','close']);
});
test('failed permission or listener startup leaves no task or listener to leak', async()=>{
  for(const options of [{denied:true},{listenFails:true}]){
    const f=server(options);await f.get('start').onclick();assert.equal(f.get('start').disabled,false);
    assert.deepEqual(f.events,options.denied?['listen','register','close']:['listen']);
  }
});
test('external client consumes real bodies once a minute and reports the elapsed-time average',async()=>{
  const f=remote();await settle();assert.equal(f.calls.length,2);
  await f.advance(60000);assert.equal(f.calls.filter(c=>c.path.startsWith('/api/transfer')).length,2);
  assert.match(f.get('transferOutput').textContent,/成功：2 次/);
  assert.match(f.get('transferOutput').textContent,/平均：4.27 KiB\/s/);
  await f.advance(60000*19);assert.equal(f.calls.filter(c=>c.path.startsWith('/api/transfer')).length,21);
  f.get('transferToggle').onclick();assert.equal(f.timers.size,0);
});
test('stop and pagehide abort pending transfer and prevent late completion from scheduling more work',async()=>{
  for(const exit of ['stop','pagehide']){
    let resolve;const pending=new Promise(r=>resolve=r);
    const f=remote(()=>pending);assert.equal(f.calls.length,1);
    if(exit==='stop')f.get('transferToggle').onclick();else f.listeners.get('pagehide')();
    assert.equal(f.calls[0].options.signal.aborted,true);
    resolve({ok:true,arrayBuffer:async()=>new ArrayBuffer(131072)});await settle();
    assert.equal(f.timers.size,0);await f.advance(120000);assert.equal(f.calls.length,1);
    assert.match(f.get('transferOutput').textContent,/成功：0 次/);
  }
});
test('timeout aborts the connection; failure never fabricates bytes and waits until the next minute',async()=>{
  const f=remote((path,options)=>new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>{
    const error=Error('abort');error.name='AbortError';reject(error);
  })));
  await f.advance(15000);assert.equal(f.calls[0].options.signal.aborted,true);
  assert.match(f.get('transferOutput').textContent,/失败：1 次/);
  assert.match(f.get('transferOutput').textContent,/实际接收：0.0 KiB/);
  await f.advance(44999);assert.equal(f.calls.length,1);await f.advance(1);assert.equal(f.calls.length,2);
  f.get('transferToggle').onclick();await settle();assert.equal(f.timers.size,0);
});
test('a busy transfer never overlaps a subsequent round and restarting ignores a late old response',async()=>{
  let resolve;const f=remote(()=>new Promise(r=>resolve=r));
  await f.advance(180000);assert.equal(f.calls.length,1);
  const finishOld=resolve;f.get('transferToggle').onclick();f.get('transferToggle').onclick();
  assert.equal(f.calls.length,2);finishOld({ok:true,arrayBuffer:async()=>new ArrayBuffer(131072)});await settle();
  assert.match(f.get('transferOutput').textContent,/成功：0 次/);
  f.get('transferToggle').onclick();resolve({ok:true,arrayBuffer:async()=>new ArrayBuffer(131072)});await settle();
  assert.equal(f.timers.size,0);
});
