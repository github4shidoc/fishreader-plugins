import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {test} from 'node:test';

const guide=fs.readFileSync(new URL('../../docs/27-1.1.6网页服务后台运行.md',import.meta.url),'utf8');
const blocks=[...guide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)].map(match=>match[1]);
assert.equal(blocks.length,3);
for(const block of blocks)new vm.Script('(async()=>{\n'+block+'\n})');

function lifecycle(options={}){
  const events=[];let handler,failStop=options.failStop,failClose=options.failClose;
  const window={FishHttpService:{async listen(port,fn){events.push('listen');handler=fn;
    return {urls:['http://192.0.2.1:'+port],async close(){events.push('close');if(failClose){failClose=false;throw Error('close failed');}}};}},
    FishReaderTasks:{async registerAsync(json){events.push('register');assert.equal(JSON.parse(json).type,'dataTransfer');
      await options.gate;if(options.denied)throw Error('permission denied');return JSON.stringify({running:!options.inactive});},
      async statusAsync(){return JSON.stringify({running:true,transferredBytes:123});},
      async stopAsync(){events.push('stop');if(failStop){failStop=false;throw Error('stop failed');}}}};
  const context=vm.createContext({window,URL,Date,console});
  vm.runInContext(blocks[0]+'\nglobalThis.controls={startService,stopService};',context);
  return {events,...context.controls,request:path=>handler({method:'GET',url:'http://host'+path})};
}
test('published lifecycle code listens first, checks status, then stops task before listener',async()=>{
  const f=lifecycle();const result=await f.startService();assert.equal(result.task.running,true);
  assert.deepEqual(f.events,['listen','register']);
  assert.equal((await f.request('/api/task-status')).body.backgroundTask.transferredBytes,123);
  assert.equal((await f.request('/unknown')).status,404);
  await f.stopService();assert.deepEqual(f.events,['listen','register','stop','close']);
});
test('published lifecycle code rolls back listener on registration failure and supports an explicit restart',async()=>{
  const f=lifecycle({denied:true});await assert.rejects(f.startService(),/permission denied/);
  assert.deepEqual(f.events,['listen','register','close']);await f.stopService();
});
test('published lifecycle code rejects a non-running registration and cleans both resources',async()=>{
  const f=lifecycle({inactive:true});await assert.rejects(f.startService(),/后台任务未启动/);
  assert.deepEqual(f.events,['listen','register','stop','close']);
});
test('published lifecycle cleanup attempts both releases and retries failed cleanup explicitly',async()=>{
  for(const option of ['failStop','failClose']){
    const f=lifecycle({[option]:true});await f.startService();await assert.rejects(f.stopService(),/失败/);
    assert.deepEqual(f.events.slice(2),['stop','close']);await f.stopService();
    assert.equal(f.events.filter(event=>event===(option==='failStop'?'stop':'close')).length,2);
  }
});
test('published lifecycle does not create duplicate listeners while registration is pending',async()=>{
  let resolve;const f=lifecycle({gate:new Promise(r=>resolve=r)});const start=f.startService();
  await new Promise(r=>setImmediate(r));await f.startService();assert.deepEqual(f.events,['listen','register']);
  resolve();await start;await f.stopService();
});
test('published external timer aborts on pagehide, ignores late bodies and never duplicates bridge calls',async()=>{
  const listeners=new Map(),timers=new Map(),calls=[];let resolve,id=0;
  const context=vm.createContext({window:{addEventListener:(name,fn)=>listeners.set(name,fn)},Date,
    performance:{now:()=>1000},AbortController,console,
    setTimeout:(fn,ms)=>{timers.set(++id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
    fetch:(path,options)=>{calls.push({path,options});return new Promise(r=>resolve=r);}});
  vm.runInContext(blocks[2]+'\nglobalThis.controls={startTransferExperiment,stopTransferExperiment};',context);
  const results=[];context.controls.startTransferExperiment(value=>results.push(value));
  assert.equal(calls.length,1);assert.equal([...timers.values()][0].ms,15000);
  listeners.get('pagehide')();assert.equal(calls[0].options.signal.aborted,true);
  resolve({ok:true,arrayBuffer:async()=>new ArrayBuffer(131072)});await new Promise(r=>setImmediate(r));
  assert.equal(results.length,0);assert.equal(timers.size,0);
});
