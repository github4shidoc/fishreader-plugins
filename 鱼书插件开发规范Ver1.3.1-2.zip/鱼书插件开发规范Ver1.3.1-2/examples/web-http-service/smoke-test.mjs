import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('./lan-test.html', import.meta.url), 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/);
assert.ok(match, 'test page must include its service script');
const script = match[1];

function fixture(options = {}) {
  const events = [], elements = new Map();
  function element() {
    return {
      textContent: '', disabled: false, value: '8080', children: [],
      append(...children) { this.children.push(...children); },
      replaceChildren() { this.children = []; }
    };
  }
  const document = {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, element());
      return elements.get(id);
    },
    querySelector() { return { textContent: '' }; },
    createElement: element
  };
  let handler, failStop = !!options.failStop;
  const tasks = {
    async registerAsync(input) {
      events.push('register');
      assert.equal(JSON.parse(input).type, 'dataTransfer');
      if (options.denied) throw Error('permission denied');
      return JSON.stringify({ running: !options.inactive, error: options.inactive ? 'task stopped' : '' });
    },
    async statusAsync() {
      events.push('status');
      return JSON.stringify(options.status || { running: true, transferredBytes: 123 });
    },
    async stopAsync() {
      events.push('stop-task');
      if (failStop) { failStop = false; throw Error('stop failed'); }
      return 'ok';
    }
  };
  const http = {
    async listen(port, callback) {
      events.push('listen');
      assert.equal(port, 8080);
      if (options.listenFails) throw Error('port busy');
      handler = callback;
      return { port, urls: ['http://192.168.1.2:8080'], async close() { events.push('close-listener'); } };
    }
  };
  const context = vm.createContext({
    document, window: { FishReaderTasks: tasks, FishHttpService: http },
    URL, Date, Uint8Array, AbortController, setTimeout, clearTimeout
  });
  vm.runInContext(script, context);
  return { events, get: id => document.getElementById(id), request: request => handler(request) };
}

const statusRequest = { method: 'GET', target: '/api/status', url: 'http://localhost/api/status', headers: {} };
let f = fixture();
await f.get('start').onclick();
assert.deepEqual(f.events, ['listen', 'register']);
assert.equal(f.get('background').textContent, '后台任务：已申请');
assert.equal((await f.request(statusRequest)).body.backgroundTask.running, true);
await f.get('stop').onclick();
assert.deepEqual(f.events, ['listen', 'register', 'status', 'stop-task', 'close-listener']);
assert.equal(f.get('start').disabled, false);
console.log('PASS registration, status and stop order');

f = fixture({ denied: true });
await f.get('start').onclick();
assert.deepEqual(f.events, ['listen', 'register', 'close-listener']);
assert.equal(f.get('start').disabled, false);
assert.match(f.get('message').textContent, /permission denied/);
console.log('PASS denied registration rolls back the listener');

f = fixture({ inactive: true });
await f.get('start').onclick();
assert.deepEqual(f.events, ['listen', 'register', 'close-listener', 'stop-task']);
assert.equal(f.get('start').disabled, false);
console.log('PASS non-running registration cleanup');

f = fixture({ listenFails: true });
await f.get('start').onclick();
assert.deepEqual(f.events, ['listen']);
assert.equal(f.get('start').disabled, false);
console.log('PASS listener failure releases the task');

f = fixture({ failStop: true });
await f.get('start').onclick();
await f.get('stop').onclick();
assert.equal(f.get('stop').disabled, false);
assert.equal(f.get('start').disabled, true);
await f.get('stop').onclick();
assert.equal(f.get('start').disabled, false);
console.log('PASS failed cleanup permits explicit stop retry');

f = fixture({ status: { running: false, error: 'system cancelled' } });
await f.get('start').onclick();
assert.equal((await f.request(statusRequest)).body.backgroundTask.running, false);
assert.match(f.get('background').textContent, /system cancelled/);
assert.equal(f.events.filter(event => event === 'register').length, 1);
console.log('PASS system cancellation is reported without automatic re-registration');
