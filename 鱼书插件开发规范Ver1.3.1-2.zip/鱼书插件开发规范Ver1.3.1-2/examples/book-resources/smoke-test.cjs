const test = require('node:test');
const assert = require('node:assert/strict');
const R = require('./resources.js');
test('independently padded base64 chunks decode before concatenation', async () => {
  const original = Buffer.from('中文 image bytes'), offsets = [];
  const blob = await R.binary(async q => {
    offsets.push(q.offset); const part = original.subarray(q.offset, q.offset + 4);
    return { offset:q.offset, nextOffset:q.offset+part.length, total:original.length, complete:q.offset+part.length===original.length, base64:part.toString('base64'), mediaType:'image/png' };
  }, {op:'resource',path:'images/a.png'});
  assert.deepEqual(Buffer.from(await blob.arrayBuffer()), original); assert.equal(blob.type,'image/png'); assert.ok(offsets.length>1);
});
test('paginated image index uses chapter key, not global ordinal', async () => {
  const entries = Array.from({length:201},(_,i)=>({chapterKey:'c'+i,ordinal:0,archivePath:i+'.png'}));
  const found = await R.chapterImages(async q=>({entries:entries.slice(q.offset,q.offset+q.limit),total:entries.length}),{bookId:'book',token:'token'},{chapterKey:'c200'});
  assert.deepEqual(found,[entries[200]]);
});
test('image references retain original UTF-16 positions and ignore invalid ordinals',()=>{
  const text='😀前文[[FISHREADER_EPUB_IMAGE:2;w=p55;iw=758;ih=74]]尾声[[FISHREADER_EPUB_IMAGE:-1]]';
  const refs=R.imageReferences(text);assert.equal(refs.length,1);assert.equal(refs[0].ordinal,2);assert.equal(refs[0].sourceOffset,4);
  assert.equal(text.slice(refs[0].sourceOffset,refs[0].sourceOffset+refs[0].sourceLength),'[[FISHREADER_EPUB_IMAGE:2;w=p55;iw=758;ih=74]]');
});
test('unknown total ends on empty data; incomplete or misplaced known data fails',async()=>{
  let calls=0;
  const blob=await R.binary(async q=>{calls++;return {offset:q.offset,nextOffset:q.offset+(calls===1?1:0),total:-1,complete:false,base64:calls===1?'YQ==':''};},{op:'readFile',fileId:'f'});
  assert.equal(await blob.text(),'a');assert.equal(calls,2);
  await assert.rejects(R.binary(async()=>({offset:0,nextOffset:0,total:10,complete:false,base64:''}),{op:'resource'}),/中断/);
  await assert.rejects(R.binary(async()=>({offset:0,nextOffset:9,total:10,base64:'YQ=='}),{op:'resource'}),/不连续/);
  await assert.rejects(R.binary(async()=>({offset:0,nextOffset:1,total:0,complete:false,base64:'YQ=='}),{op:'resource'}),/超过资源长度/);
  await assert.rejects(R.binary(async q=>({offset:q.offset,nextOffset:q.offset+1,total:q.offset?3:2,complete:false,base64:'YQ=='}),{op:'resource'}),/长度改变/);
});
test('caller abort and memory budget do not return partial bytes',async()=>{
  const controller=new AbortController();controller.abort();let calls=0;
  await assert.rejects(R.binary(async()=>{calls++;},{op:'resource'},{signal:controller.signal}),/停止/);assert.equal(calls,0);
  await assert.rejects(R.binary(async()=>({offset:0,nextOffset:1,total:100,base64:'YQ=='}),{op:'resource'},{maxBytes:10}),/预算/);
});
test('book errors preserve session revocation code',async()=>{
  await assert.rejects(R.request({requestAsync:async()=>JSON.stringify({ok:false,code:'SESSION_REVOKED',error:'revoked'})},{op:'resource'}),e=>e.code==='SESSION_REVOKED');
});
