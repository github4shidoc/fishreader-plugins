(function (root) {
  'use strict';
  async function request(bridge, input) {
    const value = await bridge.requestAsync(JSON.stringify(input));
    const result = typeof value === 'string' ? JSON.parse(value) : value;
    if (!result?.ok) throw Object.assign(new Error(result?.error || '书籍接口调用失败'), { code: result?.code });
    return result;
  }
  function checkSignal(signal) { if (signal?.aborted) throw new Error('调用方已停止读取'); }
  async function chapterImages(call, reference, chapter, signal) {
    const images = []; let offset = 0;
    for (;;) {
      checkSignal(signal);
      const result = await call({ ...reference, op: 'importData', section: 'images', offset, limit: 200 });
      checkSignal(signal);
      if (!Array.isArray(result.entries)) throw new Error('图片索引不是数组');
      for (const image of result.entries) if (image.chapterKey === chapter.chapterKey) images.push(image);
      offset += result.entries.length;
      if (!result.entries.length || offset >= result.total) return images;
    }
  }
  async function binary(call, input, { signal, maxBytes = 64 * 1024 * 1024 } = {}) {
    if (!['resource', 'cover', 'readFile'].includes(input.op)) throw new Error('不是分片字节操作');
    const parts = []; let offset = 0, mediaType = '', knownTotal = null;
    for (;;) {
      checkSignal(signal);
      const part = await call({ ...input, offset, limit: 1048576 });
      checkSignal(signal);
      const data = Uint8Array.from(atob(part.base64), c => c.charCodeAt(0));
      if (part.offset !== offset || part.nextOffset !== offset + data.length) throw new Error('分片位置不连续');
      if (!Number.isSafeInteger(part.total) || part.total < -1) throw new Error('资源总长度无效');
      if (part.total >= 0) {
        if (knownTotal !== null && knownTotal !== part.total) throw new Error('读取期间资源长度改变');
        knownTotal = part.total;
        if (part.nextOffset > knownTotal) throw new Error('分片超过资源长度');
      } else if (knownTotal !== null) throw new Error('读取期间资源长度改变');
      if (part.total > maxBytes || offset + data.length > maxBytes) throw new Error('超过调用方的内存读取预算');
      offset += data.length; parts.push(data); mediaType = part.mediaType || mediaType;
      if (part.complete) {
        if (part.total >= 0 && part.total !== offset) throw new Error('资源长度不完整');
        break;
      }
      if (part.total >= 0 && offset >= part.total) break;
      if (!data.length) { if (part.total < 0) break; throw new Error('资源读取中断'); }
    }
    return new Blob(parts, { type: mediaType || 'application/octet-stream' });
  }
  function imageReferences(content) {
    const result = [];
    for (const match of String(content).matchAll(/\[\[FISHREADER_EPUB_IMAGE:([^\[\]]*)\]\]/g)) {
      const [number, ...fields] = match[1].split(';');
      if (!/^\d+$/.test(number) || !Number.isSafeInteger(Number(number))) continue;
      // Optional fields are data. Never concatenate them into style/HTML/code.
      result.push({ ordinal: Number(number), fields, sourceOffset: match.index, sourceLength: match[0].length });
    }
    return result;
  }
  const exported = { request, chapterImages, binary, imageReferences };
  if (typeof module !== 'undefined' && module.exports) module.exports = exported; else root.BookResourceExample = exported;
})(typeof window !== 'undefined' ? window : globalThis);
