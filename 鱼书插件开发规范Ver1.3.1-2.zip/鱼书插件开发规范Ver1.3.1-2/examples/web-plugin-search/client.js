(function (root) {
  'use strict';
  const decode = value => typeof value === 'string' ? JSON.parse(value) : value;
  const error = (code, message) => Object.assign(new Error(message), { code });
  function createPluginClient(bridge, onState = () => {}) {
    const queue = []; let active = 0;
    function capacity() {
      try {
        const value = decode(bridge.capabilities()).maxConcurrentRequests;
        if (Number.isSafeInteger(value) && value > 0) return value;
      } catch (_) {}
      return 4; // Conservative compatibility with older supported hosts.
    }
    function state() { return { capacity: capacity(), active, queued: queue.filter(job => !job.settled).length }; }
    function notify() { try { onState(state()); } catch (_) {} }
    function drain() {
      while (queue.length && active < capacity()) {
        const job = queue.shift(); if (job.settled) continue;
        if (job.signal?.aborted) { job.finish(error('ABORTED', '已停止等待')); continue; }
        active++;
        job.timer = setTimeout(() => job.finish(error('WAIT_TIMEOUT', '网页等待超时；底层请求仍占容量')), job.waitMs);
        // Only this line submits to the app. Queued jobs remain entirely in JS.
        Promise.resolve().then(job.work).then(value => job.finish(null, value), cause => job.finish(cause))
          .finally(() => { active--; drain(); });
      }
      notify();
    }
    function submit(work, { signal, waitMs = 45000 } = {}) {
      return new Promise((resolve, reject) => {
        const job = { work, signal, waitMs, settled: false, timer: null };
        const abort = () => { job.finish(error('ABORTED', '已停止等待')); drain(); };
        job.finish = (cause, value) => {
          if (job.settled) return;
          job.settled = true; clearTimeout(job.timer); signal?.removeEventListener('abort', abort);
          cause ? reject(cause) : resolve(value);
          // Do not decrement active here: timeout/abort does not cancel native work.
        };
        if (signal?.aborted) { abort(); return; }
        signal?.addEventListener('abort', abort, { once: true });
        queue.push(job); drain();
      });
    }
    return {
      state,
      async list(options) {
        const result = decode(await submit(() => bridge.listAsync(), options));
        if (!Array.isArray(result)) throw error('BAD_RESULT', '插件列表无效');
        return result;
      },
      async invoke(pluginId, entrypoint, input, options = {}) {
        const result = decode(await submit(() => bridge.invokeAsync(JSON.stringify({ pluginId, entrypoint, input })),
          { waitMs: entrypoint === 'content' ? 135000 : 45000, ...options }));
        if (!result?.ok) throw error(result?.error?.code || 'PLUGIN_ERROR', result?.error?.message || '插件调用失败');
        return result;
      }
    };
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { createPluginClient };
  else root.createPluginClient = createPluginClient;
})(typeof window !== 'undefined' ? window : globalThis);
