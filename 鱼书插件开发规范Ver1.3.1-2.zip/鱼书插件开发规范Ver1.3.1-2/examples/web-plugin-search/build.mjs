import fs from 'node:fs';
const read = name => fs.readFileSync(new URL(name, import.meta.url), 'utf8');
const html = read('template.html').replace('<!-- CLIENT_SCRIPT -->', '<script>\n' + read('client.js').replace(/<\/script/gi, '<\\/script') + '\n</script>');
fs.writeFileSync(new URL('index.html', import.meta.url), html);
console.log('Built standalone web-plugin-search/index.html');
