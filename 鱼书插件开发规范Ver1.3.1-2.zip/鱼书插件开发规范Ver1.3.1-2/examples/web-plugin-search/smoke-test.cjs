const test = require('node:test');
const assert = require('node:assert/strict');
const { createPluginClient } = require('./client.js');
const tick = () => new Promise(resolve => setImmediate(resolve));
function fixture(capacity = 32) {
  const calls = [], finish = [];
  const bridge = { capabilities: () => JSON.stringify({ maxConcurrentRequests: capacity }),
    invokeAsync: input => new Promise(resolve => { calls.push(JSON.parse(input)); finish.push(resolve); }),
    listAsync: () => new Promise(resolve => { calls.push({ entrypoint: 'list' }); finish.push(resolve); }) };
  return { client: createPluginClient(bridge), calls, finish };
}
const success = JSON.stringify({ ok: true, result: [] });
test('webpage submits 32 then immediately refills source 33 after one completion', async () => {
  const f = fixture();
  const tasks = Array.from({ length: 33 }, (_, i) => f.client.invoke('p', 'search', { sourceKey: String(i) }));
  await tick(); assert.equal(f.calls.length, 32); assert.equal(f.client.state().queued, 1);
  f.finish[0](success); await tick(); assert.equal(f.calls.length, 33);
  f.finish.forEach(resolve => resolve(success)); await Promise.all(tasks);
  await tick(); assert.equal(f.client.state().active, 0);
  assert.ok(f.calls.every(q => !('concurrency' in q.input)));
});
test('older hosts reporting 4 retain their capacity and list shares slots', async () => {
  const f = fixture(4); const list = f.client.list();
  const tasks = Array.from({ length: 4 }, () => f.client.invoke('p', 'search', {}));
  await tick(); assert.equal(f.calls.length, 4); f.finish[0]('[]'); await list; await tick();
  assert.equal(f.calls.length, 5); f.finish.slice(1).forEach(resolve => resolve(success)); await Promise.all(tasks);
});
test('a failed source frees its actual slot and subsequent source still runs', async () => {
  const f = fixture(1);
  const first = f.client.invoke('p', 'search', {});
  const failure = assert.rejects(first, /single source failed/);
  const next = f.client.invoke('p', 'search', {});
  await tick(); f.finish[0](JSON.stringify({ ok: false, error: { code: 'PLUGIN_ERROR', message: 'single source failed' } }));
  await failure; await tick(); assert.equal(f.calls.length, 2); f.finish[1](success); await next;
});
test('waiting timeout does not free the occupied app slot', async () => {
  const f = fixture(1);
  await assert.rejects(f.client.invoke('p', 'search', {}, { waitMs: 10 }), e => e.code === 'WAIT_TIMEOUT');
  const second = f.client.invoke('p', 'detail', {});
  await tick(); assert.equal(f.calls.length, 1); assert.equal(f.client.state().active, 1);
  f.finish[0](success); await tick(); assert.equal(f.calls.length, 2); f.finish[1](success); await second;
});
test('stop removes queued work, rejects late results, and restart still shares native occupancy', async () => {
  const f = fixture(1), control = new AbortController();
  const first = f.client.invoke('p', 'search', {}, { signal: control.signal }).catch(e => e.code);
  const queued = f.client.invoke('p', 'search', {}, { signal: control.signal }).catch(e => e.code);
  await tick(); control.abort(); assert.equal(await first, 'ABORTED'); assert.equal(await queued, 'ABORTED');
  const restart = f.client.invoke('p', 'search', { keyword: 'new' }); await tick(); assert.equal(f.calls.length, 1);
  f.finish[0](success); await tick(); assert.equal(f.calls.length, 2); assert.equal(f.calls[1].input.keyword, 'new');
  f.finish[1](success); await restart;
});
