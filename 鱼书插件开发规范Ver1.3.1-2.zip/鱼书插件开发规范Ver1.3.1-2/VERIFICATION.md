# Ver1.3.1-2 开发包验证说明

日期：2026-11-19。以 Ver1.3.1 的 169 个文件为基线建立完整包。当前本地鸿蒙应用仍标记为 `versionName: 1.3.1` / `versionCode: 10131`；规范修订号为 1.3.1-2。插件包协议 `schemaVersion: 1`、建议 SDK `1.0` 不变，旧版目录和归档保留。

## 1.3.1-2 公开接口核对

- 对照 `PluginTtsPackageCatalogHost.ets`、`HarmonyPluginHostBroker.ets`、`HarmonyIsolatedPluginRuntime.ets`：`reader.ttsPackages.voices/resolveVoice` 只查询当前拥有语音包运行时声明的 TTS 插件，要求 `pluginStorage` 权限；分页、筛选、音色解析和失败边界已记录。
- 对照 `PluginTtsInlineAudio.ets`、`HarmonySourcePluginService.ets`、`ReaderTtsPluginWorkflow.ets`：普通 `ttsSynthesize` 增加 `audio-base64`，按标准 Base64、解码 5 MiB 上限、音频 MIME 与元数据校验；旧的 HTTP 和本地音色结果仍有效。
- 对照 `WebpageContentPluginService.ets`、`WebViewPage.ets`、`WebPluginAudioStreamTransport.ets`：仅已导入本地网页入口可列出并调用 TTS 插件；`output:'stream'` 需目标插件声明流式能力，网页取得一次性同源音频 URL，状态、关闭和生命周期边界已记录。商店专用、主题类插件和宿主内部对象未作为公开接口。

## 本版可复现检查

- `node tools/verify-guide.mjs`：通过；173 个文件、2,232 项契约配方、示例、链接、Schema 和新专章检查通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 安卓定向测试按用户要求不纳入本次验收；本版检查针对鸿蒙公开接口及规范包。
- ZIP 路径、CRC 与目录逐字节核对：旧版 169 个路径全部保留；新版 173 个文件与目录一致，ZIP CRC 通过。
- 本次只更新规范包，未修改应用代码；未构建或安装应用，离线检查不代替真机 TTS 网页音频播放验收。

## Ver1.3.1 验证记录（历史）

日期：2026-11-18。以 Ver1.2.8 的 166 个文件为基线建立完整包，核对本地鸿蒙应用 `versionName: 1.3.1` / `versionCode: 10131`。插件协议 `schemaVersion: 1`、建议 SDK `1.0` 不变。旧版目录和归档保留。

## 1.3.1 公开接口核对

- 对照 `TtsPackagePolicy.ets`、`PluginPackageEngineAdapter.ets`、`PluginAudioStreamService.ets`、`HarmonyIsolatedPluginRuntime.ets` 与 Android 对应实现：`ttsPackages.runtime` 的引擎路由、`package-synthesize` 输入、受限文件结果和 `reader.audioStream` 编码字节流均为插件运行时可用契约。
- 对照 `PluginSocketExchange.ets`、`HarmonyPluginHostBroker.ets` 与 Android 对应实现：`reader.socket.open/send/read/close` 是插件侧有界 WebSocket 会话；独立网页与管理页不注入该对象。
- 当前应用的阅读器、同步和播放器内部流程未写成新增公共入口；商店专用与主题类插件保持排除。

## 本版可复现检查

- `node tools/verify-guide.mjs`：通过；169 个文件、2,232 项契约配方、示例、链接、Schema 及 1.3.1 两个新专章检查通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 包校验器对合法及非法 `ttsPackages.runtime` 声明：合法引擎代码、类型及流式布尔值通过；非法引擎代码按预期被拒绝。
- 源码静态边界核对：鸿蒙与 Android 共 8 处声明、运行时桥、宿主处理、流服务及 WebSocket 会话标记均匹配；这不是运行时连线测试。
- ZIP 路径、CRC 与目录逐字节核对：以本文件最终内容打包后通过，旧版 166 个路径全部保留，新版共 169 个文件。
- 本次只更新规范包，不修改应用源码；未构建或安装应用，离线检查不能代替真机语音流与 WebSocket 连接验收。

## Ver1.2.8 验证记录（历史）

日期：2026-11-16。本完整包以 Ver1.2.5 的全部 162 个文件为基线，新增语音包下载导入与网页弹幕表情专章及对应 Schema，共 166 个文件。按要求将规范版本命名为 1.2.8；当前本地应用源码标记为 `versionName: 1.2.9` / `versionCode: 10129`，不将两者混同。插件协议 `schemaVersion: 1`、建议 SDK `1.0` 不变。旧版目录及归档未覆盖。

## 1.2.8 公开接口核对

- 对照 `HtmlPlugin.ets`、`LocalTtsPackageService.ets`、`TtsPackageDownloadService.ets` 与 `TtsPackageDownloadTask.ets`：仅声明了 `ttsPackages` 的当前 TTS 插件管理页可调用 `download(args)`；分类须支持 `multitts`，下载经插件网络权限、大小和 SHA-256 校验，结果沿用导入汇总结构。
- 对照 `WebVideoPlaybackModels.ets`、`WebVideoInlinePlayer.ets` 和 `DanmakuInlineEmotes.ets`：`respondDanmakuList` 新增可选 `emotes`，仅匹配当前列表中的方括号标记，限制前 64 个映射和受支持的图片数据 URI。
- 同期多角色配音、导入设置和书架隐私属于应用侧流程，未把它们写成新增的插件入口；商店专用、主题类插件和宿主内部辅助接口继续不纳入公开规范。

## 本版可复现检查

- `node tools/verify-guide.mjs`：通过；166 个文件、2,232 项契约配方、示例、链接、Schema 与 1.2.8 专章检查通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- `node --test scripts/tests/tts-package-layout.test.cjs`：46 项通过，覆盖现有 TTS 包目录、导入、迁移、隔离与备份；不覆盖新增网络下载的端到端流程。
- 对当前应用源码六处公开边界做静态断言：管理页桥、下载入口/限制、播放模型、弹幕列表赋值和表情解码均匹配本版说明。此检查不执行网络下载或 WebView 回调。
- 归档逐文件核对：Ver1.2.5 的 162 个文件路径全部保留，新增 2 个专章和 2 个 Schema；Ver1.2.8 ZIP 的 166 个文件与目录逐字节一致，ZIP CRC 检查通过。
- 本次仅更新规范包，未修改应用代码；未构建或安装 HAP，离线检查不代替真机下载导入与弹幕表情验收。

## Ver1.2.5 验证记录（历史）

日期：2026-11-14。本完整包以 Ver1.2.1 的全部 161 个文件为基线，新增网页弹幕列表与插件页面视频桥专章，共 162 个文件。应用源码已声明 `versionName: 1.2.5` / `versionCode: 10125`；插件协议 `schemaVersion: 1`、建议 SDK `1.0` 不变。旧版目录及归档未覆盖。

## 1.2.5 公开接口核对

- 对照 `WebVideoPlaybackModels.ets`、`WebVideoInlinePlayer.ets` 和 `WebViewPage.ets`：播放请求 `danmaku.loadEvent`、按集事件、`respondDanmakuList`、30 秒等待和弹幕条目接收限制已记录；独立网页可检测 `capabilities().generic.danmakuLoadEvent`。
- 对照 `HtmlPlugin.ets`：插件页面和插件管理页面的视频桥公开 `play`、`respondEpisode`、`respondQuality`、`respondDanmakuList`；不公开独立网页的内嵌矩形/待交付进度方法。旧章节“只提供 play”已修正。
- 同期变动的同步、备份、阅读设置与播放器内部实现未形成新的通用插件入口，未写入第三方接口规范。商店专用、主题类插件和宿主内部辅助接口继续不纳入本包。

## 本版可复现检查

- `node tools/verify-guide.mjs`：通过；162 个文件、2,232 项契约配方、示例、链接、Schema 与 1.2.5 专章检查通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 对当前应用源码四处公开边界做静态断言：`WebViewPage.ets` 的能力与代理注册、`HtmlPlugin.ets` 的页面视频代理、`WebVideoPlaybackModels.ets` 的会话/超时、`WebVideoInlinePlayer.ets` 的弹幕条目处理均匹配本版说明。此检查不执行网页回调。
- `node --test scripts/tests/harmony-player-danmaku-toggle.test.cjs`：5 项通过，覆盖既有弹幕设置开关和渲染状态；不覆盖新回调的端到端行为。
- 归档逐文件核对：Ver1.2.1 的 161 个文件路径全部保留，新增 1 个专章；Ver1.2.5 ZIP 的 162 个文件与目录逐字节一致，ZIP CRC 检查通过。
- 本次仅更新规范包，未修改应用代码；未构建或安装 HAP，离线检查不代替真机网页弹幕与插件页面视频播放验收。

## Ver1.2.1 验证记录（历史）

日期：2026-11-10。本完整包以 Ver1.1.9 的全部 160 个文件为基线，新增书籍专属音色与音频时间轴专章，共 161 个文件。应用源码已声明 `versionName: 1.2.1` / `versionCode: 10121`；插件协议 `schemaVersion: 1`、建议 SDK `1.0` 不变。旧版目录及归档未覆盖。

## 1.2.1 公开接口核对

- 对照 `HarmonySourcePluginService.ets`、`ReaderTtsPluginWorkflow.ets` 和 `ReaderHttpTtsService.ets`：`ttsVoices` 的书籍上下文、声音 `scope` / `mode` 默认值及组合约束、逐段合成与整章内容调用均已记录。纯内容插件可单独声明书籍章节音色。
- 对照 `HarmonyAudioTimeline.ets`、`HarmonySourcePluginService.ets` 和 `ReaderHttpTtsService.ets`：`content.audioTimeline` 的长度、顺序、文本匹配和无效时间轴降级均已记录。网页桥入口、商店专用与宿主内部辅助接口未新增到公开规范。

## 本版可复现检查

- `node tools/verify-guide.mjs`：通过；161 个文件、2,232 项契约配方、示例、链接、Schema 及 1.2.1 新章节检查通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 当前源码定向测试 `node --test scripts/tests/harmony-book-tts.test.cjs scripts/tests/harmony-audio-timeline.test.cjs scripts/tests/harmony-book-voice-panel.test.cjs`：27 项中 24 项通过，3 项失败。失败均在 `harmony-audio-timeline.test.cjs` 的 `seekFixture`，夹具生成的 `Service` 缺少 `stop()`，调用当前 `loadChapter()` 时抛出 `TypeError: this.stop is not a function`；未以此声称应用运行行为通过。该测试夹具属于应用源码，不在本规范包内。
- 归档逐文件核对：Ver1.1.9 的 160 个文件路径全部保留，新增 1 个专章；Ver1.2.1 ZIP 的 161 个文件与目录逐字节一致，ZIP CRC 检查通过。
- 本次仅更新规范包，未修改应用代码；未构建或安装 HAP，离线检查不代替真机朗读与高亮验收。

## Ver1.1.9 验证记录（历史）

## 1.1.9 公开接口核对

- 对照 `HarmonyPluginBookReviews.ets` 与 `SourceBookReviewsController.ets`：`reviews` 增加可选 `filterKey`、最多 64 个按钮组成的 `filters` 和 `selectedFilterKey`；校验非空唯一键、按钮类型、选中值和筛选切换后的结果身份。现有分页、超时和适用页面范围保留。
- 对照 `TtsPackagePolicy.ets`、`HarmonySourcePluginService.ets` 与 `HtmlPlugin.ets`：仅 TTS 插件可声明 `ttsPackages`，当前插件管理页可调用通用 `FishReader.ttsPackages`。声明格式、权限边界、方法及返回字段已同步；特定插件旧 `FishReader.tts` 操作不作为通用第三方接口。
- 对照 `LocalTtsPackageService.ets` 和 `ReaderTtsPluginWorkflow.ets`：`ttsSynthesize` 新增 `local-model` 与 `tts-package`，都必须引用当前插件已登记资源；HTTP 请求形状仍有效。结果 Schema 与类型声明已同步。
- 独立网页的 `FishReaderPlugins` 允许入口仍不包含 `reviews`；管理页 `ttsPackages` 也不是独立网页桥。商店专用和宿主内部辅助接口未纳入本版公开规范。

## 本版可复现检查

- `node --test scripts/tests/harmony-book-detail-reviews.test.cjs scripts/tests/tts-package-layout.test.cjs`：48 项通过，覆盖书评筛选、TTS 声明、导入、迁移、本地合成及隔离。
- `node tools/verify-guide.mjs`：通过，报告 160 个文件；旧版示例、2,232 项契约配方、Schema、链接与新增章节检查均通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 使用当前本地 TTS 示例的 Manifest、主模块和管理页组装包，`tools/validate-package.mjs` 校验通过。
- 本次仅更新规范与随包校验工具，未修改应用代码，未重新构建或安装 HAP；离线检查不代替真机语音包导入、合成与书评筛选验收。

## Ver1.1.7-2 验证记录（历史）

日期：2026-11-07。以正式 Ver1.1.7 的全部 156 个文件为基线，新增长篇书评接口说明与结果 Schema，共 158 个文件。对应鸿蒙应用仍为 1.1.7；插件协议 `schemaVersion: 1`、建议 SDK `1.0` 不变。旧版目录和压缩包不覆盖。

## 1.1.7-2 接口核对

- `HarmonySourcePluginService.ets` 在可声明入口列表中加入 `reviews`，成功结果进入 `normalizePluginBookReviews()`；Manifest、执行请求 Schema 及随包校验工具已同步。
- `HarmonyPluginBookReviews.ets` 要求对象结果、`items` 数组不超过 100、布尔 `hasMore`；单项的 `id` 与 `content` 必填，其他文本、头像 URL、游标和总数有各自限制。新结果 Schema 和类型声明按此整理。
- `SourceBookReviewsController.ets` 当前只在发现页文字、漫画、有声书详情请求书评，传入 `sourceKey`、`bookKey`、`bookUrl`、从 1 开始的 `page`、`cursor` 和 `pageSize: 10`；不支持的插件、搜索详情、视频及文件详情不调用。游标重复会报错，失败保留已加载结果。
- `WebpageContentPluginService.ets` 的网页允许入口列表尚无 `reviews`；独立网页不能用 `FishReaderPlugins.invokeAsync()` 调用它。此限制已在书评专章和网页参考明确，不把内部控制器接口写成网页公开方法。
- 打包时间以后修改的其他鸿蒙源码主要是详情展示与已有流程，未识别出需要另增公开签名的接口。本版没有修改应用代码。

## 1.1.7-2 离线检查

- `node --test scripts/tests/harmony-book-detail-reviews.test.cjs scripts/tests/harmony-source-detail-catalog.test.mjs`：23 项通过，覆盖书评校验、分页、失效响应、类型及详情流程。
- `node tools/verify-guide.mjs`：通过，报告 158 个文件；旧版示例、2,232 项契约配方、Schema 和文档链接等既有检查继续通过。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts`：通过。
- 用现有最小内容插件包加上 `reviews` 导出和入口声明，`tools/validate-package.mjs` 校验通过；`plugins/shared/reviews-contract.test.mjs` 的 4 项现有插件兼容检查通过。
- 本次只做源码核对和离线检查，未构建或安装 HAP，未进行真机书评联网验收。

## Ver1.1.7 验证记录（历史）

日期：2026-11-07。以 Ver1.1.6-1 的 145 个文件为基线，保留全部原文件路径，新增两个接口专章和调用示例，共 156 个文件。对应鸿蒙应用 1.1.7；插件协议 `schemaVersion:1`、SDK `1.0` 不变。

## 本版接口核对范围

本版只说明公开接口、返回数据及网页调用方式，不收录完整阅读网页或其产品功能。旧版本记录保留在下方；其中 4 个请求名额等数值仅表示当时实现，当前以 1.1.7 专章为准。

| 项目 | 核对依据与结论 | 文档 |
| --- | --- | --- |
| 内容插件桥 | 对照 WebpageContentPluginService：capabilities 返回 32；listAsync 与所有 invokeAsync 共用容量；BUSY、输入长度、入口和期限保持现有契约 | 22、28 |
| 应用调度 | 对照 HarmonyPluginConcurrency / HarmonyIsolatedPluginRuntime：应用配置实际执行并发，默认 16；网页不传线程数 | 28 |
| callback | 共用同一容量，修正旧章节残留的 4 名额；保留动作解码、来源身份、受控结果和错误语义 | 26、28 |
| 章节定位 | content 使用 locator 及原始上下文；不把外层不透明 chapterUrl 当作 HTTP 地址 | 22 |
| 书籍与图片 | 对照 WebBookService、WebBookFileService、EPUB 标记解析及布局实现：章节身份、图片 ordinal、资源路径、分片字节、未知总长、文件句柄和会话边界 | 25、29 |
| PDF | 已有页图从索引读取；没有缓存时读取原文件，网页接口不自动生成页图 | 29 |
| 配色 | 沿用 getPalette 的同步 JSON、ARGB 转 CSS、重新查询和授权边界；不新增页面设置功能描述 | 21 |
| 插件内 HTTP 批处理 | 对照隔离运行时权限入口与 HostBroker：普通鸿蒙插件单次上限 32，内部处理器容量 2,048；修正主规范与安全章节的混用，与网页桥区分 | 04、07、11、主规范 |
| 接口索引 | 对照 WebViewPage 注册的代理方法名与文档，未发现漏列；内部 HTTP 传输代理及状态辅助对象仍不作为第三方业务 API | 13、主规范 |

## 本版可复现验证

- `node examples/web-plugin-search/build.mjs` 生成自包含 HTML；帮助函数和成品脚本一致性、脚本语法纳入自检。
- `node tools/verify-guide.mjs` 通过：156 个文件，新增 11 项调用检查，既有 18 项后台服务检查、2,232 项契约配方、全部旧示例和 5 个插件包，以及 JSON、Schema 正则、文档链接、版本号和归档检查。
- 新增检查覆盖 32 容量滚动补位、旧应用 4 容量、列表共用、失败续行、超时不提前释放、停止与重新提交、独立 Base64 分片、图片索引分页、UTF-16 原文位置、未知总长、截断/偏移错误、内存预算与会话失效。
- `npm exec --offline --package=typescript -- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts` 通过。
- 发布 ZIP 逐文件读回，与目录内容核对；旧版文件路径全部保留，旧目录和归档不覆盖。
- 本轮仅更新开发指南及随包示例，未改应用代码，未重新构建或安装 HAP。源码核对和离线测试不代表真机联调完成。

## Ver1.1.6-1 验证记录（历史）

# Ver1.1.6-1 开发包验证说明

日期：2026-11-06。以 Ver1.1.6 全部 142 个文件为基线，保留全部原文件路径，新增每分钟传输示例和两组自检，共 145 个文件。应用版本仍为 1.1.5，插件 schemaVersion:1、SDK 1.0 不变。

## 本轮验证

- 对照当前 WebTransferTask、WebHttpServiceSession 和 WebViewPage 接口，使用 dataTransfer 方案，按先监听后注册的顺序，并说明本机网页、外部浏览器和应用的职责。
- 新增 recovering、recoveryAttempts 可选类型及 5/30/60 秒最多三次宿主恢复说明；网页不叠加重注册循环。
- 文档中实际 JavaScript 代码可解析；6 项代码块运行检查通过，覆盖启停顺序、注册失败回滚、非运行状态、分别清理失败重试、并发启动和外部请求取消。
- 普通示例 6 项生命周期检查和定时传输示例 6 项检查通过。定时传输覆盖真实字节、60 秒周期、平均速率、15 秒超时、停止和 pagehide 清理、旧请求迟到及无重叠。
- node tools/verify-guide.mjs 全部通过，包含上述 18 项检查、2,232 项既有契约配方、5 个插件示例包、JSON、Schema 正则、JavaScript、文档链接和网页归档核对。
- tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts 通过。
- 本轮只更新指南、示例和仓库文档；未改应用或内核，未重新安装或执行熄屏验证。用户报告数据传输测试约 10 分钟未冻结，仅记为该轮观察，不作为永久保活或速率阈值证明。
- 发布时对旧版本目录、ZIP 共 1,329 个文件核对 SHA-256；新 ZIP 逐项读回并与目录内容比对。旧发布包不覆盖。

## Ver1.1.6 及此前验证记录（历史）

# Ver1.1.6 开发包验证说明

日期：2026-11-06。基于完整 Ver1.1.5-2 的 138 个文件创建独立版本，保留全部基线文件路径，新增后台运行专章和测试示例的 HTML、说明、离线检查，共 142 个文件。指南版本为 1.1.6，应用仍为 1.1.5，插件包 `schemaVersion:1`、SDK `1.0` 不变。

## 1.1.6 核对与验证

- 对照当前 `WebTransferTask.ets`、`WebHttpServiceSession.ets` 和 `WebViewPage.ets`，核对显式任务申请、JSON 状态、成功后监听、初始通知失败清理、停止顺序、系统取消和实际字节更新；公开签名未变化。
- 对照 `WebBookService.ets` 与旧分组桥，确认均过滤未入架的临时书；旧接口的授权、返回结构和隐藏书处理保持原约定。相关宿主回归 63 项通过，覆盖网页服务、任务通知、书籍数据和旧书架分组；另有临时书入架、同步与备份的已有检查通过。
- 随包 `examples/web-http-service/lan-test.html` 与本轮设备验证的新版测试网页一致：用户确认可正常启动并在后台访问，电脑实测 HTTP 200，状态 JSON 的任务 `running:true`、`error` 为空。此记录针对该设备与示例，不保证任意网页空闲永久运行。
- 新示例的 6 项离线生命周期检查通过，覆盖申请 / 监听 / 停止顺序、状态返回、申请被拒、任务未运行、端口监听失败、清理重试和系统取消展示；使用桥接测试替身。
- `node tools/verify-guide.mjs` 通过，覆盖 142 个文件、2,232 项既有契约配方、全部既有示例、5 个插件包、JSON / Schema、JavaScript、文档链接及归档检查；新增示例检查已接入同一入口。
- `tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts` 通过。本次仅新增独立指南及示例，不修改应用版本号，不改变共享内核、协议字段或数据库。
- 发布时逐文件核对旧版目录与 ZIP 的 SHA-256，确认原版本未被覆盖；新 ZIP 逐项读回并与目录内容比对。

## Ver1.1.5-2 开发包验证记录（历史）

日期：2026-11-06。本版以完整 Ver1.1.5 的 136 个文件为基线，保留全部文件，新增书籍与长时任务、段评与动作回调专章，共 138 个文件；旧版目录及归档保留。开发指南版本 1.1.5-2，应用仍为 1.1.5，插件协议 `schemaVersion:1`、SDK `1.0` 未变。

## 1.1.5-2 核对与验证

- 对照网页代理与书籍数据、文件、入架、会话及长时任务实现，核对公开方法、JSON 信封、隐藏标记、导入元数据、原始章节、原始文件范围读取与进度交接。插件内容复用已有插件接口；入架复用原生方法。
- 长时任务明确使用 `MODE_DATA_TRANSFER` / `SUBMODE_LIVE_VIEW_NOTIFICATION`；成功 HTTP 收发才增加字节统计，关联实况通知最多每两秒更新一次，无周期性重新注册。文档区分真实传输、系统通知更新与空闲运行限制。
- `node tools/verify-guide.mjs` 通过：138 个文件、2,232 项契约配方、全部示例、5 个插件包、JSON / Schema / 链接与归档检查通过。
- `tsc --noEmit --lib es2022,dom types/fishreader-plugin.d.ts` 通过；新网页类型使用独立名称，保留原有内容插件类型。
- 宿主书籍数据、文件、入架、会话、长时任务、HTTP 及原生漫画 / 有声书回归检查共 165 项通过。覆盖排序先于分页、默认顺序兼容、同值稳定顺序、非法参数、原始导入数据不经排版、文件范围与路径边界、独立进度读写、原生入架委托、独占交接、旧 token 拒绝、后台任务清理及静默通知；HTTP 测试使用真实本机 TCP，桥接和系统服务使用测试替身。
- 删除此前草稿的网页专用分页 / 正文正规化、章节准备任务、图片解码、播放列表改写、固定章节缓存及预载。未新增阅读网页或应用固定 HTTP 业务路由。
- callback 扩展的 44 项检查通过，覆盖能力与入口声明、通用 input 传递、受控结果仅作为数据返回、4 并发共用、参数限制、过期引用、网页取消及销毁、权限拒绝传播，以及原有阅读图片动作。历史 1.1.2 记录中的“回调不开放”仅描述当时版本，本版已开放 callback。
- 阅读交接等待共用 4 秒预算，原生超时提示提供“返回 / 重试 / 跳过”。网页可显式使用 `takeover:true,skipCheckpoint:true`，使用最近保存进度接管；保留原写入队列与旧 token 拒绝规则。新增 15 项检查覆盖卡住的写入、排队超时、共享预算、跳过、关闭提示、取消及非 Error 异常；与书籍、HTTP、长时任务、漫画槽位及有声书回归合计 191 项全部通过。写入与释放实现已逐字核对，与本轮修改前一致。
- Harmony 默认 Debug HAP 完整构建通过。本轮未安装到设备；局域网实际访问、原生 / 网页交接、复杂 EPUB 显示和熄屏长时任务仍需真机验证。未新增浏览器阅读页面。

## Ver1.1.5 验证记录（历史）

日期：2026-11-04。本包以完整的 Ver1.1.2 开发包为底包，保留旧版示例、Schema、工具和历史章节，再增补 1.1.5 接口说明。应用源码当前声明 `versionName: 1.1.5` / `versionCode: 10115`；普通插件协议 `schemaVersion: 1`、建议 SDK `1.0` 均未改版。

## 当前接口与旧版兼容性核对

- 对照 `WebViewPage.ets`、`WebHttpServiceClient.ets`、`WebHttpServiceSession.ets`，确认已导入本地网页入口可用 `FishHttpService.listen()` / `closeAll()`；文档说明页面权限、请求与响应结构、局域网绑定、资源限制和生命周期。`FishHttpServiceNative` 与消息端口仅是内部传输协议。
- 对照 `HarmonySourcePluginService.ets`，确认 `catalog` 目录项接受可选 `updateTime`（最多 128 字符）；目录项与摘要的 `mediaType` 均接受 `file`。此前 1.1.2 类型声明已列出 `file`，但结果 Schema 漏列，本版已修正。
- 对照当前管理页文件选择实现与此前 50 个文件的接口说明，确认 `FishReader.ui.pickDataFiles()` 的单次上限改为 200；单文件 100 MiB 上限、分块读取和逐项错误语义仍适用。历史章节保留原版本说明，同时指向当前限制。
- 对照网页代理注册、网页内容插件桥和普通插件宿主操作，未发现旧版已公开方法被移除或改名；此次可确认的旧接口行为变化为多文件选择上限。网页桥仍限制为已导入的本地网页入口；商店专用及宿主内部辅助接口不计入公开契约。
- 普通插件宿主 `storage.set` / `source.setVariable` 在搜索执行通道中的持久化改为等待异步写入完成；公开调用本来就是异步返回，本包不承诺内部写入方式或未等待调用时的时序。需要先写后读时应等待调用结果。

## 本版可复现检查

- 在开发包根目录执行 `node tools/verify-guide.mjs`：通过，报告 136 个文件；包含 2,232 项契约配方、5 个示例插件包、网页与插件示例、Schema、链接、禁用术语、原生图形及共享文件归档检查。
- 在仓库根目录执行 `node --test scripts/tests/harmony-web-http-service.test.mjs scripts/tests/harmony-chapter-update-date.test.cjs scripts/tests/plugin-multi-file-import.test.mjs`：50 项通过。
- 当前包没有使用被用户排除的特定内容格式称呼，使用通用的“内容提供”与接口名称。
- 上述是源码核对和离线检查。本次未执行 HAP 构建、安装或真机联调；HTTP 服务的局域网连通、目录时间显示及 200 文件选择仍需设备验证。

## 1.1.2 验证记录（历史）

日期：2026-11-03。本开发包以 Ver1.1.1 正式包为底稿，其上游正式基线为 Ver0.9.6；不采用 Ver0.9.8 草稿。Ver1.1.2 同步规范和应用版本号，并新增已导入网页调用内容插件及书架导航的接口；其他公开接口沿用 Ver1.1.1。应用声明为 `versionName: 1.1.2` / `versionCode: 10112`，普通插件协议 `schemaVersion: 1` 不变。

## HTML 配色与内部接口核对

- `WebViewPage.ets` 注册 `FishReaderClub.getPalette()`，调用 `requireSavedBookPage()` 限定已导入本地网页入口主框架，返回同步 JSON 字符串；该方法本身不检查书架或阅读统计授权。
- `HtmlPlugin.ets` 在插件管理页控制器附着时注册同名 `FishReaderClub.getPalette()`，只开放这一方法；配色按与独立网页相同的外观设置、系统深色模式和字段计算，不暴露书架或阅读统计方法。
- 对照 `FishReaderAppearance.ets` 与 `currentPalette()`：返回 `darkMode` 和 13 个颜色字段，随应用外观设置及跟随系统深色模式计算；没有专用配色变更事件。颜色支持 `#RRGGBB` 与 ArkTS 顺序的 `#AARRGGBB`，CSS 示例进行了转换。
- `loadWebsiteStorage` / `saveWebsiteStorage` 由 `WebsiteStorageGlue.ets` 注入脚本调用；`FishReaderAudioStatistics.state` 由播放状态观察脚本调用。已在完整参考中列出内部用途及网页应使用的公开路径。

## 网页调用内容插件核对

- `WebViewPage.ets` 注册 `FishReaderPlugins` 的 `capabilities`、`listAsync` 和 `invokeAsync`，调用前沿用 `requireSavedBookPage()` 校验已导入本地入口主框架；执行期间结合网页生命周期与当前地址检查，避免删除、关闭或导航后继续返回结果。
- `WebpageContentPluginService.ets` 只列出已安装且启用的内容插件，只允许目标、搜索、发现、详情、目录、正文、图片处理与登录状态等数据入口；调用前再次核对插件声明。宿主缓存字段、管理、支付、回调和内部批量调度入口不开放。
- 调用复用 `HarmonySourcePluginService.executeSource()` 的隔离执行、插件网络权限及结果标准化；单次请求最多 1 MiB UTF-16 代码单元，同一网页最多 4 个并发调用。
- 内容结果标准化现在接受 `mediaType: "file"`，使本地网页能读取文件类详情的 `downloadUrls`；`video` 仍按原契约返回媒体地址。该桥不自动播放或下载。
- 独立执行 `normalizePluginMediaType` 验证 `video`、`file` 与大写 `FILE` 均被正确归一化，未知值仍被拒绝；类型声明的摘要和章节 `mediaType` 同步包含 `file`。
- `harmony-search-media-filter.test.cjs` 的 6 项检查通过：应用聚合搜索页仍按既有策略隐藏视频/文件结果；网页桥直接调用指定插件，不经过该展示筛选。

## 网页书架导航核对

- `WebViewPage.ets` 仅在已导入本地网页入口注册 `FishReaderClub.openBookshelfBookAsync(bookId)`，与 `bookshelfGroupsAsync()` 使用相同的页面校验和 `recommendations` 授权。
- `WebpageBookImportService.ets` 将书架 ID 交给应用书籍打开回调；原 `webpageBookOpenAsync(key)` 仍先按当前网页的导入标识查找，不能借此打开其他网页导入的书籍。
- `FishReaderAppShell.ets` 打开前刷新书架，核对 ID 仍存在，复用隐藏分组访问限制，并按当前书籍类型及本地/插件标志分流至阅读、漫画或有声书页面。
- 离线编译只能证明接口和路由能构建；仍需在设备上分别用文字、漫画、有声书、已移除书籍和未解锁的隐藏书籍验证导航结果。

## 0.9.8 草稿差异核对

本地 Ver0.9.8 目录及 ZIP 相对 Ver0.9.6 为新增 8 个文件、修改 23 个文件、未删除文件。实质增量集中在 `.fishweb` 的格式说明和示例；普通插件的 Schema 和 SDK 契约没有新字段。两版自检分别通过，但自检只覆盖静态文档、示例和归档结构，不能证明网页包在设备上完成导入与运行。

按用户提供的发布状态，Ver0.9.8 作为未发布草稿处理，不作为本版底包或兼容性承诺。草稿的版本页、更新记录和“0.9.8 起”描述会使读者误以为该版已正式发布；草稿也没有覆盖当前 1.1.2 源码中的 `.fishweb` Pro 导入/更新要求和包内相对图标。草稿写的“HTML 与 `.fishweb` 不能互相覆盖”只适用于文件选择器入口；现行通用网页资源桥允许双向转换，已在本版明确区分。经当前源码核对，ZIP 根目录入口、相对资源和主框架桥接规则可以纳入 1.1.2，已按现行行为整理为独立章节。仅靠本地档案无法确定 0.9.8 当时未发布的具体原因。

## 其他接口核对

- `FishNativeGPU`：对照 `WebViewPage.ets`、`WebGpuSession.ets`、原生 `protocol.h` / `renderer.cpp` 和通用 JS 帮助模块，核对入口权限、代理方法、二进制消息端口、77 个 opcode、能力字段、队列与回执边界；补齐颜色附件视图、原始子资源、缓冲读回、查询恢复及资源重置。
- `FishSharedFiles`：对照已注册网页代理、`WebSharedFilesSession.ets` 和通用 JS 帮助模块，核对根入口权限、声明、命名空间、端口消息、文件操作与大小上限；增加可导入示例及声明 Schema。
- 网页会话：对照 `WebViewPage.ets`、`BrowserSession.ets`、`OriginRequestRouter.ets`、`WebSyncHttpGateway.ets`，补齐以前完整网页参考未逐项展开的同步 HTTP 入口、会话 HTTP 和人工验证方法。
- 逐项比对独立网页代理注册的 40 个方法、其他网页代理注册方法与普通插件宿主的 16 个公开操作，确认文档中有对应方法名；网页私有持久化脚本辅助方法和内部状态观察器没有作为第三方接口发布。
- `.fishweb`：对照 `SubscriptionWebsiteStore.ets`、`WebpageResourceService.ets` 与 `FishWebPackageService.ets`，核对 Pro 导入、包内相对图标、资源桥流式下载/校验/更新；历史 ZIP 结构继续适用。
- 普通插件包协议 `schemaVersion: 1` 和建议插件 SDK `1.0` 未变；图形协议 `FGU1` 独立计版。

## 可复现离线检查

在开发包根目录运行 `node tools/verify-guide.mjs`：

- 开发包自检通过，报告 135 个文件。
- 插件与网页示例冒烟检查通过；契约配方覆盖 2,232 项。
- 5 个 `dist` 示例包通过静态校验；JSON、Schema 正则、JS 语法、版本号、相对链接及禁用术语检查通过。
- `.fishweb` 示例 ZIP 入口、包内图标与源文件一致；原生图形示例 ZIP、SPIR-V magic 和 `FGU1` 包头检查通过；共享文件示例 ZIP、声明和入口检查通过。
- 对照 `WebViewPage.ets` 与 `HtmlPlugin.ets` 的配色返回对象，`darkMode` 和 13 个颜色字段的名称及顺序完全一致。

在仓库根目录运行 `node --test scripts/tests/plugin-page-actions.test.mjs scripts/tests/plugin-multi-file-import.test.mjs`：23 项通过。新增书架导航接口后，鸿蒙默认 Debug HAP 构建成功，ArkTS 编译通过；构建仍有其他模块的警告。此前的构建已核对 `entry-default-unsigned.hap` 中 `pack.info` 与 `module.json` 的应用版本为 `1.1.2` / `10112`。此前的一次版本号构建曾遇到 `build.log` 的 `EBUSY` 文件占用，原样重试后通过。

此前运行 `node --test scripts/tests/harmony-browser-session.test.cjs scripts/tests/harmony-external-html-import.test.cjs scripts/tests/harmony-website-update-menu.test.cjs scripts/tests/harmony-subscription-website-refresh.test.cjs`：16 项中 15 项通过。失败项为 `fishweb import requires Pro before reading or installing the package`：测试替身缺少 `runTask`，在会员错误断言前抛出 `TypeError`；该测试与本次 `HtmlPlugin.ets` 配色桥变更无关。图形工具的 `sdk_test.mjs`、`checkpoint_resources_test.mjs` 和 `compact_completion_test.mjs` 均通过。

构建与离线检查不等于真机验收；`openBookshelfBookAsync` 的三类书籍导航、`FishReaderPlugins` 的实际页面调用、复杂插件的完整内容获取链路、插件管理页配色读取及外观切换后的重新读取仍需在目标设备上验证。
