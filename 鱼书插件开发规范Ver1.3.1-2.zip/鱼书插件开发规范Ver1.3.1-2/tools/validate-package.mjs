import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import vm from 'node:vm';
import crypto from 'node:crypto';

const fileArg = process.argv[2];
if (!fileArg) {
  console.error('用法：node tools/validate-package.mjs <插件包.fishplugin.json>');
  process.exit(2);
}

const errors = [];
const warnings = [];
const filePath = path.resolve(fileArg);
const bytes = fs.readFileSync(filePath);
if (bytes.length < 1) errors.push('文件为空');
if (bytes.length > 100 * 1024 * 1024) errors.push('插件包超过 100 MiB');

let pkg;
try { pkg = JSON.parse(bytes.toString('utf8')); }
catch (error) { errors.push('不是有效 UTF-8 JSON：' + error.message); }

const stableId = /^[A-Za-z0-9._:-]{8,128}$/;
const semver = /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-[0-9A-Za-z.-]+)?$/;
const domain = /^(?:\*\.)?(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?))*$/;
const modulePath = /^[A-Za-z0-9._/-]+\.(?:m?js|html?)$/;
const urlScheme = /^[a-z][a-z0-9+.-]{0,31}$/;
const reservedSchemes = new Set(['http', 'https', 'file', 'content', 'data', 'javascript', 'about', 'blob', 'resource', 'chrome', 'devtools', 'intent', 'mailto', 'tel', 'sms', 'market', 'magnet', 'fishreader']);
const publicKinds = new Set(['source', 'dictionary', 'tts']);
const publicEntrypoints = new Set([
  'searchTargets', 'searchPrepareBatch', 'searchParseBatch', 'searchBatch',
  'manageSearchTarget', 'permissionGroups', 'search', 'exploreMenu', 'explore',
  'detail', 'reviews', 'catalog', 'content', 'image', 'payAction', 'callback',
  'dictionary', 'ttsVoices', 'ttsSynthesize',
  'loginCheck', 'manage', 'ui'
]);

if (pkg) {
  if (pkg.schemaVersion !== 1) errors.push('顶层 schemaVersion 必须为 1');
  if (!pkg.manifest || typeof pkg.manifest !== 'object' || Array.isArray(pkg.manifest)) errors.push('缺少 manifest');
  if (typeof pkg.source !== 'string' || pkg.source.length < 1) errors.push('缺少 source');
  if (typeof pkg.source === 'string' && Buffer.byteLength(pkg.source, 'utf8') > 4 * 1024 * 1024) errors.push('主模块超过 4 MiB');

  const m = pkg.manifest || {};
  const sourceFormat = m.sourceFormat || 'fishreader-js';
  if (m.schemaVersion !== 1) errors.push('manifest.schemaVersion 必须为 1');
  if (!stableId.test(m.pluginId || '')) errors.push('pluginId 不合法');
  if (typeof m.name !== 'string' || !m.name.trim()) errors.push('name 不能为空');
  if (!semver.test(m.version || '')) errors.push('version 必须是 SemVer');
  if (!/^\d+\.\d+$/.test(m.sdkVersion || '')) errors.push('sdkVersion 格式应为 1.0');
  if (!['fishreader-js', 'fishreader-html'].includes(sourceFormat)) errors.push('sourceFormat 不属于第三方公开格式');
  if (!Array.isArray(m.entrypoints) || m.entrypoints.length < 1) errors.push('entrypoints 必须是非空数组');
  if (Array.isArray(m.entrypoints) && new Set(m.entrypoints).size !== m.entrypoints.length) errors.push('entrypoints 不能重复');
  if (Array.isArray(m.entrypoints)) {
    for (const name of m.entrypoints) if (!publicEntrypoints.has(name)) errors.push(`入口 ${name} 未在 1.3.1-2 第三方规范中公开`);
  }
  const kinds = Array.isArray(m.pluginKinds) && m.pluginKinds.length
    ? m.pluginKinds
    : (sourceFormat === 'fishreader-html' ? [] : ['source']);
  for (const kind of kinds) if (!publicKinds.has(kind)) errors.push(`插件类型 ${kind} 未在 1.3.1-2 第三方规范中公开`);
  const required = [];
  if (kinds.includes('source')) required.push('search', 'detail', 'catalog', 'content');
  if (kinds.includes('dictionary')) required.push('dictionary');
  if (kinds.includes('tts')) required.push('ttsVoices', 'ttsSynthesize');
  for (const name of required) if (!m.entrypoints?.includes(name)) errors.push(`缺少必需入口 ${name}`);
  if (!m.permissions || !Array.isArray(m.permissions.networkDomains)) errors.push('permissions.networkDomains 必须是数组');
  for (const field of ['networkDomains', 'redirectDomains']) {
    const values = m.permissions?.[field] || [];
    if (!Array.isArray(values)) errors.push(`permissions.${field} 必须是数组`);
    else {
      if (new Set(values).size !== values.length) errors.push(`permissions.${field} 不能重复`);
      for (const value of values) if (typeof value !== 'string' || !domain.test(value)) errors.push(`非法域名：${value}`);
    }
  }
  if (m.permissions?.loginBrowser === true &&
      (m.permissions.cookieScope !== true || !m.loginUrl)) {
    errors.push('loginBrowser 需要 cookieScope: true 和 loginUrl');
  }
  if (m.webPageActions !== undefined && typeof m.webPageActions !== 'boolean') errors.push('webPageActions 必须是布尔值');
  if (m.webPageActions === true && (!m.entrypoints?.includes('manage') || !m.entrypoints?.includes('ui'))) {
    errors.push('webPageActions 需要 manage 和 ui 入口');
  }
  if (m.fileImport !== undefined) {
    const declaration = m.fileImport;
    const validObject = declaration && typeof declaration === 'object' && !Array.isArray(declaration) &&
      Object.keys(declaration).every(key => ['extensions', 'entrypoint'].includes(key));
    const extensions = validObject ? declaration.extensions : undefined;
    if (!validObject || sourceFormat === 'fishreader-html' || !kinds.includes('source') ||
        !m.entrypoints?.includes('ui') || !m.managementModule ||
        typeof declaration.entrypoint !== 'string' ||
        !/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(declaration.entrypoint) ||
        !Array.isArray(extensions) || extensions.length < 1 || extensions.length > 16 ||
        new Set(extensions).size !== extensions.length ||
        extensions.some(value => typeof value !== 'string' ||
          !/^\.[a-z0-9]{1,16}(?:\.[a-z0-9]{1,16}){0,2}$/.test(value))) {
      errors.push('fileImport 声明无效或缺少内容插件管理页');
    }
  }
  if (m.ttsPackages !== undefined) {
    const d = m.ttsPackages;
    const plain = value => value && typeof value === 'object' && !Array.isArray(value);
    const only = (value, keys) => Object.keys(value).every(key => keys.includes(key));
    const directory = value => typeof value === 'string' && value.length > 0 && value.length <= 80 &&
      value === value.trim() && !/[\\/:\x00-\x1f]/.test(value) && value !== '.' && value !== '..' &&
      !/[. ]$/.test(value) && !['packs', 'installed', 'cache', 'staging', 'inbox'].includes(value.toLowerCase());
    const formats = value => Array.isArray(value) && value.length >= 1 && value.length <= 3 &&
      new Set(value).size === value.length && value.every(item => ['multitts', 'vits', 'matcha'].includes(item));
    if (!plain(d) || !only(d, ['directoryName', 'formats', 'categories', 'migration', 'runtime']) ||
        !kinds.includes('tts') || !directory(d.directoryName) ||
        (d.formats === undefined && d.categories === undefined) ||
        (d.formats !== undefined && !formats(d.formats))) {
      errors.push('ttsPackages 顶层声明无效或插件类型不是 tts');
    } else {
      if (d.categories !== undefined) {
        const ids = new Set(), names = new Set();
        if (!Array.isArray(d.categories) || d.categories.length < 1 || d.categories.length > 32) {
          errors.push('ttsPackages.categories 数量无效');
        } else for (const item of d.categories) {
          if (!plain(item) || !only(item, ['categoryId', 'name', 'directoryName', 'formats']) ||
              typeof item.categoryId !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(item.categoryId) ||
              typeof item.name !== 'string' || !item.name || item.name.length > 128 ||
              !directory(item.directoryName) || !formats(item.formats) ||
              ids.has(item.categoryId) || names.has(String(item.directoryName).toLowerCase())) {
            errors.push('ttsPackages 分类声明无效或重复');
          } else { ids.add(item.categoryId); names.add(item.directoryName.toLowerCase()); }
        }
      }
      if (d.migration !== undefined && (!plain(d.migration) || !only(d.migration, ['id', 'fromDirectory']) ||
          typeof d.migration.id !== 'string' || !/^[A-Za-z0-9._-]{1,64}$/.test(d.migration.id) ||
          typeof d.migration.fromDirectory !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(d.migration.fromDirectory))) {
        errors.push('ttsPackages.migration 声明无效');
      }
      if (d.runtime !== undefined) {
        const runtime = d.runtime;
        const codes = runtime?.engineCodes;
        if (!plain(runtime) || !only(runtime, ['engineCodes', 'engineTypes', 'streaming']) ||
            !Array.isArray(codes) || codes.length > 128 ||
            codes.some(code => typeof code !== 'string' || !/^[A-Za-z0-9._-]{1,128}$/.test(code)) ||
            new Set(codes).size !== codes.length ||
            (runtime.engineTypes !== undefined &&
              (!Array.isArray(runtime.engineTypes) || runtime.engineTypes.length > 1 ||
               runtime.engineTypes.some(type => type !== 'http'))) ||
            (runtime.streaming !== undefined && typeof runtime.streaming !== 'boolean')) {
          errors.push('ttsPackages.runtime 声明无效');
        }
      }
    }
  }
  if (m.urlSchemes !== undefined) {
    if (!Array.isArray(m.urlSchemes) || m.urlSchemes.length > 16 || new Set(m.urlSchemes).size !== m.urlSchemes.length) {
      errors.push('urlSchemes 必须是最多 16 个不重复的协议名');
    } else {
      for (const scheme of m.urlSchemes) {
        if (typeof scheme !== 'string' || !urlScheme.test(scheme) || reservedSchemes.has(scheme)) errors.push(`非法 urlSchemes 协议名：${scheme}`);
      }
    }
    if (!m.entrypoints?.includes('ui')) errors.push('urlSchemes 需要 ui 入口');
  }
  if (m.loginUrl && !/^https?:\/\//i.test(m.loginUrl)) errors.push('loginUrl 必须是 HTTP(S) 绝对地址');
  if (m.loginUrl && Array.isArray(m.permissions?.networkDomains)) {
    try {
      const host = new URL(m.loginUrl).hostname.toLowerCase();
      const allowed = m.permissions.networkDomains.some(rule => {
        const value = String(rule).toLowerCase();
        return value.startsWith('*.')
          ? host.endsWith('.' + value.slice(2))
          : host === value;
      });
      if (!allowed) errors.push('loginUrl 域名必须包含在 permissions.networkDomains 中');
    } catch (_) {}
  }
  if (m.contentHash !== undefined) {
    const actualHash = typeof pkg.source === 'string'
      ? 'sha256:' + crypto.createHash('sha256').update(pkg.source, 'utf8').digest('hex')
      : '';
    if (m.contentHash !== actualHash) errors.push('manifest.contentHash 与主模块不一致');
  }
  if (Array.isArray(m.exploreCategories) && m.exploreCategories.length > 0 && !m.entrypoints?.includes('explore')) {
    errors.push('exploreCategories 需要 explore 入口');
  }
  if (m.exploreCategories !== undefined && !Array.isArray(m.exploreCategories)) {
    errors.push('exploreCategories 必须是数组');
  }
  if (Array.isArray(m.exploreCategories)) {
    if (m.exploreCategories.length < 1 || m.exploreCategories.length > 64) errors.push('exploreCategories 必须有 1 到 64 项');
    const categoryKeys = m.exploreCategories.map(value => value && value.key);
    if (new Set(categoryKeys).size !== categoryKeys.length) errors.push('exploreCategories.key 不能重复');
  }
  if (sourceFormat !== 'fishreader-html' && m.entrypoints?.includes('ui') && !m.managementModule) {
    errors.push('ui 入口需要 managementModule');
  }
  if (m.managementModule && (!m.entrypoints?.includes('ui') || !pkg.modules?.[m.managementModule])) {
    errors.push('managementModule 需要 ui 入口，并在 modules 中包含对应 HTML');
  }
  const moduleNames = pkg.modules && typeof pkg.modules === 'object' && !Array.isArray(pkg.modules)
    ? Object.keys(pkg.modules)
    : [];
  if (m.managementModule &&
      (moduleNames.length !== 1 || moduleNames[0] !== m.managementModule)) {
    errors.push('modules 必须只包含 managementModule 声明的页面');
  }
  if (sourceFormat === 'fishreader-html' && !m.entrypoints?.includes('ui')) {
    errors.push('fishreader-html 插件必须声明 ui 入口');
  }
  if (sourceFormat === 'fishreader-html' && (m.entrypoints?.length !== 1 || m.entrypoints[0] !== 'ui')) {
    errors.push('fishreader-html 只允许 ui 入口');
  }
  if (sourceFormat === 'fishreader-html' && m.managementModule) {
    errors.push('fishreader-html 不使用 managementModule');
  }
  if (sourceFormat === 'fishreader-html' && moduleNames.length > 0) {
    errors.push('fishreader-html 不使用附加 modules');
  }
  if (sourceFormat === 'fishreader-html' && !/\.html?$/i.test(m.entryModule || '')) {
    errors.push('fishreader-html 的 entryModule 必须指向 HTML 文件');
  }
  if (sourceFormat !== 'fishreader-html' && !/\.m?js$/i.test(m.entryModule || '')) {
    errors.push('JavaScript 插件的 entryModule 必须指向 .js 或 .mjs 文件');
  }
  for (const [field, value] of [['entryModule', m.entryModule], ['managementModule', m.managementModule]]) {
    if (value === undefined && field === 'managementModule') continue;
    if (typeof value !== 'string' || value.length > 512 || !modulePath.test(value) ||
        value.startsWith('/') || value.includes('\\') || value.split('/').includes('..')) {
      errors.push(`${field} 路径不合法`);
    }
  }
  if (m.managementModule && m.managementModule === m.entryModule) errors.push('managementModule 不能与 entryModule 相同');
  if (pkg.modules && typeof pkg.modules === 'object') {
    for (const [name, value] of Object.entries(pkg.modules)) {
      if (typeof value !== 'string') errors.push(`模块 ${name} 不是字符串`);
      else if (Buffer.byteLength(value, 'utf8') > 4 * 1024 * 1024) errors.push(`模块 ${name} 超过 4 MiB`);
    }
  }

  if (typeof pkg.source === 'string' && sourceFormat !== 'fishreader-html') {
    const moduleObject = { exports: {} };
    try {
      vm.runInNewContext(pkg.source, {
        module: moduleObject,
        exports: moduleObject.exports,
        reader: Object.freeze({}),
        URL,
        TextEncoder,
        TextDecoder,
        console: Object.freeze({ log() {}, warn() {}, error() {} })
      }, { timeout: 1000, filename: m.entryModule || 'plugin.js' });
      for (const name of m.entrypoints || []) {
        if (['ui'].includes(name)) continue;
        if (typeof moduleObject.exports[name] !== 'function') errors.push(`代码未导出函数 ${name}`);
      }
    } catch (error) {
      errors.push('主模块加载失败：' + error.message);
    }
  }
}

for (const warning of warnings) console.warn('警告：' + warning);
if (errors.length) {
  for (const error of errors) console.error('错误：' + error);
  process.exit(1);
}
console.log(`校验通过：${filePath}`);
