import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function run(script, args = []) {
  const result = spawnSync(process.execPath, [path.join(root, script), ...args], {
    cwd: root,
    encoding: 'utf8'
  });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${script} 失败`);
}

const files = walk(root);

for (const requiredFile of [
  'schemas/plugin/image-result.schema.json',
  'schemas/plugin/action-result.schema.json',
  'schemas/plugin/reviews-result.schema.json',
  'schemas/plugin/tts-packages.schema.json',
  'schemas/plugin/web-video-playback-request.schema.json',
  'schemas/plugin/webpage-resource-http-request.schema.json',
  'schemas/plugin/webpage-resource-package-request.schema.json',
  'schemas/plugin/web-media-status.schema.json',
  'schemas/web/shared-files.schema.json',
  'examples/web-import-basic/index.html',
  'examples/fishweb-basic/fishweb-basic.fishweb',
  'examples/native-gpu-basic/native-gpu-basic.fishweb',
  'examples/native-gpu-basic/fish-native-gpu.mjs',
  'examples/shared-files-basic/shared-files-basic.fishweb',
  'examples/shared-files-basic/fish-shared-files.mjs',
  'docs/17-1.1.2-fishweb网页包.md',
  'docs/18-1.1.2-Vulkan图形接口.md',
  'docs/19-1.1.2-共享文件接口.md',
  'docs/20-1.1.2-网页会话与验证接口.md',
  'docs/21-1.1.2-HTML主题配色.md',
  'docs/22-1.1.2-网页调用内容插件.md',
  'docs/23-1.1.2-网页书架导航.md',
  'docs/24-1.1.5接口增补.md',
  'docs/25-1.1.5-2书籍与长时任务接口.md',
  'docs/26-1.1.5-2段评与动作回调.md',
  'docs/27-1.1.6网页服务后台运行.md',
  'docs/28-1.1.7网页请求容量与滚动补位.md',
  'docs/29-1.1.7书籍图片与PDF数据读取.md',
  'docs/30-1.1.7-2书评接口.md',
  'docs/31-1.1.9-TTS语音包接口.md',
  'docs/32-1.2.1书籍专属音色与音频时间轴.md',
  'docs/33-1.2.5网页弹幕列表与插件页面视频桥.md',
  'docs/34-1.2.8语音包下载导入.md',
  'docs/35-1.2.8网页弹幕表情映射.md',
  'schemas/plugin/tts-package-download-request.schema.json',
  'schemas/plugin/web-video-danmaku-list-response.schema.json',
  'docs/36-1.3.1-TTS插件运行时与音频流.md',
  'docs/37-1.3.1插件WebSocket会话.md',
  'schemas/plugin/tts-package-runtime-result.schema.json',
  'docs/38-1.3.1-2语音包音色目录与内联音频.md',
  'docs/39-1.3.1-2本地网页调用TTS与音频流.md',
  'schemas/plugin/webpage-tts-invoke-request.schema.json',
  'schemas/plugin/webpage-tts-stream-result.schema.json',
  'examples/web-plugin-search/README.md',
  'examples/web-plugin-search/client.js',
  'examples/web-plugin-search/template.html',
  'examples/web-plugin-search/index.html',
  'examples/web-plugin-search/build.mjs',
  'examples/web-plugin-search/smoke-test.cjs',
  'examples/book-resources/README.md',
  'examples/book-resources/resources.js',
  'examples/book-resources/smoke-test.cjs',
  'examples/web-http-service/README.md',
  'examples/web-http-service/lan-test.html',
  'examples/web-http-service/smoke-test.mjs',
  'examples/web-http-service/lan-transfer-test.html',
  'examples/web-http-service/transfer-smoke-test.mjs',
  'examples/web-http-service/guide-snippets.test.mjs',
  'docs/plugins/discover-filters.md',
  'docs/12-0.7.9接口增补.md',
  'docs/13-网页接口完整参考.md',
  'docs/14-0.9.1接口增补.md',
  'docs/15-0.9.5接口增补.md',
  'docs/16-0.9.6接口增补.md'
]) {
  if (!fs.existsSync(path.join(root, requiredFile))) throw new Error(`缺少 ${requiredFile}`);
}

const requiredVersionFiles = [
  'README.md',
  'CHANGELOG.md',
  'docs/plugins/package-format.md',
  'schemas/README.md',
  'types/fishreader-plugin.d.ts',
  'tools/validate-package.mjs',
  'docs/plugins/development-guide.md',
  'docs/plugins/result-contracts.md'
];
for (const name of requiredVersionFiles) {
  const source = fs.readFileSync(path.join(root, name), 'utf8');
  if (!source.includes('1.3.1-2')) throw new Error(`${name} 未同步到规范版本 1.3.1-2`);
}
if (!fs.readFileSync(path.join(root, 'README.md'), 'utf8').includes('发布日期：2026-11-19')) {
  throw new Error('README 发布日期未更新');
}
if (/themes\s*\(/.test(fs.readFileSync(path.join(root, 'docs/plugins/package-format.md'), 'utf8'))) {
  throw new Error('插件包格式误将主题入口写为公开能力');
}

for (const file of files.filter(file => file.endsWith('.md'))) {
  const content = fs.readFileSync(file, 'utf8');
  let inCode = false;
  for (const line of content.split(/\r?\n/)) {
    if (/^\s*```/.test(line)) { inCode = !inCode; continue; }
    if (inCode) continue;
    for (const [, rawTarget] of line.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
      const localTarget = rawTarget.split('#', 1)[0];
      if (!localTarget || /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(localTarget)) continue;
      const resolved = path.resolve(path.dirname(file), decodeURIComponent(localTarget));
      if (!fs.existsSync(resolved)) throw new Error(`${path.relative(root, file)} 的链接不存在：${rawTarget}`);
    }
  }
}

for (const file of files.filter(file => file.endsWith('.json'))) {
  JSON.parse(fs.readFileSync(file, 'utf8'));
}

for (const file of files.filter(file => file.endsWith('.schema.json'))) {
  const schema = JSON.parse(fs.readFileSync(file, 'utf8'));
  const visit = value => {
    if (!value || typeof value !== 'object') return;
    if (typeof value.pattern === 'string') new RegExp(value.pattern);
    for (const child of Object.values(value)) visit(child);
  };
  visit(schema);
}

const htmlGuide = fs.readFileSync(path.join(root, 'docs/10-网页接口.md'), 'utf8');
const managementGuide = fs.readFileSync(path.join(root, 'docs/05-管理页面与登录.md'), 'utf8');
const mainGuide = fs.readFileSync(path.join(root, 'docs/plugins/development-guide.md'), 'utf8');
const videoGuide = fs.readFileSync(path.join(root, 'docs/web-video-bridge.md'), 'utf8');
const declarations = fs.readFileSync(path.join(root, 'types/fishreader-plugin.d.ts'), 'utf8');
const videoSchema = fs.readFileSync(path.join(root, 'schemas/plugin/web-video-playback-request.schema.json'), 'utf8');
for (const [name, source, required] of [
  ['网页接口', htmlGuide, ['localStorage', '.capabilities', 'respondEpisode', 'episodeRequestEvent', 'progressIntervalSeconds']],
  ['主规范', mainGuide, ['网页条目 ID + 当前页面 Origin', 'prefetchNextSeconds', 'startPositionMs', 'refreshEvent']],
  ['视频协议', videoGuide, ['inlineEpisodeRequest', "purpose: 'prefetch'", 'updatedAt', 'sequence', 'ivHex']],
  ['类型声明', declarations, ['FishReaderWebVideoCapabilities', 'FishReaderWebVideoEpisodeResponse', 'respondEpisode?', 'defaultIvHex']],
  ['视频 Schema', videoSchema, ['episodeRequestEvent', 'prefetchNextSeconds', 'startPositionMs', 'defaultIvHex']]
]) {
  for (const token of required) if (!source.includes(token)) throw new Error(`${name} 缺少既有内容：${token}`);
}
const additions = fs.readFileSync(path.join(root, 'docs/12-0.7.9接口增补.md'), 'utf8');
for (const token of ['fileImport', 'registerFileImport', 'mediaEncryption', 'verificationJavaScript',
  'FishReaderDiscover', 'playInline', 'respondDanmaku']) {
  if (!additions.includes(token)) throw new Error(`0.7.9 增补缺少 ${token}`);
}
const currentAdditions = fs.readFileSync(path.join(root, 'docs/14-0.9.1接口增补.md'), 'utf8');
const priorAdditions = fs.readFileSync(path.join(root, 'docs/15-0.9.5接口增补.md'), 'utf8');
const latestAdditions = fs.readFileSync(path.join(root, 'docs/16-0.9.6接口增补.md'), 'utf8');
const completeWebGuide = fs.readFileSync(path.join(root, 'docs/13-网页接口完整参考.md'), 'utf8');
const backgroundGuide = fs.readFileSync(path.join(root, 'docs/27-1.1.6网页服务后台运行.md'), 'utf8');
const reviewsGuide = fs.readFileSync(path.join(root, 'docs/30-1.1.7-2书评接口.md'), 'utf8');
for (const token of ['reviews', 'sourceKey', 'bookKey', 'bookUrl', 'pageSize', 'nextCursor', '100', 'FishReaderPlugins', 'filterKey', 'selectedFilterKey']) {
  if (!reviewsGuide.includes(token)) throw new Error(`书评接口说明缺少 ${token}`);
}
for (const [, code] of reviewsGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(code);
for (const name of ['source-plugin-manifest.schema.json', 'execution-request.schema.json']) {
  const schema = fs.readFileSync(path.join(root, 'schemas/plugin', name), 'utf8');
  if (!schema.includes('"reviews"')) throw new Error(`${name} 缺少 reviews 入口`);
}
const reviewSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/reviews-result.schema.json'), 'utf8'));
if (!reviewSchema.required.includes('items') || !reviewSchema.required.includes('hasMore') ||
    reviewSchema.properties.items.maxItems !== 100 ||
    reviewSchema.properties.items.items.properties.content.maxLength !== 32768 ||
    reviewSchema.properties.filters.maxItems !== 64) {
  throw new Error('书评结果 Schema 与宿主上限不一致');
}
if (!declarations.includes('FishReaderBookReviewPage') || !declarations.includes('FishReaderReviewsInput')) {
  throw new Error('书评类型声明缺失');
}
const ttsGuide = fs.readFileSync(path.join(root, 'docs/31-1.1.9-TTS语音包接口.md'), 'utf8');
for (const token of ['ttsPackages', 'directoryName', 'categories', 'migration', 'scan', 'importFiles',
  'snapshot', 'preview', 'stopPreview', 'local-model', 'tts-package', 'ttsModels.catalog.v1']) {
  if (!ttsGuide.includes(token)) throw new Error(`TTS 语音包说明缺少 ${token}`);
}
for (const [, code] of ttsGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(`(async () => {\n${code}\n})`);
for (const [, json] of ttsGuide.matchAll(/```json\r?\n([\s\S]*?)```/g)) JSON.parse(json);
const ttsDeclaration = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-packages.schema.json'), 'utf8'));
const ttsSynthesis = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-synthesis-result.schema.json'), 'utf8'));
if (!ttsDeclaration.required.includes('directoryName') || ttsDeclaration.properties.categories.maxItems !== 32 ||
    !ttsSynthesis.oneOf.some(value => value.properties?.kind?.const === 'local-model') ||
    !ttsSynthesis.oneOf.some(value => value.properties?.kind?.const === 'tts-package') ||
    !declarations.includes('FishReaderTtsPackagesBridge')) throw new Error('TTS 语音包契约不完整');
const bookVoiceGuide = fs.readFileSync(path.join(root, 'docs/32-1.2.1书籍专属音色与音频时间轴.md'), 'utf8');
for (const token of ['bookContext', "scope:'book'", "mode:'text'", "mode:'chapter'", 'customVariable', 'audioTimeline', '4,096', '262,144']) {
  if (!bookVoiceGuide.includes(token)) throw new Error(`1.2.1 接口说明缺少 ${token}`);
}
for (const [, code] of bookVoiceGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(code);
const voiceSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-voices-result.schema.json'), 'utf8'));
const contentSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/content-result.schema.json'), 'utf8'));
if (voiceSchema.maxItems !== 256 ||
    !voiceSchema.items.properties.scope.enum.includes('book') ||
    !voiceSchema.items.properties.mode.enum.includes('chapter') ||
    !voiceSchema.items.allOf.some(rule => rule.if?.properties?.mode?.const === 'chapter' && rule.then?.properties?.scope?.const === 'book') ||
    contentSchema.properties.audioTimeline.properties.version.const !== 1 ||
    contentSchema.properties.audioTimeline.properties.cues.maxItems !== 4096 ||
    contentSchema.properties.audioTimeline.properties.cues.items.properties.text.maxLength !== 8192 ||
    !contentSchema.allOf.some(rule => rule.if?.required?.includes('audioTimeline') && rule.then?.properties?.contentType?.const === 'audio') ||
    !declarations.includes('FishReaderBookVoiceContext') ||
    !declarations.includes('FishReaderAudioTimeline')) throw new Error('1.2.1 契约或类型声明不完整');
const danmakuGuide = fs.readFileSync(path.join(root, 'docs/33-1.2.5网页弹幕列表与插件页面视频桥.md'), 'utf8');
for (const token of ['danmaku.loadEvent', 'respondDanmakuList', 'progressKey', 'durationMs', 'timeMs', '10,000', '30 秒', 'fishreader-html']) {
  if (!danmakuGuide.includes(token)) throw new Error(`1.2.5 网页弹幕说明缺少 ${token}`);
}
for (const [, code] of danmakuGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(code);
const playbackSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/web-video-playback-request.schema.json'), 'utf8'));
if (playbackSchema.$defs.danmaku.properties.loadEvent?.maxLength !== 120 ||
    !declarations.includes('FishReaderWebVideoDanmakuLoadDetail') ||
    !declarations.includes('FishReaderWebVideoDanmakuLoadResponse') ||
    !declarations.includes('respondDanmakuList?') ||
    !declarations.includes('danmakuLoadEvent?') ||
    !videoGuide.includes('respondDanmakuList') ||
    fs.readFileSync(path.join(root, 'docs/12-0.7.9接口增补.md'), 'utf8').includes('此页面只提供 `play`')) {
  throw new Error('1.2.5 网页播放器契约或旧章节修订不完整');
}
const downloadGuide = fs.readFileSync(path.join(root, 'docs/34-1.2.8语音包下载导入.md'), 'utf8');
for (const token of ['ttsPackages.download', 'downloadImport', 'maximumDownloadBytes', 'categoryId', 'sha256', 'parts', '67,108,864']) {
  if (!downloadGuide.includes(token)) throw new Error(`1.2.8 语音包下载说明缺少 ${token}`);
}
for (const [, code] of downloadGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(`(async () => {\n${code}\n})`);
const downloadSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-package-download-request.schema.json'), 'utf8'));
if (!downloadSchema.required.includes('sha256') || downloadSchema.properties.size.maximum !== 67108864 ||
    downloadSchema.properties.parts.maxItems !== 128 || downloadSchema.$defs.part.properties.size.maximum !== 10485760 ||
    !declarations.includes('FishReaderTtsPackageDownloadRequest') || !declarations.includes('download?(args:')) {
  throw new Error('1.2.8 语音包下载契约不完整');
}
const emoteGuide = fs.readFileSync(path.join(root, 'docs/35-1.2.8网页弹幕表情映射.md'), 'utf8');
for (const token of ['respondDanmakuList', 'emotes', 'data:image/png;base64,', '64', '80,000']) {
  if (!emoteGuide.includes(token)) throw new Error(`1.2.8 弹幕表情说明缺少 ${token}`);
}
for (const [, code] of emoteGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(code);
const danmakuSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/web-video-danmaku-list-response.schema.json'), 'utf8'));
if (danmakuSchema.properties.emotes.maxProperties !== 64 ||
    danmakuSchema.properties.emotes.additionalProperties.maxLength !== 80000 ||
    !declarations.includes('emotes?: Record<string, string>')) {
  throw new Error('1.2.8 弹幕表情契约不完整');
}
const runtimeGuide = fs.readFileSync(path.join(root, 'docs/36-1.3.1-TTS插件运行时与音频流.md'), 'utf8');
const socketGuide = fs.readFileSync(path.join(root, 'docs/37-1.3.1插件WebSocket会话.md'), 'utf8');
for (const token of ['package-synthesize', 'runtime.streaming', 'audioStream.configure', 'audioStream.fetch', 'audio-stream']) {
  if (!runtimeGuide.includes(token)) throw new Error(`1.3.1 音频流说明缺少 ${token}`);
}
for (const token of ['socket.open', 'socket.send', 'socket.read', 'socket.close', 'wss://']) {
  if (!socketGuide.includes(token)) throw new Error(`1.3.1 WebSocket 说明缺少 ${token}`);
}
for (const source of [runtimeGuide, socketGuide]) {
  for (const [, code] of source.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(`(async () => {\n${code}\n})`);
}
const ttsPackagesSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-packages.schema.json'), 'utf8'));
const runtimeResultSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-package-runtime-result.schema.json'), 'utf8'));
if (!ttsPackagesSchema.properties.runtime.properties.streaming ||
    runtimeResultSchema.oneOf[1].properties.kind.const !== 'audio-stream' ||
    !declarations.includes('FishReaderPackageSynthesisInput') ||
    !declarations.includes('audioStream: {') ||
    !declarations.includes('socket: {')) {
  throw new Error('1.3.1 语音包与 WebSocket 契约不完整');
}
const catalogGuide = fs.readFileSync(path.join(root, 'docs/38-1.3.1-2语音包音色目录与内联音频.md'), 'utf8');
const webpageTtsGuide = fs.readFileSync(path.join(root, 'docs/39-1.3.1-2本地网页调用TTS与音频流.md'), 'utf8');
for (const token of ['ttsPackages.voices', 'ttsPackages.resolveVoice', 'audio-base64', '5 MiB']) {
  if (!catalogGuide.includes(token)) throw new Error(`1.3.1-2 TTS 音色与音频说明缺少 ${token}`);
}
for (const token of ["pluginKinds:['tts']", "output:'stream'", 'streamStatusAsync', 'closeStreamAsync', 'audio-stream']) {
  if (!webpageTtsGuide.includes(token)) throw new Error(`1.3.1-2 网页 TTS 说明缺少 ${token}`);
}
for (const source of [catalogGuide, webpageTtsGuide]) {
  for (const [, code] of source.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(`(async () => {\n${code}\n})`);
}
const ttsSynthesisSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/tts-synthesis-result.schema.json'), 'utf8'));
const webpageTtsRequestSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/webpage-tts-invoke-request.schema.json'), 'utf8'));
const webpageTtsStreamSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/webpage-tts-stream-result.schema.json'), 'utf8'));
if (!ttsSynthesisSchema.oneOf.some(branch => branch.properties?.kind?.const === 'audio-base64') ||
    !webpageTtsRequestSchema.properties.output.enum.includes('stream') ||
    webpageTtsStreamSchema.properties.kind.const !== 'audio-stream' ||
    !declarations.includes('FishReaderTtsPackageCatalogPage') ||
    !declarations.includes('FishReaderWebTtsStreamResult') ||
    !declarations.includes('streamStatusAsync?')) {
  throw new Error('1.3.1-2 TTS 与网页音频契约不完整');
}
for (const [name, tokens] of [
  ['docs/28-1.1.7网页请求容量与滚动补位.md', ['maxConcurrentRequests', '32', '16', 'BUSY', 'listAsync', 'invokeAsync', '120', '30']],
  ['docs/29-1.1.7书籍图片与PDF数据读取.md', ['chapterKey + ordinal', 'archivePath', 'FISHREADER_EPUB_IMAGE', 'importData', 'resource', 'readFile', 'releaseFile', 'UTF-16', 'nextOffset', 'SESSION_REVOKED']]
]) {
  const source = fs.readFileSync(path.join(root, name), 'utf8');
  for (const token of tokens) if (!source.includes(token)) throw new Error(`${name} 缺少 ${token}`);
  for (const [, code] of source.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) new vm.Script(`(async () => {\n${code}\n})`);
}
for (const token of ['FishReaderWebContentPluginCapabilities', 'maxConcurrentRequests', 'FishReaderBookChapterImage', 'FishReaderBookResource']) {
  if (!declarations.includes(token)) throw new Error(`1.1.7 类型声明缺少 ${token}`);
}
const searchTemplate = fs.readFileSync(path.join(root, 'examples/web-plugin-search/template.html'), 'utf8');
const searchClient = fs.readFileSync(path.join(root, 'examples/web-plugin-search/client.js'), 'utf8');
const searchIndex = fs.readFileSync(path.join(root, 'examples/web-plugin-search/index.html'), 'utf8');
const expectedSearchIndex = searchTemplate.replace('<!-- CLIENT_SCRIPT -->', '<script>\n' + searchClient.replace(/<\/script/gi, '<\\/script') + '\n</script>');
if (searchIndex !== expectedSearchIndex) throw new Error('搜索示例 HTML 未同步模板和帮助代码');
for (const [, code] of searchIndex.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi)) new vm.Script(code);
run('examples/web-plugin-search/smoke-test.cjs');
run('examples/book-resources/smoke-test.cjs');
for (const token of ['registerAsync', 'JSON.parse', 'running:true', 'stopAsync', '临时书',
  'bookshelfGroupsAsync', 'transferredBytes', '10 分钟', '静默',
  "type:'dataTransfer'", 'recovering', 'recoveryAttempts', '外部浏览器',
  'stopTransferExperiment', 'pagehide', '128 KiB', '15 秒', '1 KiB/s']) {
  if (!backgroundGuide.includes(token)) throw new Error(`1.1.6-1 后台服务说明缺少 ${token}`);
}
for (const [, source] of backgroundGuide.matchAll(/```javascript\r?\n([\s\S]*?)```/g)) {
  new vm.Script(`(async () => {\n${source}\n})`);
}
run('examples/web-http-service/smoke-test.mjs');
run('examples/web-http-service/transfer-smoke-test.mjs');
run('examples/web-http-service/guide-snippets.test.mjs');
const transferGuide = fs.readFileSync(path.join(root, 'docs/25-1.1.5-2书籍与长时任务接口.md'), 'utf8');
for (const token of ['FishReaderBooks', 'FishReaderTasks', 'checkpointMissed', 'SESSION_REVOKED',
  'MODE_DATA_TRANSFER', 'SUBMODE_LIVE_VIEW_NOTIFICATION', 'transferredBytes', '静默',
  '10 分钟', '周期性重新注册', '90 秒', 'UTF-16', 'hidden:true', 'importId', 'saveProgress', 'addToShelf', 'readFile']) {
  if (!transferGuide.includes(token)) throw new Error(`1.1.5-2 说明缺少 ${token}`);
}
for (const token of ['FishReaderBooksBridge', 'FishReaderTasksBridge', 'FishReaderBookRequest',
  'FishReaderBookBinary', 'FishReaderTransferTaskStatus']) {
  if (!declarations.includes(token)) throw new Error(`1.1.5-2 类型声明缺少 ${token}`);
}
for (const token of ['FishReaderBooks', 'FishReaderTasks']) {
  if (!completeWebGuide.includes(token) || !mainGuide.includes(token)) throw new Error(`公开接口索引缺少 ${token}`);
}
for (const token of ['FishReaderWebpageResource', 'nodeRuntimeRequestAsync', 'FishReaderWebMedia', 'FishReaderClub',
  'FishReaderDiscover', 'localRelay']) {
  if (!currentAdditions.includes(token)) throw new Error(`0.9.1 增补缺少 ${token}`);
}
for (const token of ['FishReaderWebpageResource', 'FishPython', 'sniffAsync', 'webpageBookDownloadAsync',
  'FishSharedFiles', 'openDetailAsync', 'getSyncHttpEndpointAsync', 'webpageHttpSessionAsync',
  'webpageVerifyAsync', 'webpageVerifySubmitAsync', 'webpageVerifyCancel', 'autoSearch?', 'FishHttpService']) {
  if (!completeWebGuide.includes(token)) throw new Error(`完整网页接口缺少 ${token}`);
}
// Public methods registered on the independent webpage bridge. The two website-storage
// helpers are internal page persistence glue and intentionally absent from this inventory.
const publicWebpageMethods = [
  'play', 'call', 'httpGet', 'httpPost', 'httpGetBinary', 'httpGetText', 'jsvmExecute',
  'parseUrl', 'getStorage', 'httpGetAsync', 'httpPostAsync', 'httpRequestAsync',
  'httpGetBinaryAsync', 'httpGetTextAsync', 'jsvmExecuteAsync', 'getSyncHttpEndpointAsync',
  'getStorageAsync', 'parseUrlAsync', 'readFileAsync', 'pickFileAsync',
  'nodeRuntimeRequestAsync', 'webpageBookLookupAsync', 'webpageBookListAsync',
  'webpageBookDownloadAsync', 'webpageBookStatus', 'webpageBookOpenAsync',
  'webpageBookSearchSourceAsync', 'webpageSecretGetAsync', 'webpageSecretSetAsync',
  'webpageHttpSessionAsync', 'webpageVerifyAsync', 'webpageVerifySubmitAsync',
  'webpageVerifyCancel', 'setStorage', 'sniff', 'sniffAsync', 'openWebView', 'toast'
];
for (const name of publicWebpageMethods) {
  if (!completeWebGuide.includes(name)) throw new Error(`完整网页接口漏列 ${name}`);
}
for (const token of ['plugin-image:', 'pickDataFiles', 'httpRequestAsync', 'qualityRequestEvent',
  'respondQuality', 'externalSubtitles', 'liveChannelMode', 'FishReaderPageNavigation']) {
  if (!priorAdditions.includes(token)) throw new Error(`0.9.5 增补缺少 ${token}`);
}
for (const token of ['qualityRequestEvent', 'externalSubtitles', 'liveChannelMode', 'selectedSubtitleIndex']) {
  if (!videoSchema.includes(token) || !declarations.includes(token)) throw new Error(`0.9.5 契约缺少 ${token}`);
}
for (const token of ['nodeRuntimeRequestAsync', 'moduleInstalled:true', 'ensureModule',
  'setupKey', 'archiveKeepAs', 'localRelay', 'Referer']) {
  if (!latestAdditions.includes(token)) throw new Error(`0.9.6 增补缺少 ${token}`);
}
const fishwebGuide = fs.readFileSync(path.join(root, 'docs/17-1.1.2-fishweb网页包.md'), 'utf8');
for (const token of ['index.html', 'ZIP64', 'Deflate', '相对路径', '主框架', '更新', '备份']) {
  if (!fishwebGuide.includes(token)) throw new Error(`1.1.2 网页包说明缺少 ${token}`);
}
for (const token of ['鱼书 Pro', '相对图标', 'FishReaderWebpageResource', '双向转换', '应用备份直接收录']) {
  if (!fishwebGuide.includes(token)) throw new Error(`1.1.2 网页包说明缺少 ${token}`);
}
const gpuGuide = fs.readFileSync(path.join(root, 'docs/18-1.1.2-Vulkan图形接口.md'), 'utf8');
for (const token of ['FishNativeGPU', 'FGU1', 'FGR1', 'capabilities()', 'open(rectJson)',
  'resize(rectJson)', 'status()', 'close()', 'admissionReceipts', 'compactCompletion',
  '16 MiB', '32 MiB', '77 个 opcode', 'ComputePipeline', 'ImageArray', 'BlitImage',
  'RebindTargetColor', 'RestoreOcclusionResults', 'ResetResources', 'rawImageSubresources']) {
  if (!gpuGuide.includes(token)) throw new Error(`1.1.2 图形接口说明缺少 ${token}`);
}
const filesGuide = fs.readFileSync(path.join(root, 'docs/19-1.1.2-共享文件接口.md'), 'utf8');
const sessionsGuide = fs.readFileSync(path.join(root, 'docs/20-1.1.2-网页会话与验证接口.md'), 'utf8');
const paletteGuide = fs.readFileSync(path.join(root, 'docs/21-1.1.2-HTML主题配色.md'), 'utf8');
const webpagePluginsGuide = fs.readFileSync(path.join(root, 'docs/22-1.1.2-网页调用内容插件.md'), 'utf8');
const latestPublicGuide = fs.readFileSync(path.join(root, 'docs/24-1.1.5接口增补.md'), 'utf8');
for (const token of ['FishHttpService.listen', '0.0.0.0', '16 MiB', '32 KiB', '64',
  'updateTime', '128', 'pickDataFiles()', '200']) {
  if (!latestPublicGuide.includes(token)) throw new Error(`1.1.5 接口增补缺少 ${token}`);
}
for (const token of ['FishHttpServiceBridge', 'FishHttpServiceRequest', 'declare const FishHttpService', 'updateTime?: string']) {
  if (!declarations.includes(token)) throw new Error(`1.1.5 类型声明缺少 ${token}`);
}
const sourceResultSchema = JSON.parse(fs.readFileSync(path.join(root, 'schemas/plugin/source-result.schema.json'), 'utf8'));
if (sourceResultSchema.$defs.chapter.properties.updateTime.maxLength !== 128 ||
  !sourceResultSchema.$defs.chapter.properties.mediaType.enum.includes('file') ||
  !sourceResultSchema.$defs.bookSummary.properties.mediaType.enum.includes('file')) {
  throw new Error('1.1.5 目录时间和文件类结果 Schema 未同步');
}
for (const token of ['FishSharedFiles', 'shared-files.json', 'fish-files-v1',
  'namespace', 'writeOpen', 'commit', '33554432']) {
  if (!filesGuide.includes(token)) throw new Error(`1.1.2 共享文件说明缺少 ${token}`);
}
for (const token of ['getSyncHttpEndpointAsync', 'webpageHttpSessionAsync',
  'webpageVerifyAsync', 'webpageVerifySubmitAsync', 'webpageVerifyCancel',
  'originRouting', 'sessionRouting', 'managedContexts']) {
  if (!sessionsGuide.includes(token)) throw new Error(`1.1.2 网页会话说明缺少 ${token}`);
}
for (const token of ['FishReaderClub.getPalette()', 'darkMode', 'accentSoft',
  'navigationFill', '#AARRGGBB', '#RRGGBBAA', '不依赖', '当前应用外观',
  'fishreader-html', '只注入']) {
  if (!paletteGuide.includes(token)) throw new Error(`1.1.2 HTML 配色说明缺少 ${token}`);
}
for (const token of ['FishReaderClub.getPalette()', 'fishreader-html', '只提供 `getPalette()`']) {
  if (!managementGuide.includes(token)) throw new Error(`插件管理页配色说明缺少 ${token}`);
}
if (!mainGuide.includes('插件管理页只开放该对象的配色方法')) {
  throw new Error('主规范缺少插件管理页配色权限边界');
}
for (const token of ['getPalette()', 'FishReaderHtmlPalette']) {
  if (!declarations.includes(token)) throw new Error(`1.1.2 类型声明缺少 ${token}`);
}
for (const token of ['FishReaderPlugins', 'listAsync()', 'invokeAsync(requestJson)',
  'searchTargets', 'exploreMenu', 'detail', 'catalog', 'content', '已导入本地 HTML', 'iframe',
  'downloadUrls', 'mediaType', 'fishreaderwebviewvideo.play']) {
  if (!webpagePluginsGuide.includes(token)) throw new Error(`1.1.2 网页内容插件说明缺少 ${token}`);
}
for (const token of ['FishReaderPluginsBridge', 'FishReaderWebContentPluginReply',
  'declare const FishReaderPlugins']) {
  if (!declarations.includes(token)) throw new Error(`1.1.2 网页内容插件类型声明缺少 ${token}`);
}
if (!completeWebGuide.includes('FishReaderPlugins') || !mainGuide.includes('FishReaderPlugins')) {
  throw new Error('网页接口索引缺少内容插件桥');
}
for (const token of ['loadWebsiteStorage', 'saveWebsiteStorage', 'FishReaderAudioStatistics.state']) {
  if (!completeWebGuide.includes(token)) throw new Error(`内部辅助接口边界缺少 ${token}`);
}
const resourceSchema = fs.readFileSync(path.join(root, 'schemas/plugin/webpage-resource-package-request.schema.json'), 'utf8');
for (const token of ['[Ff][Ii][Ss][Hh][Ww][Ee][Bb]', 'progressId', 'parts']) {
  if (!resourceSchema.includes(token)) throw new Error(`1.1.2 网页资源 Schema 缺少 ${token}`);
}
for (const token of ['FishNativeGPUBridge', 'FishNativeGPUStatus', 'FishNativeGPUCapabilities',
  'FishSharedFilesBridge', 'FishReaderBrowserSessionOptions', 'FishReaderVerifyCapabilities',
  'attachmentColorViews', 'rawBufferReadback', 'rawImageSubresources',
  'resourceReset', 'restoreOcclusionResults', 'progressId']) {
  if (!declarations.includes(token)) throw new Error(`1.1.2 类型声明缺少 ${token}`);
}
for (const token of ['FishReaderNodeScriptStatus', 'FishReaderNodeScriptBundle', '0.9.6']) {
  if (!declarations.includes(token)) throw new Error(`0.9.6 类型声明缺少 ${token}`);
}
if (/Referer\s*:\s*location\.href/.test(videoGuide) ||
  /Referer\s*:\s*location\.href/.test(htmlGuide)) {
  throw new Error('网页示例把本地页面地址当成媒体 Referer');
}
const excludedStoreBridge = 'FishReader' + 'Store';
if (additions.includes(excludedStoreBridge) || currentAdditions.includes(excludedStoreBridge) ||
  priorAdditions.includes(excludedStoreBridge) || latestAdditions.includes(excludedStoreBridge) ||
  declarations.includes(excludedStoreBridge)) {
  throw new Error('开发规范不应包含商店专用桥接');
}

const relativeNames = files.map(file => path.relative(root, file).replaceAll('\\', '/'));
const forbiddenCharacter = '\u6e90';
if (relativeNames.some(name => name.includes(forbiddenCharacter))) {
  throw new Error('开发包文件名包含禁止字符');
}
for (const file of files.filter(file => /\.(?:md|json|[cm]?js|html?|d\.ts)$/i.test(file))) {
  if (fs.statSync(file).size === 0) throw new Error(`${path.relative(root, file)} 是空文件`);
}
if (relativeNames.some(name => /(^|\/)theme(?:[-./]|$)/i.test(name))) {
  throw new Error('开发包中不应包含主题插件文件');
}
const forbiddenTerms = [String.fromCodePoint(0x4e66, 0x6e90),
  String.fromCodePoint(0x732b, 0x6e90), 'tv' + 'box', 'cat' + 'paw',
  'book' + ' sources', excludedStoreBridge.toLowerCase()];
for (const file of files.filter(file => /\.(?:md|json|[cm]?js|html?|d\.ts)$/i.test(file))) {
  const content = fs.readFileSync(file, 'utf8').toLowerCase();
  const name = path.relative(root, file).toLowerCase();
  if (forbiddenTerms.some(term => content.includes(term) || name.includes(term))) {
    throw new Error(`${path.relative(root, file)} 包含具体外部格式名称`);
  }
}

for (const script of [
  'examples/source-basic/smoke-test.mjs',
  'examples/plugin-development/basic/smoke-test.mjs',
  'examples/source-network/smoke-test.mjs',
  'examples/dictionary-basic/smoke-test.mjs',
  'examples/tts-basic/smoke-test.mjs',
  'examples/web-basic/smoke-test.mjs',
  'examples/web-import-basic/smoke-test.mjs',
  'examples/fishweb-basic/smoke-test.mjs',
  'examples/native-gpu-basic/smoke-test.mjs',
  'examples/shared-files-basic/smoke-test.mjs',
  'examples/contract-recipes/smoke-test.mjs'
]) run(script);

for (const file of relativeNames.filter(name => name.startsWith('dist/') && name.endsWith('.fishplugin.json'))) {
  run('tools/validate-package.mjs', [file]);
  const packed = JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
  if (packed.manifest.sourceFormat !== 'fishreader-html') new vm.Script(packed.source);
  const exampleCopy = relativeNames.find(name => name.startsWith('examples/') &&
    !name.startsWith('examples/plugin-development/') &&
    path.basename(name) === path.basename(file));
  if (exampleCopy && !fs.readFileSync(path.join(root, file)).equals(fs.readFileSync(path.join(root, exampleCopy)))) {
    throw new Error(`${file} 与示例目录中的包不一致`);
  }
}

console.log(`开发包自检通过：${relativeNames.length} 个文件`);
