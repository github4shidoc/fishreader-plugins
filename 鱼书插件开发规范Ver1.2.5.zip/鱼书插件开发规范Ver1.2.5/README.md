# 鱼书插件开发规范 Ver1.2.5（鸿蒙版）

对应应用版本：鱼书鸿蒙版 1.2.5  
插件协议：`schemaVersion: 1`  
建议 SDK：`1.0`  
发布日期：2026-11-14
更新日期：2026-11-14

**主规范是 [`docs/plugins/development-guide.md`](docs/plugins/development-guide.md)。** 本包以 Ver1.2.1 的全部 161 个文件为基线，补充网页弹幕列表与插件页面视频桥。它是完整开发包，不是补丁包。指南与鸿蒙应用版本均为 1.2.5；插件协议 `schemaVersion: 1` 和建议 SDK `1.0` 不变。本版重点见[1.2.5 新增接口](docs/33-1.2.5网页弹幕列表与插件页面视频桥.md)。主题类插件不再支持。

这是一套可以脱离鱼书代码使用的插件开发包。当前公开并建议第三方开发的能力为：

- 内容插件：搜索、发现、详情、目录、正文，以及文字、漫画、有声书和视频内容。
- 字典插件：在阅读页查询选中文字。
- TTS 插件：把阅读页的文字合成为音频。
- `fishreader-html` 插件包：通过插件管理导入，提供使用 `FishReader` 桥接的受限交互页面；可调用 `FishReaderClub.getPalette()` 读取当前应用配色。
- 独立网页：通过“网页与订阅 → 网页”导入单文件 HTML 或 `.fishweb` 网页包，使用网页、播放器及会话桥接；本地网页入口可调用 `FishReaderPlugins` 获取已安装内容插件的搜索、详情、目录、正文与发现结果，授权后还可从书架打开阅读、漫画和有声书页面；也可检测 `FishNativeGPU`，网页包根入口还可声明 `FishSharedFiles`。

主题类插件不再支持，本开发包不包含主题规范、模板或主题结果 Schema。宿主内部遗留字段不代表可供第三方稳定使用。

## 1.2.5 更新重点

- 已导入本地网页的视频请求可设置 `danmaku.loadEvent`，由页面按集提供弹幕列表，并用 `respondDanmakuList` 应答；补全回调字段、超时、条目限制和兼容探测。
- `fishreader-html` 插件页面和插件管理页面的视频桥现支持 `respondDanmakuList`；修正旧章节中“只提供 play”的失效描述。同步 Schema、类型和[完整契约](docs/33-1.2.5网页弹幕列表与插件页面视频桥.md)。

## 1.2.1 更新重点（沿用）

- `ttsVoices` 可按当前书籍查询，声音项增加可选 `scope` 与 `mode`。`mode:'text'` 逐段调用 `ttsSynthesize`，`mode:'chapter'` 按整章调用 `content` 获取音频。
- 音频正文结果可选附带 `audioTimeline`，使书籍专属章节朗读按原文时间轴高亮。更新结果 Schema、TypeScript 类型和[完整契约](docs/32-1.2.1书籍专属音色与音频时间轴.md)。
- 旧插件省略新增字段时维持全局文字 TTS 行为；网页桥没有新增公开调用。

## 1.1.9 更新重点（沿用）

- 内容插件 `reviews` 新增可选 `filterKey` 输入、`filters` 与 `selectedFilterKey` 输出，用通用按钮元数据提供书评筛选；更新结果 Schema、类型和校验说明。
- TTS 插件可在 Manifest 声明 `ttsPackages` 目录、格式/分类及迁移规则，管理页通过 `FishReader.ttsPackages` 扫描、批量导入、查看、移除和试听。
- `ttsSynthesize` 新增 `local-model` 与 `tts-package` 两种本地合成结果；HTTP TTS 原契约仍适用。同步声明、合成结果 Schema、TypeScript 类型和包校验工具。
- 当前独立网页的内容插件桥仍不开放 `reviews`，管理页专用的 `ttsPackages` 也不在独立网页注入。

## 1.1.7-2 更新重点（沿用）

- 内容插件可选声明 `reviews` 入口，为发现页文字、漫画、有声书详情提供分页书评；未声明的插件继续正常显示详情和目录。
- 新增[书评接口专章](docs/30-1.1.7-2书评接口.md)、[返回结果 Schema](schemas/plugin/reviews-result.schema.json)及 TypeScript 声明。当前独立网页的内容插件桥尚未开放 `reviews`。
- 书评结果限制为每页 100 项，要求稳定 ID、非空正文和前进的分页游标；保留旧包全部文件与既有契约。

## 1.1.7 更新重点（沿用）

- `FishReaderPlugins` 同一网页的在途请求容量为 32，`listAsync` 与 `invokeAsync` 共用；实际执行并发由应用设置决定，默认 16。网页不指定执行线程数。
- 网页按 `capabilities().maxConcurrentRequests` 滚动提交：一个实际请求结束后立即补下一个，不一次性提交全部，也不等整批完成。兼容旧应用返回 4 的容量。
- 网页自行设置的等待超时不等于底层取消；未结束的请求仍占容量。单源失败不阻塞其他源，停止后不再提交且丢弃迟到结果。
- 新增[独立 HTML 多源搜索示例](examples/web-plugin-search/README.md)，统一调度列表、搜索与其他插件调用，包含可执行补位与超时回归测试。
- 补充 EPUB/PDF 的书籍接口用法：章节与图片索引关联、资源分片、原文件读取和会话/进度约定。
- 插件包 `schemaVersion: 1`、SDK `1.0` 和入口签名不变；现有插件无需改包。

## 1.1.6-1 更新重点（沿用）

- 后台网页服务先启动监听，再申请 `dataTransfer` 任务并检查 `running:true`；申请失败关闭监听，停止时先停止任务。
- 明确本机网页、外部浏览器和宿主的分工：外部浏览器不直接调用桥接，定时真实传输由外部网页实现；通知心跳不等于网络保活。
- 补充应用侧 5 / 30 / 60 秒最多三次恢复、可选状态字段、请求超时和计时清理；网页不要另写重注册循环。
- 新增[局域网服务测试网页](examples/web-http-service/README.md)，可验证前台 / 后台 HTTP、文本和二进制回传、状态及真实传输字节。
- 新旧书架接口均过滤未加入书架的临时书；临时书正式入架后，下次查询即可返回。旧分组接口继续兼容。
- 任务申请、状态查询与停止的公开签名不变；静默通知由宿主处理，网页无需查询或管理系统通知。

## 1.1.5-2 能力摘要（沿用）

- `FishReaderBooks`：所有书籍类型的书架标识、隐藏标记、已存资料、进度读取 / 回写和加入书架接口。内容插件书籍继续复用既有插件内容接口。
- 已导入的本地 / 远端书籍提供 `importId`，可分别读取详情、封面、导入目录、原始章节数据和关联文件；不引入阅读槽位、分页、预载或媒体处理。文字、漫画、有声书均使用现有进度模型和书籍会话校验。
- `FishReaderTasks`：网页按需注册 / 查询 / 停止数据传输长时任务，宿主按实际 HTTP 收发更新关联实况通知；说明静默策略、系统取消和生命周期清理，不承诺空闲永久运行。
- 入架接口接收提交的详情 / 目录或临时书籍 ID，调用现有入架方法，不另建流程或自动补抓内容。
- `FishReaderPlugins` 增加通用 callback 入口，复用插件已有动作逻辑，只向网页返回数据；[段评与动作回调](docs/26-1.1.5-2段评与动作回调.md)说明标记解析、引用调用、返回值与失效处理。

## 1.1.5 能力摘要（沿用）

- 已导入本地 HTML 与 `.fishweb` 根入口可用 `FishHttpService.listen(port, handler)` 建立网页拥有的 HTTP 服务，接收本机或局域网请求；请求体、响应体通过二进制消息端口传输。见[1.1.5 接口增补](docs/24-1.1.5接口增补.md)。
- 内容插件 `catalog` 结果的目录项可增加 `updateTime`，表示内容提供方给出的更新时间；最多 128 字符。
- `fishreader-html` 管理页的 `FishReader.ui.pickDataFiles()` 单次选择上限提高至 200 个文件，每个文件仍受 100 MiB 上限约束。

## 1.1.2 能力摘要

本版同步规范与应用版本号，并增加网页调用已安装内容插件和按书架书籍 ID 打开的接口；下列其他接口沿用 Ver1.1.1。

补充：本地网页现可通过 `FishReaderPlugins` 调用已启用内容插件的完整内容获取链路，见[网页调用内容插件](docs/22-1.1.2-网页调用内容插件.md)。

已导入本地网页可在取得书架数据授权后，使用 `FishReaderClub.openBookshelfBookAsync(bookId)` 打开书架中的文字、漫画或有声书；见[书架导航](docs/23-1.1.2-网页书架导航.md)。

- 已导入 HTML 与 `fishreader-html` 插件管理页均可调用 `FishReaderClub.getPalette()` 读取鱼书当前外观配色；插件管理页只开放这个配色方法。说明包含全部字段、权限范围、颜色格式与 CSS 示例；读取不要求书架或阅读统计授权。
- `FishSharedFiles`：网页包在 `shared-files.json` 声明命名空间，通过二进制端口读写应用共享目录；提供[接口说明](docs/19-1.1.2-共享文件接口.md)和[可导入示例](examples/shared-files-basic/README.md)。
- 补全此前遗漏的 `webpageHttpSessionAsync`、`webpageVerifyAsync`、`webpageVerifySubmitAsync`、`webpageVerifyCancel`、`getSyncHttpEndpointAsync`，以及会话能力、按域路由和媒体失败事件的边界，见[会话接口说明](docs/20-1.1.2-网页会话与验证接口.md)。
- `FishNativeGPU` 增至 77 个 opcode，新增附件颜色视图切换、原始子资源传输、查询恢复和资源重置；普通插件 `schemaVersion: 1` 与建议 SDK `1.0` 不变。

## 1.0.3 历史更新重点

- 增加 `.fishweb` 网页包格式、会员导入、相对图标与资源桥更新说明。
- 增加 `FishNativeGPU` / `FGU1` 的 74 个初始命令及最小绘图示例。

## 0.9.6 历史更新重点

- 独立 HTML 的 `nodeRuntimeRequestAsync` 现在使用应用内置的脚本运行环境；`status` 与 `ensureModule` 的返回和调用顺序按当前实现更新。
- 补充脚本请求的初始化复用、并发调用、ZIP 保留字段，以及同一网页脚本返回的本地媒体 URL 在播放器中的适用边界。
- 明确视频 `pageUrl` 仅在有效 HTTP(S) 页面地址下推导默认 Referer；本地 HTML 应按媒体服务要求显式提供合法请求头。
- `localRelay` 仍是既有播放字段，说明当前字节范围、跳转及 HLS 播放行为；插件包协议和建议 SDK 均未变。

## 0.9.5 历史更新重点

- 内容插件可用 `plugin-image:` 封面地址请求按需执行 `image` 入口；管理页新增 `ui.pickDataFiles()` 批量选择文件。
- 独立 HTML 的 `FishPlayerWebVideo` 新增 `httpRequestAsync`；网页播放器新增画质请求与应答、外部字幕和初始轨道选择、直播频道/线路/节目单字段。
- `fishreader-html` 插件包的视频桥支持带参数播放、按集应答和画质应答；其方法范围与独立 HTML 网页不同。
- 更新网页视频 Schema、编辑器类型和自检，保持插件包 `schemaVersion: 1`、建议 SDK `1.0`。

## 0.9.1 历史更新重点

- 对照当前宿主区分普通插件、管理页和独立 HTML 网页；插件包协议主版本不变。
- 收录本地 HTML 的 `FishReaderWebpageResource` 通用资源桥、`nodeRuntimeRequestAsync` 私有脚本管理、`FishReaderWebMedia` 媒体会话及经本地授权的 `FishReaderClub` 数据桥。
- 补充发现桥能力与返回字段、视频 `localRelay` 及按集覆盖，更新 TypeScript 声明、视频和网页请求 Schema。
- 扩充独立 HTML 完整参考；商店专用桥接和宿主内部字段不进入公开开发接口。

## 0.7.9 历史更新重点

- 新增 `manifest.fileImport` 与管理页 `FishReader.plugin.registerFileImport`，外部 JSON 文件经用户确认后交给插件处理。
- 新增发现筛选 `button`、搜索目标图标提示、音频 `mediaEncryption`、受控 WebView 人工验证与单次超时。
- 对照当前鸿蒙实现更新插件包 100 MiB、搜索/发现 5,000 项上限和相应 Schema/类型。
- 盘点独立网页的书籍、会话、发现、Python、内嵌播放与弹幕桥接；明确各自的页面权限。
- 沿用 `schemaVersion: 1`、SDK `1.0`；主题类插件不再支持。

## 0.6.0 历史更新重点

- 用户导入的网页获得按网页条目和页面 Origin 隔离的持久化 `localStorage`；删除网页时只清除该条目数据，不清理共享 Cookie 或其他网页数据。
- 网页播放器新增 `capabilities()` 能力探测与 `respondEpisode()` 按集取链回应，可在播放器不退出的情况下完成切集。
- 新增选集预取、播放中进度事件、初始断点、播放地址刷新事件；调用方仍负责取链、记录和片首尾持久化。
- 更新 `mediaOptions`、网页播放 Schema、TypeScript 声明和独立 HTML 示例；插件协议仍为 `schemaVersion: 1`，建议 SDK 仍为 `1.0`。
- 保留 Ver0.5.8 的发现筛选、环境信息、网页导入和完整开发包内容。

## 0.5.1 起保留的契约重点

- 新增目录 `locator` 契约：跨调用上下文通过 `content.input.chapter` 恢复，不能依赖同一个 JS 实例。
- 补齐目录文件事务参数、提交与失败清理，明确每块字节限制和普通插件的选择。
- 区分数据库 500 行分页、校验单次 2,048 项与搜索目标总量，提供 2,232 项离线批次测试。
- 明确 JS 隔离运行环境不保证浏览器全局对象；编码使用 `reader.text`，网页执行读取响应的 `body`。
- 增加独立回归配方、冷启动示例与执行请求 Schema 的图片/动作入口检查。

- 插件协议仍是 `schemaVersion: 1`，公开 SDK 仍是 `1.0`；不要因为开发规范版本变化而修改这两个值。
- `sourceFormat` 只能使用宿主公开枚举；JS 插件通常使用 `fishreader-js`。自定义字符串会在导入阶段被拒绝。
- JS 插件只要声明 `managementModule`，就必须同时声明 `ui`，并在 `modules` 中提供同名 HTML；三者缺一不可。
- 包内 `entryModule`、`managementModule` 和 `modules` 键统一使用 `/` 分隔的相对路径，不允许绝对路径、反斜杠或 `..`。
- 私有存储可能包含旧版本、备份或跨平台迁移留下的字符串、数字、布尔值、数组或对象；读取后先判断类型，不能无条件 `JSON.parse`。
- 多目标内容插件必须把稳定的 `sourceKey` 贯穿搜索、发现、详情、目录和正文；`bookKey`、`chapterKey` 也必须能在冷启动后重新定位数据。
- 拆分批量搜索由宿主维护 HTTP 槽位；请求完成一个就补入一个。插件不要自行切固定批次等待，也不要在列表阶段提前去重。
- 数据库单次查询 `maximumRows` 必须是 `1..500` 的整数；更多记录必须稳定排序后分页读取。
- 多目标清单可返回 `homeUrl`、`iconUrl` 和 `metadataDeferred`；不要为了补图标或主页信息阻塞首次列表显示。
- 漫画、有声书和视频必须使用 `mediaType` 与对应媒体结果；不要依赖标题或分类文字猜测阅读器。
- 网页调用优先使用 Promise 方法；视频桥接支持标题、季集、请求头和片首尾回传，调用前必须做能力检测。
- 校验工具检查公开枚举、管理页绑定规则和数据库行数边界；不替代手机实际导入与播放验证。

## 第一次开发

1. 安装 Node.js 18 或更高版本。
2. 复制 `examples/source-basic`，修改 `manifest.json` 和 `index.js`。
3. 在示例目录执行：

   ```bash
   node build.mjs
   node smoke-test.mjs
   ```

4. 在鱼书中打开“设置 → 插件管理”，导入生成的 `*.fishplugin.json`，启用后测试。
5. 发布前在开发包根目录执行：

   ```bash
   node tools/validate-package.mjs 路径/你的插件.fishplugin.json
   ```

开发包自身可用以下命令完整自检：

```bash
node tools/verify-guide.mjs
```

完整流程见 `docs/01-从零开始.md`。

## 目录

```text
README.md                         本文件
CHANGELOG.md                      本版规范变化
docs/
  01-从零开始.md                 创建、构建、导入第一个插件
  02-插件包与声明信息.md          包格式、Manifest、升级语义
  03-内容插件.md                  搜索到正文的完整数据链路
  04-宿主API.md                   reader.* 能力参考
  05-管理页面与登录.md            FishReader 桥接、文件导入导出、登录
  06-字典与TTS插件.md             两类独立能力
  07-安全性能与兼容.md            权限、限额、后台任务和跨平台要求
  08-测试打包与发布.md            本地检查和发布清单
  09-常见错误.md                 错误定位方法
  10-网页接口.md                 网页入口、桥接与播放说明
  11-目录上下文与批量任务.md       冷启动、目录事务、分页与批次边界
  plugins/development-guide.md     1.2.5 主规范，包含网页类插件导入章节
  12-0.7.9接口增补.md              0.7.9 已有能力索引
  13-网页接口完整参考.md            独立网页的方法、参数与事件
  14-0.9.1接口增补.md              0.9.1 新增公开接口
  15-0.9.5接口增补.md              0.9.5 新增公开接口
  16-0.9.6接口增补.md              0.9.6 运行行为与接口边界
  17-1.1.2-fishweb网页包.md        网页包格式、资源、导入和更新
  18-1.1.2-Vulkan图形接口.md       原生图形接口与 FGU1 协议
  19-1.1.2-共享文件接口.md         网页包共享目录、端口协议与帮助模块
  20-1.1.2-网页会话与验证接口.md   会话 HTTP、人工验证和同步入口
  21-1.1.2-HTML主题配色.md        已导入 HTML 读取当前外观配色
  22-1.1.2-网页调用内容插件.md    已导入网页调用内容插件
  23-1.1.2-网页书架导航.md        已导入网页从书架打开书籍
  24-1.1.5接口增补.md             网页 HTTP 服务、目录更新时间与多文件上限
  25-1.1.5-2书籍与长时任务接口.md  通用书籍数据、独占会话、入架和后台任务
  26-1.1.5-2段评与动作回调.md      段评标记、动作引用和通用 callback
  27-1.1.6网页服务后台运行.md       后台服务顺序、任务清理与排错
  28-1.1.7网页请求容量与滚动补位.md  内容插件请求容量、排队、超时与停止
  29-1.1.7书籍图片与PDF数据读取.md   图片索引、二进制读取与文件会话
  30-1.1.7-2书评接口.md             内容插件书评入口、分页与结果限制
  31-1.1.9-TTS语音包接口.md          TTS 语音包声明、管理页桥接与本地合成
  32-1.2.1书籍专属音色与音频时间轴.md  书籍音色、章节朗读与原文时间轴
  33-1.2.5网页弹幕列表与插件页面视频桥.md  按集弹幕列表回调与视频桥方法
  plugins/discover-filters.md      发现筛选可选扩展
  plugins/package-format.md        插件包格式
  plugins/result-contracts.md      结果契约
  web-video-bridge.md             网页视频桥接完整字段
examples/
  source-basic/                   无网络、可直接导入的最小内容插件
  source-network/                 网络与 HTML 解析模板
  dictionary-basic/               字典模板
  tts-basic/                      TTS 模板
  web-basic/                      插件管理中导入的 HTML 插件包模板
  web-import-basic/               在“网页与订阅”导入的独立 HTML 模板
  fishweb-basic/                  可打包的独立网页包示例
  native-gpu-basic/               可导入的 Vulkan 三角形示例和通用 JS 帮助模块
  shared-files-basic/             可导入的共享文件示例和通用 JS 帮助模块
  web-http-service/               可导入的局域网后台服务测试网页
  web-plugin-search/              内容插件共享队列调用示例
  book-resources/                 图片索引与二进制分块读取帮助函数
  contract-recipes/               可执行的分页、批次和冷启动回归配方
  plugin-development/basic/         主规范引用的最小内容插件
plugins/
  dictionary-example/              主规范引用的字典示例
  tts-template/                     主规范引用的 TTS 示例
schemas/                          当前公开契约的 JSON Schema
types/fishreader-plugin.d.ts      编辑器类型提示
tools/build-plugin.mjs            通用打包工具
tools/validate-package.mjs        零依赖静态校验工具
tools/verify-guide.mjs            开发包示例与契约自检
dist/                             已构建的示例插件
```

## 重要边界

- 插件运行在隔离环境中，不能直接访问系统文件、进程、套接字、原生对象或页面组件。
- 网络、Cookie、存储、数据库、HTML 解析、加密和私有文件必须通过宿主 API。
- 仅能访问 Manifest 声明并由用户授权的域名；重定向目标也会重新校验。
- 插件输入输出必须是可 JSON 序列化的普通值，不能返回 DOM、函数、自定义类实例或循环引用。
- 插件不得绕过登录、付费、访问控制、反自动化措施或目标服务条款。
- `pluginId` 是升级身份。发布后改显示名可以，改 `pluginId` 会被视为另一个插件。
- 包内模块路径和插件私有文件路径都必须相对化；二者不是系统文件路径。
- TTS 和有声书是两套能力：TTS 合成文字；有声书由内容插件 `content` 返回音频地址。

文档、Schema 和目标鱼书版本有冲突时，以随目标应用发布的 Schema 和该版本实际公开接口为准。
