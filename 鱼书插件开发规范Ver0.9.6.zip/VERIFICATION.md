# Ver0.9.6 开发包验证说明

日期：2026-10-22。本开发包以 Ver0.9.5 完整包为底稿，按鱼书鸿蒙版 0.9.6 本地源码核对公开契约。主规范为 `docs/plugins/development-guide.md`，最新行为见 `docs/16-0.9.6接口增补.md`，独立 HTML 完整参考见 `docs/13-网页接口完整参考.md`。应用源码及既有版本开发包未修改。

## 本次核对

- 独立 HTML：对照 `NodeScriptService.ets` 与 `NodeRuntimeService.ets`，修订内置运行环境、`status` / `ensureModule`、文件包保留、配置、初始化复用与并发调用说明。
- 网页播放器：对照 `WebViewPage.ets`、`HtmlPlugin.ets`、`WebVideoRequestHeaders.ets` 和本地中继实现，明确默认 Referer、脚本本地媒体地址及既有 `localRelay` 的边界。
- 普通插件协议和 0.9.5 已有字段继续适用；TypeScript 声明、网页参考、示例请求头与自检同步更新。商店专用及主题类接口未纳入。

## 可复现离线检查

在包根目录运行 `node tools/verify-guide.mjs`。本次结果：

- 插件与网页示例冒烟测试通过；契约配方覆盖 2,232 项分页、批量、生命周期与章节上下文。
- 5 个 `dist` 示例包通过静态校验；JSON、Schema 正则、JS 语法、版本号、相对链接及禁用术语检查通过。
- 0.9.6 脚本桥、请求头、类型声明、环境区分和排除术语检查通过；开发包自检报告 100 个文件。

这些是离线文档和示例检查，不等于应用编译或真机验收。开发者仍需在目标宿主、站点和授权账号下验证网络、登录、视频及加密播放。
