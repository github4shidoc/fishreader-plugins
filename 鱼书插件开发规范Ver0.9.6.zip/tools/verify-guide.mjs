import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function run(script, args = []) {
  const result = spawnSync(process.execPath, [path.join(root, script), ...args], {
    cwd: root,
    encoding: 'utf8'
  });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${script} 失败`);
}

const files = walk(root);

for (const requiredFile of [
  'schemas/plugin/image-result.schema.json',
  'schemas/plugin/action-result.schema.json',
  'schemas/plugin/web-video-playback-request.schema.json',
  'schemas/plugin/webpage-resource-http-request.schema.json',
  'schemas/plugin/webpage-resource-package-request.schema.json',
  'schemas/plugin/web-media-status.schema.json',
  'examples/web-import-basic/index.html',
  'docs/plugins/discover-filters.md',
  'docs/12-0.7.9接口增补.md',
  'docs/13-网页接口完整参考.md',
  'docs/14-0.9.1接口增补.md',
  'docs/15-0.9.5接口增补.md',
  'docs/16-0.9.6接口增补.md'
]) {
  if (!fs.existsSync(path.join(root, requiredFile))) throw new Error(`缺少 ${requiredFile}`);
}

const requiredVersionFiles = [
  'README.md',
  'CHANGELOG.md',
  'docs/plugins/package-format.md',
  'schemas/README.md',
  'types/fishreader-plugin.d.ts',
  'tools/validate-package.mjs',
  'docs/plugins/development-guide.md'
];
for (const name of requiredVersionFiles) {
  const source = fs.readFileSync(path.join(root, name), 'utf8');
  if (!source.includes('0.9.6')) throw new Error(`${name} 未同步到规范版本 0.9.6`);
}
if (!fs.readFileSync(path.join(root, 'README.md'), 'utf8').includes('发布日期：2026-10-22')) {
  throw new Error('README 发布日期未更新');
}
if (/themes\s*\(/.test(fs.readFileSync(path.join(root, 'docs/plugins/package-format.md'), 'utf8'))) {
  throw new Error('插件包格式误将主题入口写为公开能力');
}

for (const file of files.filter(file => file.endsWith('.md'))) {
  const content = fs.readFileSync(file, 'utf8');
  let inCode = false;
  for (const line of content.split(/\r?\n/)) {
    if (/^\s*```/.test(line)) { inCode = !inCode; continue; }
    if (inCode) continue;
    for (const [, rawTarget] of line.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
      const localTarget = rawTarget.split('#', 1)[0];
      if (!localTarget || /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(localTarget)) continue;
      const resolved = path.resolve(path.dirname(file), decodeURIComponent(localTarget));
      if (!fs.existsSync(resolved)) throw new Error(`${path.relative(root, file)} 的链接不存在：${rawTarget}`);
    }
  }
}

for (const file of files.filter(file => file.endsWith('.json'))) {
  JSON.parse(fs.readFileSync(file, 'utf8'));
}

for (const file of files.filter(file => file.endsWith('.schema.json'))) {
  const schema = JSON.parse(fs.readFileSync(file, 'utf8'));
  const visit = value => {
    if (!value || typeof value !== 'object') return;
    if (typeof value.pattern === 'string') new RegExp(value.pattern);
    for (const child of Object.values(value)) visit(child);
  };
  visit(schema);
}

const htmlGuide = fs.readFileSync(path.join(root, 'docs/10-网页接口.md'), 'utf8');
const mainGuide = fs.readFileSync(path.join(root, 'docs/plugins/development-guide.md'), 'utf8');
const videoGuide = fs.readFileSync(path.join(root, 'docs/web-video-bridge.md'), 'utf8');
const declarations = fs.readFileSync(path.join(root, 'types/fishreader-plugin.d.ts'), 'utf8');
const videoSchema = fs.readFileSync(path.join(root, 'schemas/plugin/web-video-playback-request.schema.json'), 'utf8');
for (const [name, source, required] of [
  ['网页接口', htmlGuide, ['localStorage', '.capabilities', 'respondEpisode', 'episodeRequestEvent', 'progressIntervalSeconds']],
  ['主规范', mainGuide, ['网页条目 ID + 当前页面 Origin', 'prefetchNextSeconds', 'startPositionMs', 'refreshEvent']],
  ['视频协议', videoGuide, ['inlineEpisodeRequest', "purpose: 'prefetch'", 'updatedAt', 'sequence', 'ivHex']],
  ['类型声明', declarations, ['FishReaderWebVideoCapabilities', 'FishReaderWebVideoEpisodeResponse', 'respondEpisode?', 'defaultIvHex']],
  ['视频 Schema', videoSchema, ['episodeRequestEvent', 'prefetchNextSeconds', 'startPositionMs', 'defaultIvHex']]
]) {
  for (const token of required) if (!source.includes(token)) throw new Error(`${name} 缺少既有内容：${token}`);
}
const additions = fs.readFileSync(path.join(root, 'docs/12-0.7.9接口增补.md'), 'utf8');
for (const token of ['fileImport', 'registerFileImport', 'mediaEncryption', 'verificationJavaScript',
  'FishReaderDiscover', 'playInline', 'respondDanmaku']) {
  if (!additions.includes(token)) throw new Error(`0.7.9 增补缺少 ${token}`);
}
const currentAdditions = fs.readFileSync(path.join(root, 'docs/14-0.9.1接口增补.md'), 'utf8');
const priorAdditions = fs.readFileSync(path.join(root, 'docs/15-0.9.5接口增补.md'), 'utf8');
const latestAdditions = fs.readFileSync(path.join(root, 'docs/16-0.9.6接口增补.md'), 'utf8');
const completeWebGuide = fs.readFileSync(path.join(root, 'docs/13-网页接口完整参考.md'), 'utf8');
for (const token of ['FishReaderWebpageResource', 'nodeRuntimeRequestAsync', 'FishReaderWebMedia', 'FishReaderClub',
  'FishReaderDiscover', 'localRelay']) {
  if (!currentAdditions.includes(token)) throw new Error(`0.9.1 增补缺少 ${token}`);
}
for (const token of ['FishReaderWebpageResource', 'FishPython', 'sniffAsync', 'webpageBookDownloadAsync']) {
  if (!completeWebGuide.includes(token)) throw new Error(`完整网页接口缺少 ${token}`);
}
for (const token of ['plugin-image:', 'pickDataFiles', 'httpRequestAsync', 'qualityRequestEvent',
  'respondQuality', 'externalSubtitles', 'liveChannelMode', 'FishReaderPageNavigation']) {
  if (!priorAdditions.includes(token)) throw new Error(`0.9.5 增补缺少 ${token}`);
}
for (const token of ['qualityRequestEvent', 'externalSubtitles', 'liveChannelMode', 'selectedSubtitleIndex']) {
  if (!videoSchema.includes(token) || !declarations.includes(token)) throw new Error(`0.9.5 契约缺少 ${token}`);
}
for (const token of ['nodeRuntimeRequestAsync', 'moduleInstalled:true', 'ensureModule',
  'setupKey', 'archiveKeepAs', 'localRelay', 'Referer']) {
  if (!latestAdditions.includes(token)) throw new Error(`0.9.6 增补缺少 ${token}`);
}
for (const token of ['FishReaderNodeScriptStatus', 'FishReaderNodeScriptBundle', '0.9.6']) {
  if (!declarations.includes(token)) throw new Error(`0.9.6 类型声明缺少 ${token}`);
}
if (/Referer\s*:\s*location\.href/.test(videoGuide) ||
  /Referer\s*:\s*location\.href/.test(htmlGuide)) {
  throw new Error('网页示例把本地页面地址当成媒体 Referer');
}
const excludedStoreBridge = 'FishReader' + 'Store';
if (additions.includes(excludedStoreBridge) || currentAdditions.includes(excludedStoreBridge) ||
  priorAdditions.includes(excludedStoreBridge) || latestAdditions.includes(excludedStoreBridge) ||
  declarations.includes(excludedStoreBridge)) {
  throw new Error('开发规范不应包含商店专用桥接');
}

const relativeNames = files.map(file => path.relative(root, file).replaceAll('\\', '/'));
const forbiddenCharacter = '\u6e90';
if (relativeNames.some(name => name.includes(forbiddenCharacter))) {
  throw new Error('开发包文件名包含禁止字符');
}
for (const file of files.filter(file => /\.(?:md|json|[cm]?js|html?|d\.ts)$/i.test(file))) {
  if (fs.statSync(file).size === 0) throw new Error(`${path.relative(root, file)} 是空文件`);
}
if (relativeNames.some(name => /(^|\/)theme(?:[-./]|$)/i.test(name))) {
  throw new Error('开发包中不应包含主题插件文件');
}
const forbiddenTerms = [String.fromCodePoint(0x4e66, 0x6e90),
  String.fromCodePoint(0x732b, 0x6e90), 'tv' + 'box', 'cat' + 'paw',
  'book' + ' sources', excludedStoreBridge.toLowerCase()];
for (const file of files.filter(file => /\.(?:md|json|[cm]?js|html?|d\.ts)$/i.test(file))) {
  const content = fs.readFileSync(file, 'utf8').toLowerCase();
  const name = path.relative(root, file).toLowerCase();
  if (forbiddenTerms.some(term => content.includes(term) || name.includes(term))) {
    throw new Error(`${path.relative(root, file)} 包含具体外部格式名称`);
  }
}

for (const script of [
  'examples/source-basic/smoke-test.mjs',
  'examples/plugin-development/basic/smoke-test.mjs',
  'examples/source-network/smoke-test.mjs',
  'examples/dictionary-basic/smoke-test.mjs',
  'examples/tts-basic/smoke-test.mjs',
  'examples/web-basic/smoke-test.mjs',
  'examples/web-import-basic/smoke-test.mjs',
  'examples/contract-recipes/smoke-test.mjs'
]) run(script);

for (const file of relativeNames.filter(name => name.startsWith('dist/') && name.endsWith('.fishplugin.json'))) {
  run('tools/validate-package.mjs', [file]);
  const packed = JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
  if (packed.manifest.sourceFormat !== 'fishreader-html') new vm.Script(packed.source);
  const exampleCopy = relativeNames.find(name => name.startsWith('examples/') &&
    !name.startsWith('examples/plugin-development/') &&
    path.basename(name) === path.basename(file));
  if (exampleCopy && !fs.readFileSync(path.join(root, file)).equals(fs.readFileSync(path.join(root, exampleCopy)))) {
    throw new Error(`${file} 与示例目录中的包不一致`);
  }
}

console.log(`开发包自检通过：${relativeNames.length} 个文件`);
